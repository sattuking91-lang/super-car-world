package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.engine.Gl3DRenderer
import com.example.model.CarCatalog
import com.example.model.GameSettings
import com.example.ui.components.GameGlViewport
import com.example.ui.theme.AsphaltDark
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.ChampionshipGold
import com.example.ui.theme.CrispWhite
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GoldBright
import com.example.ui.theme.MutedSlate
import com.example.ui.theme.RacingCrimson

@Composable
fun MainMenuScreen(
    renderer: Gl3DRenderer,
    settings: GameSettings,
    onPlayClick: () -> Unit,
    onSelectMapClick: () -> Unit,
    onSelectCarClick: () -> Unit,
    onSettingsClick: () -> Unit
) {
    val selectedCar = CarCatalog.fromId(settings.selectedCarId)
    val bestForMap = settings.bestScores[settings.selectedMap] ?: 0

    Box(modifier = Modifier.fillMaxSize()) {
        // Live 3D racing showcase background
        GameGlViewport(renderer = renderer, modifier = Modifier.fillMaxSize())

        // Cinematic dark gradient scrim for crisp foreground legibility
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        0.0f to AsphaltDark.copy(alpha = 0.78f),
                        0.45f to AsphaltDark.copy(alpha = 0.30f),
                        1.0f to AsphaltDark.copy(alpha = 0.90f)
                    )
                )
        )

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 24.dp, vertical = 20.dp)
        ) {
            val isLandscape = maxWidth > maxHeight

            if (isLandscape) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 24.dp),
                        verticalArrangement = Arrangement.Center
                    ) {
                        TitleHeader(
                            mapName = settings.selectedMap.displayName,
                            carName = selectedCar.name,
                            bestScore = bestForMap,
                            coinBalance = settings.coinBalance
                        )
                    }
                    Column(
                        modifier = Modifier.widthIn(min = 280.dp, max = 360.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        MenuActionButtons(
                            onPlayClick = onPlayClick,
                            onSelectMapClick = onSelectMapClick,
                            onSelectCarClick = onSelectCarClick,
                            onSettingsClick = onSettingsClick
                        )
                    }
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 520.dp)
                        .align(Alignment.Center),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    TitleHeader(
                        mapName = settings.selectedMap.displayName,
                        carName = selectedCar.name,
                        bestScore = bestForMap,
                        coinBalance = settings.coinBalance
                    )

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        MenuActionButtons(
                            onPlayClick = onPlayClick,
                            onSelectMapClick = onSelectMapClick,
                            onSelectCarClick = onSelectCarClick,
                            onSettingsClick = onSettingsClick
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TitleHeader(
    mapName: String,
    carName: String,
    bestScore: Int,
    coinBalance: Int
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = RacingCrimson.copy(alpha = 0.22f),
                shape = RoundedCornerShape(50),
                border = BorderStroke(1.dp, RacingCrimson.copy(alpha = 0.7f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = null,
                        tint = ChampionshipGold,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "3D ARCADE RACING",
                        style = MaterialTheme.typography.labelSmall,
                        color = CrispWhite
                    )
                }
            }

            Surface(
                color = CarbonSurface.copy(alpha = 0.88f),
                shape = RoundedCornerShape(50),
                border = BorderStroke(1.dp, GoldBright.copy(alpha = 0.65f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.MonetizationOn,
                        contentDescription = "Gold Coins",
                        tint = GoldBright,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "$coinBalance",
                        style = MaterialTheme.typography.labelLarge,
                        color = GoldBright,
                        modifier = Modifier.testTag("menu_coin_balance")
                    )
                }
            }
        }

        Text(
            text = "SUPER CAR\nWORLD",
            style = MaterialTheme.typography.displayLarge,
            color = CrispWhite,
            modifier = Modifier.testTag("game_title")
        )

        Surface(
            color = CarbonSurface.copy(alpha = 0.82f),
            shape = MaterialTheme.shapes.medium,
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.14f))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Column(modifier = Modifier.weight(1f, fill = false)) {
                    Text(
                        text = "$mapName • $carName",
                        style = MaterialTheme.typography.titleMedium,
                        color = CrispWhite,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "Ready on the starting grid",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MutedSlate
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.EmojiEvents,
                        contentDescription = "Best Score",
                        tint = ChampionshipGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "$bestScore",
                        style = MaterialTheme.typography.titleLarge,
                        color = ChampionshipGold
                    )
                }
            }
        }
    }
}

@Composable
private fun MenuActionButtons(
    onPlayClick: () -> Unit,
    onSelectMapClick: () -> Unit,
    onSelectCarClick: () -> Unit,
    onSettingsClick: () -> Unit
) {
    Button(
        onClick = onPlayClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(60.dp)
            .testTag("btn_play"),
        shape = MaterialTheme.shapes.medium,
        colors = ButtonDefaults.buttonColors(
            containerColor = RacingCrimson,
            contentColor = CrispWhite
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 8.dp)
    ) {
        Icon(
            imageVector = Icons.Default.PlayArrow,
            contentDescription = null,
            modifier = Modifier.size(28.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "PLAY",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SecondaryMenuButton(
            label = "SELECT MAP",
            icon = Icons.Default.Map,
            accentColor = ElectricCyan,
            onClick = onSelectMapClick,
            modifier = Modifier
                .weight(1f)
                .testTag("btn_select_map")
        )
        SecondaryMenuButton(
            label = "SELECT CAR",
            icon = Icons.Default.DirectionsCar,
            accentColor = ChampionshipGold,
            onClick = onSelectCarClick,
            modifier = Modifier
                .weight(1f)
                .testTag("btn_select_car")
        )
    }

    OutlinedButton(
        onClick = onSettingsClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(54.dp)
            .testTag("btn_settings"),
        shape = MaterialTheme.shapes.medium,
        border = BorderStroke(1.5.dp, Color.White.copy(alpha = 0.26f)),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = CarbonSurface.copy(alpha = 0.85f),
            contentColor = CrispWhite
        )
    ) {
        Icon(
            imageVector = Icons.Default.Settings,
            contentDescription = null,
            tint = MutedSlate,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "SETTINGS",
            style = MaterialTheme.typography.labelLarge
        )
    }
}

@Composable
private fun SecondaryMenuButton(
    label: String,
    icon: ImageVector,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        modifier = modifier.height(56.dp),
        shape = MaterialTheme.shapes.medium,
        colors = ButtonDefaults.buttonColors(
            containerColor = CarbonSurface.copy(alpha = 0.90f),
            contentColor = CrispWhite
        ),
        border = BorderStroke(1.5.dp, accentColor.copy(alpha = 0.65f))
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = accentColor,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
