package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.CarCatalog
import com.example.model.CarUpgrades
import com.example.model.GameMap
import com.example.model.GameSettings
import com.example.model.UpgradeStat
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.gameDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "super_car_world_prefs"
)

interface PreferencesSource {
    val settingsFlow: Flow<GameSettings>
    suspend fun setSelectedMap(map: GameMap)
    suspend fun setSelectedCar(carId: String)
    suspend fun setSoundEffectsEnabled(enabled: Boolean)
    suspend fun setMusicEnabled(enabled: Boolean)
    suspend fun updateBestScore(map: GameMap, score: Int)
    suspend fun resetBestScores()
    suspend fun addCoins(amount: Int)
    suspend fun purchaseUpgrade(carId: String, stat: UpgradeStat): Boolean
}

class GamePreferencesRepository(private val context: Context) : PreferencesSource {

    private object Keys {
        val SELECTED_MAP = stringPreferencesKey("selected_map")
        val SELECTED_CAR = stringPreferencesKey("selected_car")
        val SOUND_EFFECTS = booleanPreferencesKey("sound_effects_enabled")
        val MUSIC_ENABLED = booleanPreferencesKey("music_enabled")
        val BEST_CITY = intPreferencesKey("best_score_city")
        val BEST_VILLAGE = intPreferencesKey("best_score_village")
        val BEST_JUNGLE = intPreferencesKey("best_score_jungle")
        val COIN_BALANCE = intPreferencesKey("coin_balance")

        fun upgradeKey(carId: String, stat: UpgradeStat): Preferences.Key<Int> =
            intPreferencesKey("upgrade_${carId}_${stat.id}")
    }

    override val settingsFlow: Flow<GameSettings> = context.gameDataStore.data.map { prefs ->
        val upgradesMap = CarCatalog.allCars.associate { car ->
            car.id to CarUpgrades(
                topSpeedLevel = (prefs[Keys.upgradeKey(car.id, UpgradeStat.TOP_SPEED)] ?: 0)
                    .coerceIn(0, CarUpgrades.MAX_LEVEL),
                accelerationLevel = (prefs[Keys.upgradeKey(car.id, UpgradeStat.ACCELERATION)] ?: 0)
                    .coerceIn(0, CarUpgrades.MAX_LEVEL),
                brakingLevel = (prefs[Keys.upgradeKey(car.id, UpgradeStat.BRAKING)] ?: 0)
                    .coerceIn(0, CarUpgrades.MAX_LEVEL),
                handlingLevel = (prefs[Keys.upgradeKey(car.id, UpgradeStat.HANDLING)] ?: 0)
                    .coerceIn(0, CarUpgrades.MAX_LEVEL)
            )
        }

        GameSettings(
            soundEffectsEnabled = prefs[Keys.SOUND_EFFECTS] ?: true,
            musicEnabled = prefs[Keys.MUSIC_ENABLED] ?: true,
            selectedMap = GameMap.fromId(prefs[Keys.SELECTED_MAP]),
            selectedCarId = CarCatalog.fromId(prefs[Keys.SELECTED_CAR]).id,
            bestScores = mapOf(
                GameMap.CITY to (prefs[Keys.BEST_CITY] ?: 0),
                GameMap.VILLAGE to (prefs[Keys.BEST_VILLAGE] ?: 0),
                GameMap.JUNGLE to (prefs[Keys.BEST_JUNGLE] ?: 0)
            ),
            coinBalance = (prefs[Keys.COIN_BALANCE] ?: CarUpgrades.INITIAL_STARTER_COINS).coerceAtLeast(0),
            carUpgrades = upgradesMap
        )
    }

    override suspend fun setSelectedMap(map: GameMap) {
        context.gameDataStore.edit { prefs ->
            prefs[Keys.SELECTED_MAP] = map.id
        }
    }

    override suspend fun setSelectedCar(carId: String) {
        context.gameDataStore.edit { prefs ->
            prefs[Keys.SELECTED_CAR] = CarCatalog.fromId(carId).id
        }
    }

    override suspend fun setSoundEffectsEnabled(enabled: Boolean) {
        context.gameDataStore.edit { prefs ->
            prefs[Keys.SOUND_EFFECTS] = enabled
        }
    }

    override suspend fun setMusicEnabled(enabled: Boolean) {
        context.gameDataStore.edit { prefs ->
            prefs[Keys.MUSIC_ENABLED] = enabled
        }
    }

    override suspend fun updateBestScore(map: GameMap, score: Int) {
        context.gameDataStore.edit { prefs ->
            val key = when (map) {
                GameMap.CITY -> Keys.BEST_CITY
                GameMap.VILLAGE -> Keys.BEST_VILLAGE
                GameMap.JUNGLE -> Keys.BEST_JUNGLE
            }
            val current = prefs[key] ?: 0
            if (score > current) {
                prefs[key] = score
            }
        }
    }

    override suspend fun resetBestScores() {
        context.gameDataStore.edit { prefs ->
            prefs[Keys.BEST_CITY] = 0
            prefs[Keys.BEST_VILLAGE] = 0
            prefs[Keys.BEST_JUNGLE] = 0
        }
    }

    override suspend fun addCoins(amount: Int) {
        if (amount <= 0) return
        context.gameDataStore.edit { prefs ->
            val current = prefs[Keys.COIN_BALANCE] ?: CarUpgrades.INITIAL_STARTER_COINS
            prefs[Keys.COIN_BALANCE] = (current + amount).coerceAtLeast(0)
        }
    }

    override suspend fun purchaseUpgrade(carId: String, stat: UpgradeStat): Boolean {
        var purchased = false
        context.gameDataStore.edit { prefs ->
            val validCarId = CarCatalog.fromId(carId).id
            val key = Keys.upgradeKey(validCarId, stat)
            val currentLevel = (prefs[key] ?: 0).coerceIn(0, CarUpgrades.MAX_LEVEL)
            val cost = CarUpgrades.costForNextLevel(currentLevel) ?: return@edit
            val balance = (prefs[Keys.COIN_BALANCE] ?: CarUpgrades.INITIAL_STARTER_COINS).coerceAtLeast(0)
            if (balance >= cost) {
                prefs[Keys.COIN_BALANCE] = balance - cost
                prefs[key] = currentLevel + 1
                purchased = true
            }
        }
        return purchased
    }
}
