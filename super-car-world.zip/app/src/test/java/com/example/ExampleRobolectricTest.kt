package com.example

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorManager
import android.view.Surface
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.assertTextEquals
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.down
import androidx.compose.ui.test.up
import androidx.test.core.app.ApplicationProvider
import com.example.audio.SoundEngine
import com.example.data.PreferencesSource
import com.example.model.CarCatalog
import com.example.model.CarUpgrades
import com.example.model.GameMap
import com.example.model.GameSettings
import com.example.model.GoldCoin
import com.example.model.UpgradeStat
import com.example.ui.GameViewModel
import com.example.ui.theme.SuperCarWorldTheme
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config
import org.robolectric.shadows.SensorEventBuilder
import org.robolectric.shadows.ShadowDisplay
import org.robolectric.shadows.ShadowSensor

private class FakePreferencesSource : PreferencesSource {
    private val state = MutableStateFlow(GameSettings())
    override val settingsFlow: Flow<GameSettings> = state.asStateFlow()

    override suspend fun setSelectedMap(map: GameMap) {
        state.update { it.copy(selectedMap = map) }
    }

    override suspend fun setSelectedCar(carId: String) {
        state.update { it.copy(selectedCarId = carId) }
    }

    override suspend fun setSoundEffectsEnabled(enabled: Boolean) {
        state.update { it.copy(soundEffectsEnabled = enabled) }
    }

    override suspend fun setMusicEnabled(enabled: Boolean) {
        state.update { it.copy(musicEnabled = enabled) }
    }

    override suspend fun updateBestScore(map: GameMap, score: Int) {
        state.update { s ->
            val current = s.bestScores[map] ?: 0
            if (score > current) s.copy(bestScores = s.bestScores + (map to score)) else s
        }
    }

    override suspend fun resetBestScores() {
        state.update { it.copy(bestScores = emptyMap()) }
    }

    override suspend fun addCoins(amount: Int) {
        if (amount <= 0) return
        state.update { it.copy(coinBalance = it.coinBalance + amount) }
    }

    override suspend fun purchaseUpgrade(carId: String, stat: UpgradeStat): Boolean {
        var purchased = false
        state.update { s ->
            val currentUpgrades = s.upgradesForCar(carId)
            val level = currentUpgrades.levelFor(stat)
            val cost = CarUpgrades.costForNextLevel(level)
            if (cost != null && s.coinBalance >= cost) {
                purchased = true
                s.copy(
                    coinBalance = s.coinBalance - cost,
                    carUpgrades = s.carUpgrades + (carId to currentUpgrades.withIncremented(stat))
                )
            } else {
                s
            }
        }
        return purchased
    }
}

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w800dp-h360dp-land")
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    private fun createTestViewModel(): GameViewModel =
        GameViewModel(preferences = FakePreferencesSource(), soundEngine = SoundEngine())

    @Test
    fun appNameMatchesSuperCarWorld() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Super Car World", appName)
    }

    @Test
    fun mainMenuShowsTitleAndAllFourButtons() {
        val vm = createTestViewModel()
        composeTestRule.setContent {
            SuperCarWorldTheme {
                SuperCarWorldApp(viewModel = vm)
            }
        }
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("game_title").assertIsDisplayed()
        composeTestRule.onNodeWithTag("btn_play").assertIsDisplayed()
        composeTestRule.onNodeWithTag("btn_select_map").assertIsDisplayed()
        composeTestRule.onNodeWithTag("btn_select_car").assertIsDisplayed()
        composeTestRule.onNodeWithTag("btn_settings").assertIsDisplayed()
    }

    @Test
    fun allThreeMapsHaveSeparateSelectionButtonsAndDoNotAutoChange() {
        val vm = createTestViewModel()
        composeTestRule.setContent {
            SuperCarWorldTheme {
                SuperCarWorldApp(viewModel = vm)
            }
        }
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("btn_select_map").performClick()
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("map_button_city").performScrollTo().assertExists()
        composeTestRule.onNodeWithTag("map_button_village").performScrollTo().assertExists()
        composeTestRule.onNodeWithTag("map_button_jungle").performScrollTo().assertExists()

        // Explicitly select Village Map
        composeTestRule.onNodeWithTag("map_button_village").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        assertEquals(GameMap.VILLAGE, vm.settings.value.selectedMap)

        // Explicitly select Jungle Map
        composeTestRule.onNodeWithTag("map_button_jungle").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        assertEquals(GameMap.JUNGLE, vm.settings.value.selectedMap)

        // Start race on Jungle Map and step frames -> map must stay JUNGLE
        composeTestRule.onNodeWithTag("map_play_jungle").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        repeat(60) { vm.stepRaceFrame(0.016f) }
        assertEquals(GameMap.JUNGLE, vm.hudState.value.map)
    }

    @Test
    fun selectCarDefaultsToRedSportsCarAndSwitchesCars() {
        val vm = createTestViewModel()
        assertEquals(CarCatalog.RED_SPORTS_CAR.id, vm.settings.value.selectedCarId)

        composeTestRule.setContent {
            SuperCarWorldTheme {
                SuperCarWorldApp(viewModel = vm)
            }
        }
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("btn_select_car").performClick()
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("car_button_volt_gt").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        assertEquals(CarCatalog.VOLT_GT.id, vm.settings.value.selectedCarId)

        composeTestRule.onNodeWithTag("btn_race_selected_car").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        assertEquals(CarCatalog.VOLT_GT.id, vm.hudState.value.car.id)
    }

    @Test
    fun settingsTogglesWork() {
        val vm = createTestViewModel()
        composeTestRule.setContent {
            SuperCarWorldTheme {
                SuperCarWorldApp(viewModel = vm)
            }
        }
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("btn_settings").performClick()
        composeTestRule.waitForIdle()

        assertTrue(vm.settings.value.soundEffectsEnabled)
        assertTrue(vm.settings.value.musicEnabled)

        composeTestRule.onNodeWithTag("switch_sfx").performClick()
        composeTestRule.onNodeWithTag("switch_music").performClick()
        composeTestRule.waitForIdle()

        assertFalse(vm.settings.value.soundEffectsEnabled)
        assertFalse(vm.settings.value.musicEnabled)
    }

    @Test
    fun raceHudSupportsPauseResumeAndRestart() {
        val vm = createTestViewModel()
        composeTestRule.setContent {
            SuperCarWorldTheme {
                SuperCarWorldApp(viewModel = vm)
            }
        }
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("btn_play").performClick()
        composeTestRule.waitForIdle()

        // Verify minimal top HUD (Score, Coins, Speed), no swipe area, and big bottom BRAKE & RACE/GAS controls
        composeTestRule.onNodeWithTag("btn_steer_left").assertDoesNotExist()
        composeTestRule.onNodeWithTag("btn_steer_right").assertDoesNotExist()
        composeTestRule.onNodeWithTag("hud_timer").assertDoesNotExist()
        composeTestRule.onNodeWithTag("steering_swipe_area").assertDoesNotExist()
        composeTestRule.onNodeWithTag("btn_brake").assertIsDisplayed()
        composeTestRule.onNodeWithTag("btn_accelerate").assertIsDisplayed()
        composeTestRule.onNodeWithTag("hud_speed").assertIsDisplayed()
        composeTestRule.onNodeWithTag("hud_score").assertIsDisplayed()
        composeTestRule.onNodeWithTag("hud_coins").assertIsDisplayed()

        // Simulate driving for 1 second
        vm.updateAcceleratePressed(true)
        repeat(60) { vm.stepRaceFrame(0.016f) }
        assertTrue(vm.hudState.value.score > 0)
        assertTrue(vm.hudState.value.speedKmh > 0)

        // Pause
        composeTestRule.onNodeWithTag("btn_pause").performClick()
        composeTestRule.waitForIdle()
        assertTrue(vm.hudState.value.isPaused)
        composeTestRule.onNodeWithText("RACE PAUSED").assertIsDisplayed()

        // Resume
        composeTestRule.onNodeWithTag("btn_resume").performClick()
        composeTestRule.waitForIdle()
        assertFalse(vm.hudState.value.isPaused)

        // Pause again and Restart
        composeTestRule.onNodeWithTag("btn_pause").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("btn_restart").performScrollTo().performClick()
        composeTestRule.waitForIdle()

        assertFalse(vm.hudState.value.isPaused)
        assertEquals(0, vm.hudState.value.score)
        assertEquals(0, vm.hudState.value.speedKmh)
    }

    @Test
    fun starterCoinsAndPerCarUpgradesPurchaseFlowWorksInGarage() {
        val vm = createTestViewModel()
        assertEquals(150, vm.settings.value.coinBalance)

        composeTestRule.setContent {
            SuperCarWorldTheme {
                SuperCarWorldApp(viewModel = vm)
            }
        }
        composeTestRule.waitForIdle()

        // Main menu displays 150 starter coins
        composeTestRule.onNodeWithTag("menu_coin_balance").assertTextEquals("150")

        // Open Garage
        composeTestRule.onNodeWithTag("btn_select_car").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("garage_coin_balance").assertTextEquals("150")

        // Purchase Top Speed Lv 1 (50 coins) and Braking Lv 1 (50 coins) on Crimson Viper
        composeTestRule.onNodeWithTag("upgrade_button_top_speed").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        assertEquals(100, vm.settings.value.coinBalance)
        assertEquals(1, vm.settings.value.upgradesForCar(CarCatalog.RED_SPORTS_CAR.id).topSpeedLevel)

        composeTestRule.onNodeWithTag("upgrade_button_braking").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        assertEquals(50, vm.settings.value.coinBalance)
        assertEquals(1, vm.settings.value.upgradesForCar(CarCatalog.RED_SPORTS_CAR.id).brakingLevel)

        // Switch to Volt GT -> verify per-car upgrades start at 0
        composeTestRule.onNodeWithTag("car_button_volt_gt").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        assertEquals(0, vm.settings.value.upgradesForCar(CarCatalog.VOLT_GT.id).topSpeedLevel)
        composeTestRule.onNodeWithTag("upgrade_level_top_speed").performScrollTo().assertTextEquals("LV 0/5")

        // Purchase Handling Lv 1 (50 coins) on Volt GT -> wallet hits 0, button for another upgrade disables
        composeTestRule.onNodeWithTag("upgrade_button_handling").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        assertEquals(0, vm.settings.value.coinBalance)
        assertEquals(1, vm.settings.value.upgradesForCar(CarCatalog.VOLT_GT.id).handlingLevel)
        composeTestRule.onNodeWithTag("upgrade_button_top_speed").performScrollTo().assertIsNotEnabled()

        // Launch race and verify Volt GT receives its upgraded handling rating
        composeTestRule.onNodeWithTag("btn_race_selected_car").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        assertEquals(CarCatalog.VOLT_GT.handlingRating + 0.12f, vm.hudState.value.car.handlingRating, 0.001f)
    }

    @Test
    fun collectingGoldCoinsInRaceBanksIntoGarageWallet() {
        val vm = createTestViewModel()
        composeTestRule.setContent {
            SuperCarWorldTheme {
                SuperCarWorldApp(viewModel = vm)
            }
        }
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("btn_play").performClick()
        composeTestRule.waitForIdle()

        vm.raceEngine.goldCoins.clear()
        vm.raceEngine.goldCoins.add(
            GoldCoin(id = 9001, x = vm.raceEngine.playerX, z = vm.raceEngine.distanceZ + 0.4f)
        )
        vm.updateAcceleratePressed(true)
        vm.stepRaceFrame(0.016f)

        assertEquals(1, vm.hudState.value.coins)
        assertEquals(151, vm.settings.value.coinBalance)
    }

    @Test
    fun tiltSteeringAndGasBrakePedalsWorkAcrossAllMaps() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val shadowSensorManager = Shadows.shadowOf(sensorManager)
        val accelSensor = ShadowSensor.newInstance(Sensor.TYPE_ACCELEROMETER)
        shadowSensorManager.addSensor(accelSensor)
        Shadows.shadowOf(ShadowDisplay.getDefaultDisplay()).setRotation(Surface.ROTATION_90)

        val vm = createTestViewModel()
        composeTestRule.setContent {
            SuperCarWorldTheme {
                SuperCarWorldApp(viewModel = vm)
            }
        }
        composeTestRule.waitForIdle()

        val mapPlayTags = listOf(
            GameMap.CITY to "map_play_city",
            GameMap.VILLAGE to "map_play_village",
            GameMap.JUNGLE to "map_play_jungle"
        )

        for ((map, playTag) in mapPlayTags) {
            composeTestRule.onNodeWithTag("btn_select_map").performClick()
            composeTestRule.waitForIdle()

            composeTestRule.onNodeWithTag(playTag).performScrollTo().performClick()
            composeTestRule.waitForIdle()

            vm.raceEngine.trafficVehicles.clear()
            assertEquals("${map.displayName}: car starts at 0 km/h", 0, vm.hudState.value.speedKmh)

            // 1. Hold big RACE / GAS button -> car accelerates forward
            composeTestRule.onNodeWithTag("btn_accelerate").performTouchInput {
                down(center)
            }
            repeat(40) { vm.stepRaceFrame(0.016f) }
            val peakSpeed = vm.hudState.value.speedKmh
            assertTrue("${map.displayName}: pressing RACE button must increase speed", peakSpeed > 40)

            // 2. Tilt phone LEFT (ROTATION_90: ay < 0) while driving -> car steers left (+X)
            val startX = vm.raceEngine.playerX
            repeat(24) {
                shadowSensorManager.sendSensorEventToListeners(
                    SensorEventBuilder.newBuilder()
                        .setSensor(accelSensor)
                        .setValues(floatArrayOf(9.1f, -3.8f, 1.0f))
                        .build()
                )
                vm.stepRaceFrame(0.016f)
            }
            val afterLeftX = vm.raceEngine.playerX
            assertTrue(
                "${map.displayName}: tilting phone left must move car left (+X) (start=$startX, after=$afterLeftX)",
                afterLeftX > startX + 0.5f
            )

            // 3. Tilt phone RIGHT (ROTATION_90: ay > 0) while driving -> car steers right (-X)
            repeat(36) {
                shadowSensorManager.sendSensorEventToListeners(
                    SensorEventBuilder.newBuilder()
                        .setSensor(accelSensor)
                        .setValues(floatArrayOf(9.1f, 3.8f, 1.0f))
                        .build()
                )
                vm.stepRaceFrame(0.016f)
            }
            val afterRightX = vm.raceEngine.playerX
            assertTrue(
                "${map.displayName}: tilting phone right must move car right (-X) (left=$afterLeftX, right=$afterRightX)",
                afterRightX < afterLeftX - 1.0f
            )

            // Return phone level and release RACE / GAS -> slows down slowly
            repeat(10) {
                shadowSensorManager.sendSensorEventToListeners(
                    SensorEventBuilder.newBuilder()
                        .setSensor(accelSensor)
                        .setValues(floatArrayOf(9.8f, 0f, 0.5f))
                        .build()
                )
            }
            composeTestRule.onNodeWithTag("btn_accelerate").performTouchInput {
                up()
            }
            val speedAtRelease = vm.hudState.value.speedKmh
            repeat(20) { vm.stepRaceFrame(0.016f) }
            val coastSpeed = vm.hudState.value.speedKmh
            assertTrue(
                "${map.displayName}: releasing RACE must slow down slowly ($coastSpeed vs $speedAtRelease)",
                coastSpeed in 1 until speedAtRelease
            )

            // 4. Hold big BRAKE button -> car slows down and stops completely
            composeTestRule.onNodeWithTag("btn_brake").performTouchInput {
                down(center)
            }
            repeat(70) { vm.stepRaceFrame(0.016f) }
            composeTestRule.onNodeWithTag("btn_brake").performTouchInput {
                up()
            }
            assertEquals("${map.displayName}: pressing BRAKE must stop the car", 0, vm.hudState.value.speedKmh)

            composeTestRule.onNodeWithTag("btn_pause").performClick()
            composeTestRule.waitForIdle()
            composeTestRule.onNodeWithTag("btn_exit_menu").performScrollTo().performClick()
            composeTestRule.waitForIdle()
        }
    }
}
