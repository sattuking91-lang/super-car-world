package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

/**
 * Procedural real-time audio engine using Android AudioTrack for:
 * 1) Upbeat synthwave background music loop
 * 2) Speed-modulated sports car engine sound
 * 3) Coin collection chime, collision impact thud, brake chirp, and UI click SFX
 */
class SoundEngine {

    private val sampleRate = 22050
    private val isReleased = AtomicBoolean(false)
    private val sfxEnabled = AtomicBoolean(true)
    private val musicEnabled = AtomicBoolean(true)
    private val isAppResumed = AtomicBoolean(true)
    private val isRacingActive = AtomicBoolean(false)
    private val speedNormalized = AtomicReference(0f)

    private var musicThread: Thread? = null
    private val musicRunning = AtomicBoolean(false)

    private var engineThread: Thread? = null
    private val engineRunning = AtomicBoolean(false)

    private val pendingCoinEvents = AtomicInteger(0)
    private val pendingCrashEvents = AtomicInteger(0)
    private val pendingClickEvents = AtomicInteger(0)

    fun setSfxEnabled(enabled: Boolean) {
        sfxEnabled.set(enabled)
        syncEngineLoop()
    }

    fun setMusicEnabled(enabled: Boolean) {
        musicEnabled.set(enabled)
        syncMusicLoop()
    }

    fun onAppResumed(resumed: Boolean) {
        isAppResumed.set(resumed)
        syncMusicLoop()
        syncEngineLoop()
    }

    fun setRacingActive(active: Boolean, speedRatio: Float = 0f) {
        isRacingActive.set(active)
        speedNormalized.set(speedRatio.coerceIn(0f, 1f))
        syncEngineLoop()
    }

    fun updateSpeed(speedRatio: Float) {
        speedNormalized.set(speedRatio.coerceIn(0f, 1f))
    }

    fun playCoin() {
        if (sfxEnabled.get() && isAppResumed.get() && !isReleased.get()) {
            pendingCoinEvents.incrementAndGet()
            playToneAsync(frequencies = floatArrayOf(987.77f, 1318.51f), durationMs = 150, volume = 0.25f)
        }
    }

    fun playCollision() {
        if (sfxEnabled.get() && isAppResumed.get() && !isReleased.get()) {
            pendingCrashEvents.incrementAndGet()
            playCrashAsync()
        }
    }

    fun playClick() {
        if (sfxEnabled.get() && isAppResumed.get() && !isReleased.get()) {
            pendingClickEvents.incrementAndGet()
            playToneAsync(frequencies = floatArrayOf(640f), durationMs = 45, volume = 0.16f)
        }
    }

    fun playUpgrade() {
        if (sfxEnabled.get() && isAppResumed.get() && !isReleased.get()) {
            playToneAsync(
                frequencies = floatArrayOf(523.25f, 659.25f, 783.99f, 1046.50f),
                durationMs = 240,
                volume = 0.24f
            )
        }
    }

    fun release() {
        isReleased.set(true)
        stopMusicLoop()
        stopEngineLoop()
    }

    private fun syncMusicLoop() {
        val shouldPlay = musicEnabled.get() && isAppResumed.get() && !isReleased.get()
        if (shouldPlay && !musicRunning.get()) {
            startMusicLoop()
        } else if (!shouldPlay && musicRunning.get()) {
            stopMusicLoop()
        }
    }

    private fun syncEngineLoop() {
        val shouldPlay = sfxEnabled.get() && isAppResumed.get() && isRacingActive.get() && !isReleased.get()
        if (shouldPlay && !engineRunning.get()) {
            startEngineLoop()
        } else if (!shouldPlay && engineRunning.get()) {
            stopEngineLoop()
        }
    }

    private fun startMusicLoop() {
        if (!musicRunning.compareAndSet(false, true)) return
        musicThread = Thread {
            val track = createStreamTrack(sampleRate)
            if (track == null) {
                musicRunning.set(false)
                return@Thread
            }
            val chunkSamples = 1024
            val buffer = ShortArray(chunkSamples)
            // Bass & arpeggio synthwave notes (A minor / F / C / G progression)
            val bassNotes = floatArrayOf(110.0f, 110.0f, 87.31f, 87.31f, 130.81f, 130.81f, 98.0f, 98.0f)
            val arpNotes = floatArrayOf(
                440.0f, 523.25f, 659.25f, 523.25f,
                349.23f, 440.0f, 523.25f, 440.0f,
                523.25f, 659.25f, 783.99f, 659.25f,
                392.0f, 493.88f, 587.33f, 493.88f
            )
            var sampleIndex = 0L
            val stepSamples = sampleRate / 6 // ~180ms per 16th-note groove

            runCatching { track.play() }
            try {
                while (musicRunning.get() && !isReleased.get()) {
                    for (i in 0 until chunkSamples) {
                        val step = ((sampleIndex / stepSamples) % 16).toInt()
                        val localPos = (sampleIndex % stepSamples).toFloat() / stepSamples.toFloat()
                        val bassFreq = bassNotes[step / 2]
                        val arpFreq = arpNotes[step]

                        val t = sampleIndex.toDouble() / sampleRate.toDouble()
                        // Soft saw/triangle hybrid for bass + bell-like arp + light kick pulse
                        val bassEnv = (1f - localPos * 0.45f)
                        val arpEnv = (1f - localPos).let { it * it }
                        val bassWave = ((2.0 * ((t * bassFreq) % 1.0)) - 1.0) * 0.45 + sin(2.0 * PI * bassFreq * t) * 0.55
                        val arpWave = sin(2.0 * PI * arpFreq * t) * 0.65 + sin(4.0 * PI * arpFreq * t) * 0.25
                        val kickEnv = if (step % 4 == 0 && localPos < 0.35f) (1f - localPos / 0.35f) else 0f
                        val kick = sin(2.0 * PI * (120.0 - 70.0 * localPos) * t) * kickEnv

                        val mixed = (bassWave * bassEnv * 0.08 + arpWave * arpEnv * 0.055 + kick * 0.09)
                        buffer[i] = (mixed.coerceIn(-0.9, 0.9) * Short.MAX_VALUE).toInt().toShort()
                        sampleIndex++
                    }
                    track.write(buffer, 0, buffer.size)
                }
            } catch (_: Throwable) {
            } finally {
                runCatching {
                    track.pause()
                    track.flush()
                    track.release()
                }
                musicRunning.set(false)
            }
        }.apply {
            name = "SuperCarMusicThread"
            isDaemon = true
            start()
        }
    }

    private fun stopMusicLoop() {
        musicRunning.set(false)
        musicThread?.interrupt()
        musicThread = null
    }

    private fun startEngineLoop() {
        if (!engineRunning.compareAndSet(false, true)) return
        engineThread = Thread {
            val track = createStreamTrack(sampleRate)
            if (track == null) {
                engineRunning.set(false)
                return@Thread
            }
            val chunkSamples = 735
            val buffer = ShortArray(chunkSamples)
            var phase1 = 0.0
            var phase2 = 0.0
            runCatching { track.play() }
            try {
                while (engineRunning.get() && !isReleased.get()) {
                    val norm = speedNormalized.get().coerceIn(0f, 1f)
                    val baseFreq = 58.0 + norm * 145.0
                    val vol = 0.05 + norm * 0.07
                    for (i in 0 until chunkSamples) {
                        phase1 += baseFreq / sampleRate
                        phase2 += (baseFreq * 1.98) / sampleRate
                        if (phase1 >= 1.0) phase1 -= 1.0
                        if (phase2 >= 1.0) phase2 -= 1.0
                        val engineSample = (
                            sin(2.0 * PI * phase1) * 0.65 +
                            ((phase2 * 2.0) - 1.0) * 0.35
                        ) * vol
                        buffer[i] = (engineSample.coerceIn(-0.85, 0.85) * Short.MAX_VALUE).toInt().toShort()
                    }
                    track.write(buffer, 0, buffer.size)
                }
            } catch (_: Throwable) {
            } finally {
                runCatching {
                    track.pause()
                    track.flush()
                    track.release()
                }
                engineRunning.set(false)
            }
        }.apply {
            name = "SuperCarEngineThread"
            isDaemon = true
            start()
        }
    }

    private fun stopEngineLoop() {
        engineRunning.set(false)
        engineThread?.interrupt()
        engineThread = null
    }

    private fun playToneAsync(frequencies: FloatArray, durationMs: Int, volume: Float) {
        Thread {
            val totalSamples = (sampleRate * durationMs) / 1000
            val pcm = ShortArray(totalSamples)
            val perTone = totalSamples / frequencies.size.coerceAtLeast(1)
            for (i in 0 until totalSamples) {
                val freqIndex = (i / perTone).coerceAtMost(frequencies.lastIndex)
                val freq = frequencies[freqIndex]
                val env = 1.0 - (i.toDouble() / totalSamples.toDouble())
                val s = sin(2.0 * PI * freq * i / sampleRate) * volume * env
                pcm[i] = (s.coerceIn(-0.95, 0.95) * Short.MAX_VALUE).toInt().toShort()
            }
            playStaticBuffer(pcm)
        }.apply {
            isDaemon = true
            start()
        }
    }

    private fun playCrashAsync() {
        Thread {
            val totalSamples = (sampleRate * 260) / 1000
            val pcm = ShortArray(totalSamples)
            val rng = Random(42)
            for (i in 0 until totalSamples) {
                val env = (1.0 - i.toDouble() / totalSamples.toDouble()).let { it * it }
                val thud = sin(2.0 * PI * (95.0 - 55.0 * i / totalSamples) * i / sampleRate) * 0.55
                val crunch = (rng.nextDouble() * 2.0 - 1.0) * 0.45
                val s = (thud + crunch) * 0.35 * env
                pcm[i] = (s.coerceIn(-0.95, 0.95) * Short.MAX_VALUE).toInt().toShort()
            }
            playStaticBuffer(pcm)
        }.apply {
            isDaemon = true
            start()
        }
    }

    private fun createStreamTrack(rate: Int): AudioTrack? = runCatching {
        val minBuffer = AudioTrack.getMinBufferSize(
            rate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(2048)
        AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(minBuffer)
            .build()
    }.getOrNull()

    private fun playStaticBuffer(pcm: ShortArray) {
        runCatching {
            val byteSize = pcm.size * 2
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setTransferMode(AudioTrack.MODE_STATIC)
                .setBufferSizeInBytes(byteSize)
                .build()
            track.write(pcm, 0, pcm.size)
            track.play()
            Thread.sleep((pcm.size * 1000L / sampleRate) + 30L)
            track.release()
        }
    }
}
