package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val SuperCarDarkColorScheme = darkColorScheme(
    primary = RacingCrimson,
    onPrimary = CrispWhite,
    primaryContainer = RacingCrimsonDark,
    onPrimaryContainer = CrispWhite,
    secondary = ChampionshipGold,
    onSecondary = AsphaltDark,
    tertiary = ElectricCyan,
    onTertiary = AsphaltDark,
    background = AsphaltDark,
    onBackground = CrispWhite,
    surface = CarbonSurface,
    onSurface = CrispWhite,
    surfaceVariant = CarbonSurfaceElevated,
    onSurfaceVariant = MutedSlate,
    outline = DividerSlate
)

private val SuperCarShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun SuperCarWorldTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = SuperCarDarkColorScheme,
        typography = SuperCarTypography,
        shapes = SuperCarShapes,
        content = content
    )
}
