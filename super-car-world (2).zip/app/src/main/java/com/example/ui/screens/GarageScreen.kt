package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Garage
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.engine.Gl3DRenderer
import com.example.model.CarBodyStyle
import com.example.model.CarCatalog
import com.example.model.CarSpec
import com.example.model.GameSettings
import com.example.ui.components.GameGlViewport
import com.example.ui.theme.AsphaltDark
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.CarbonSurfaceElevated
import com.example.ui.theme.ChampionshipGold
import com.example.ui.theme.CrispWhite
import com.example.ui.theme.DividerSlate
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldJungle
import com.example.ui.theme.GoldBright
import com.example.ui.theme.MutedSlate
import com.example.ui.theme.RacingCrimson
import kotlinx.coroutines.delay

@Composable
fun GarageScreen(
    renderer: Gl3DRenderer,
    settings: GameSettings,
    onSelectCar: (CarSpec) -> Unit,
    onUnlockCar: (String) -> Boolean,
    onPreviewCar: (CarSpec) -> Unit,
    onRaceNow: () -> Unit,
    onBack: () -> Unit
) {
    val cars = CarCatalog.allCars
    val selectedCar = CarCatalog.fromId(settings.selectedCarId)
    var lockedNoticeText by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(lockedNoticeText) {
        if (lockedNoticeText != null) {
            delay(3200)
            lockedNoticeText = null
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // 1. Live 3D Big Shed Garage with ALL cars parked side-by-side (including Phantom Onyx & Thar)
        GameGlViewport(renderer = renderer, modifier = Modifier.fillMaxSize())

        // Subtle top & bottom gradient scrims so the big 3D shed & parked cars shine clearly
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        0.0f to AsphaltDark.copy(alpha = 0.72f),
                        0.26f to Color.Transparent,
                        0.66f to Color.Transparent,
                        1.0f to AsphaltDark.copy(alpha = 0.88f)
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Garage Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = CarbonSurface.copy(alpha = 0.85f),
                        shape = CircleShape,
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f))
                    ) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.testTag("btn_back_from_garage")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = CrispWhite
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Garage,
                                contentDescription = null,
                                tint = ChampionshipGold,
                                modifier = Modifier.size(22.dp)
                            )
                            Text(
                                text = "GARAGE",
                                style = MaterialTheme.typography.headlineMedium,
                                color = CrispWhite,
                                modifier = Modifier.testTag("garage_title")
                            )
                        }
                        Text(
                            text = "Tap any parked car to select for race • Active: ${selectedCar.name}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = CrispWhite.copy(alpha = 0.80f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.testTag("garage_active_car_label")
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = CarbonSurfaceElevated.copy(alpha = 0.92f),
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.5.dp, GoldBright.copy(alpha = 0.75f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.MonetizationOn,
                                contentDescription = "Coins",
                                tint = GoldBright,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${settings.coinBalance}",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = GoldBright
                            )
                        }
                    }

                    Button(
                        onClick = onRaceNow,
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("btn_garage_race_now"),
                        shape = MaterialTheme.shapes.medium,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = RacingCrimson,
                            contentColor = CrispWhite
                        )
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "RACE ${selectedCar.name.uppercase()}",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AnimatedVisibility(
                    visible = lockedNoticeText != null,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Surface(
                        color = CarbonSurfaceElevated.copy(alpha = 0.95f),
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.5.dp, GoldBright)
                    ) {
                        Text(
                            text = lockedNoticeText.orEmpty(),
                            style = MaterialTheme.typography.labelLarge,
                            color = GoldBright,
                            modifier = Modifier
                                .padding(horizontal = 16.dp, vertical = 7.dp)
                                .testTag("garage_locked_notice")
                        )
                    }
                }

                // Interactive parked vehicle bays along the garage shed floor
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally)
                ) {
                    cars.forEach { baseCar ->
                        val isUnlocked = settings.isCarUnlocked(baseCar.id)
                        val isSelected = settings.selectedCarId == baseCar.id
                        val effective = CarCatalog.withUpgrades(baseCar, settings.upgradesForCar(baseCar.id))
                        GarageBayCard(
                            car = baseCar,
                            effectiveSpeedKmh = effective.maxSpeedKmh.toInt(),
                            isUnlocked = isUnlocked,
                            isSelected = isSelected,
                            canAffordUnlock = settings.coinBalance >= baseCar.unlockCostCoins,
                            onClick = {
                                if (isUnlocked) {
                                    lockedNoticeText = null
                                    onSelectCar(baseCar)
                                } else {
                                    onPreviewCar(baseCar)
                                    val unlockedNow = onUnlockCar(baseCar.id)
                                    if (unlockedNow) {
                                        lockedNoticeText = null
                                    } else {
                                        lockedNoticeText =
                                            "${baseCar.name} costs ${baseCar.unlockCostCoins} coins to unlock (You have ${settings.coinBalance})"
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GarageBayCard(
    car: CarSpec,
    effectiveSpeedKmh: Int,
    isUnlocked: Boolean,
    isSelected: Boolean,
    canAffordUnlock: Boolean,
    onClick: () -> Unit
) {
    val swatch = Color(
        red = car.primaryColorRgb.first,
        green = car.primaryColorRgb.second,
        blue = car.primaryColorRgb.third
    )
    val accentBorder = when {
        isSelected -> ChampionshipGold
        !isUnlocked && canAffordUnlock -> GoldBright
        !isUnlocked -> DividerSlate
        else -> ElectricCyan.copy(alpha = 0.55f)
    }

    Card(
        onClick = onClick,
        modifier = Modifier
            .widthIn(min = 136.dp, max = 164.dp)
            .testTag("garage_car_${car.id}"),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) {
                CarbonSurfaceElevated.copy(alpha = 0.94f)
            } else {
                CarbonSurface.copy(alpha = 0.86f)
            }
        ),
        border = BorderStroke(
            width = if (isSelected) 2.5.dp else 1.2.dp,
            color = accentBorder
        )
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = swatch,
                    shape = CircleShape,
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.45f)),
                    modifier = Modifier.size(18.dp)
                ) {}

                Surface(
                    color = AsphaltDark.copy(alpha = 0.72f),
                    shape = RoundedCornerShape(50)
                ) {
                    Text(
                        text = if (car.bodyStyle == CarBodyStyle.BOXY_SUV) "SUV" else "SPORTS",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (car.bodyStyle == CarBodyStyle.BOXY_SUV) GoldBright else ElectricCyan,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Text(
                text = car.name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = CrispWhite,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = "$effectiveSpeedKmh km/h",
                style = MaterialTheme.typography.labelSmall,
                color = MutedSlate
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                when {
                    isSelected -> {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Selected for race",
                            tint = EmeraldJungle,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = "SELECTED",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldJungle
                        )
                    }
                    isUnlocked -> {
                        Text(
                            text = "TAP TO SELECT",
                            style = MaterialTheme.typography.labelSmall,
                            color = ElectricCyan
                        )
                    }
                    else -> {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Locked",
                            tint = GoldBright,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "${car.unlockCostCoins} COINS",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = GoldBright
                        )
                    }
                }
            }
        }
    }
}
