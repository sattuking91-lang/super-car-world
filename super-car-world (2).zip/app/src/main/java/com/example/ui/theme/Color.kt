package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AsphaltDark = Color(0xFF0A0E17)
val CarbonSurface = Color(0xFF131A29)
val CarbonSurfaceElevated = Color(0xFF1C2538)
val RacingCrimson = Color(0xFFEF4444)
val RacingCrimsonDark = Color(0xFFB91C1C)
val ChampionshipGold = Color(0xFFF59E0B)
val GoldBright = Color(0xFFFACC15)
val ElectricCyan = Color(0xFF06B6D4)
val EmeraldJungle = Color(0xFF10B981)
val VillageSun = Color(0xFF38BDF8)
val CrispWhite = Color(0xFFF8FAFC)
val MutedSlate = Color(0xFF94A3B8)
val DividerSlate = Color(0xFF2A364F)
