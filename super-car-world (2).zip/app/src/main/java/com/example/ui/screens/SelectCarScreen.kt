package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.engine.Gl3DRenderer
import com.example.model.CarCatalog
import com.example.model.CarSpec
import com.example.model.CarUpgrades
import com.example.model.GameSettings
import com.example.model.UpgradeStat
import com.example.ui.components.GameGlViewport
import com.example.ui.theme.AsphaltDark
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.CarbonSurfaceElevated
import com.example.ui.theme.ChampionshipGold
import com.example.ui.theme.CrispWhite
import com.example.ui.theme.DividerSlate
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldJungle
import com.example.ui.theme.GoldBright
import com.example.ui.theme.MutedSlate
import com.example.ui.theme.RacingCrimson
import java.util.Locale

@Composable
fun SelectCarScreen(
    renderer: Gl3DRenderer,
    settings: GameSettings,
    onSelectCar: (CarSpec) -> Unit,
    onPreviewCar: (CarSpec) -> Unit,
    onUnlockCar: (String) -> Boolean,
    onPurchaseUpgrade: (String, UpgradeStat) -> Unit,
    onRotateShowroom: (Float) -> Unit,
    onRaceNow: (CarSpec) -> Unit,
    onBack: () -> Unit
) {
    var previewCarId by remember(settings.selectedCarId) { mutableStateOf(settings.selectedCarId) }
    val baseCar = CarCatalog.fromId(previewCarId)
    val isPreviewUnlocked = settings.isCarUnlocked(baseCar.id)
    val upgrades = settings.upgradesForCar(baseCar.id)
    val effectiveCar = CarCatalog.withUpgrades(baseCar, upgrades)
    val cars = CarCatalog.allCars

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(AsphaltDark, Color(0xFF101829))))
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        // Header with Gold Coin Wallet
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("btn_back_from_car")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = CrispWhite
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(
                        text = "GARAGE & UPGRADES",
                        style = MaterialTheme.typography.headlineMedium,
                        color = CrispWhite,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "Select a car & spend gold coins to tune",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MutedSlate,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Persistent Gold Coin Wallet Pill
            Surface(
                color = CarbonSurfaceElevated,
                shape = RoundedCornerShape(50),
                border = BorderStroke(1.5.dp, GoldBright.copy(alpha = 0.75f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.MonetizationOn,
                        contentDescription = "Gold Coin Wallet",
                        tint = GoldBright,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "${settings.coinBalance}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = GoldBright,
                        modifier = Modifier.testTag("garage_coin_balance")
                    )
                }
            }
        }

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val isLandscape = maxWidth > maxHeight
            if (isLandscape) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ShowroomViewport(
                            renderer = renderer,
                            car = effectiveCar,
                            upgrades = upgrades,
                            onRotateShowroom = onRotateShowroom,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(190.dp)
                        )
                        CarSelectorList(
                            cars = cars,
                            previewCar = effectiveCar,
                            settings = settings,
                            onCarCardClick = { clicked ->
                                previewCarId = clicked.id
                                if (settings.isCarUnlocked(clicked.id)) {
                                    onSelectCar(clicked)
                                } else {
                                    onPreviewCar(clicked)
                                }
                            }
                        )
                    }

                    Column(
                        modifier = Modifier
                            .weight(1.1f)
                            .fillMaxHeight()
                            .verticalScroll(rememberScrollState())
                            .padding(bottom = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CarStatsPanel(
                            baseCar = baseCar,
                            effectiveCar = effectiveCar,
                            upgrades = upgrades
                        )
                        if (isPreviewUnlocked) {
                            CarUpgradesPanel(
                                carId = baseCar.id,
                                upgrades = upgrades,
                                coinBalance = settings.coinBalance,
                                onPurchaseUpgrade = onPurchaseUpgrade
                            )
                            RaceCarButton(
                                car = effectiveCar,
                                onRaceNow = { onRaceNow(effectiveCar) }
                            )
                        } else {
                            UnlockCarPanel(
                                car = baseCar,
                                coinBalance = settings.coinBalance,
                                onUnlockClick = { onUnlockCar(baseCar.id) }
                            )
                        }
                    }
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(bottom = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ShowroomViewport(
                        renderer = renderer,
                        car = effectiveCar,
                        upgrades = upgrades,
                        onRotateShowroom = onRotateShowroom,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(190.dp)
                            .padding(horizontal = 16.dp)
                    )

                    CarSelectorList(
                        cars = cars,
                        previewCar = effectiveCar,
                        settings = settings,
                        onCarCardClick = { clicked ->
                            previewCarId = clicked.id
                            if (settings.isCarUnlocked(clicked.id)) {
                                onSelectCar(clicked)
                            } else {
                                onPreviewCar(clicked)
                            }
                        },
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )

                    CarStatsPanel(
                        baseCar = baseCar,
                        effectiveCar = effectiveCar,
                        upgrades = upgrades,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )

                    if (isPreviewUnlocked) {
                        CarUpgradesPanel(
                            carId = baseCar.id,
                            upgrades = upgrades,
                            coinBalance = settings.coinBalance,
                            onPurchaseUpgrade = onPurchaseUpgrade,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )

                        RaceCarButton(
                            car = effectiveCar,
                            onRaceNow = { onRaceNow(effectiveCar) },
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    } else {
                        UnlockCarPanel(
                            car = baseCar,
                            coinBalance = settings.coinBalance,
                            onUnlockClick = { onUnlockCar(baseCar.id) },
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ShowroomViewport(
    renderer: Gl3DRenderer,
    car: CarSpec,
    upgrades: CarUpgrades,
    onRotateShowroom: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(MaterialTheme.shapes.large)
            .pointerInput(Unit) {
                detectHorizontalDragGestures { _, dragAmount ->
                    onRotateShowroom(dragAmount)
                }
            },
        shape = MaterialTheme.shapes.large,
        border = BorderStroke(1.dp, DividerSlate),
        color = CarbonSurface
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            GameGlViewport(renderer = renderer, modifier = Modifier.fillMaxSize())

            Surface(
                color = AsphaltDark.copy(alpha = 0.72f),
                shape = RoundedCornerShape(50),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.TouchApp,
                        contentDescription = null,
                        tint = ElectricCyan,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "SWIPE TO ROTATE 3D MODEL",
                        style = MaterialTheme.typography.labelSmall,
                        color = CrispWhite
                    )
                }
            }

            if (upgrades.totalLevels() > 0) {
                Surface(
                    color = EmeraldJungle.copy(alpha = 0.90f),
                    shape = RoundedCornerShape(50),
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                ) {
                    Text(
                        text = "TUNED ${upgrades.totalLevels()}/20",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = AsphaltDark,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }

            Surface(
                color = AsphaltDark.copy(alpha = 0.78f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(12.dp)
            ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Text(
                        text = car.name,
                        style = MaterialTheme.typography.titleLarge,
                        color = CrispWhite
                    )
                    Text(
                        text = "${car.maxSpeedKmh.toInt()} KM/H TOP SPEED",
                        style = MaterialTheme.typography.labelSmall,
                        color = ChampionshipGold
                    )
                }
            }
        }
    }
}

@Composable
private fun CarStatsPanel(
    baseCar: CarSpec,
    effectiveCar: CarSpec,
    upgrades: CarUpgrades,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = CarbonSurface),
        border = BorderStroke(1.dp, DividerSlate)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Text(
                text = effectiveCar.tagline,
                style = MaterialTheme.typography.titleMedium,
                color = CrispWhite
            )
            StatBarRow(
                label = "TOP SPEED",
                valueText = "${effectiveCar.maxSpeedKmh.toInt()} km/h",
                bonusText = if (upgrades.topSpeedLevel > 0) "+${(effectiveCar.maxSpeedKmh - baseCar.maxSpeedKmh).toInt()}" else null,
                rating = effectiveCar.speedRating,
                color = RacingCrimson
            )
            StatBarRow(
                label = "ACCELERATION",
                valueText = String.format(Locale.US, "%.1f m/s²", effectiveCar.accelerationRate),
                bonusText = if (upgrades.accelerationLevel > 0) String.format(Locale.US, "+%.1f", effectiveCar.accelerationRate - baseCar.accelerationRate) else null,
                rating = effectiveCar.accelRating,
                color = ChampionshipGold
            )
            StatBarRow(
                label = "BRAKING",
                valueText = String.format(Locale.US, "%.1f m/s²", effectiveCar.brakingDeceleration),
                bonusText = if (upgrades.brakingLevel > 0) String.format(Locale.US, "+%.1f", effectiveCar.brakingDeceleration - baseCar.brakingDeceleration) else null,
                rating = effectiveCar.brakingRating,
                color = EmeraldJungle
            )
            StatBarRow(
                label = "HANDLING",
                valueText = String.format(Locale.US, "%.2fx", effectiveCar.handlingRating),
                bonusText = if (upgrades.handlingLevel > 0) String.format(Locale.US, "+%.2fx", effectiveCar.handlingRating - baseCar.handlingRating) else null,
                rating = effectiveCar.handlingScore,
                color = ElectricCyan
            )
        }
    }
}

@Composable
private fun StatBarRow(
    label: String,
    valueText: String,
    bonusText: String?,
    rating: Int,
    color: Color
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = MutedSlate)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (bonusText != null) {
                    Text(
                        text = bonusText,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldJungle
                    )
                }
                Text(text = valueText, style = MaterialTheme.typography.labelSmall, color = CrispWhite)
            }
        }
        LinearProgressIndicator(
            progress = { (rating / 100f).coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(7.dp)
                .clip(RoundedCornerShape(50)),
            color = color,
            trackColor = CarbonSurfaceElevated
        )
    }
}

@Composable
private fun CarUpgradesPanel(
    carId: String,
    upgrades: CarUpgrades,
    coinBalance: Int,
    onPurchaseUpgrade: (String, UpgradeStat) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Build,
                contentDescription = null,
                tint = GoldBright,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = "PERFORMANCE UPGRADES",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = CrispWhite
            )
        }

        UpgradeStat.entries.forEach { stat ->
            val currentLevel = upgrades.levelFor(stat)
            val nextCost = CarUpgrades.costForNextLevel(currentLevel)
            val isMaxed = nextCost == null
            val canAfford = nextCost != null && coinBalance >= nextCost

            val (icon, accent) = when (stat) {
                UpgradeStat.TOP_SPEED -> Icons.Default.Speed to RacingCrimson
                UpgradeStat.ACCELERATION -> Icons.Default.ElectricBolt to ChampionshipGold
                UpgradeStat.BRAKING -> Icons.Default.Security to EmeraldJungle
                UpgradeStat.HANDLING -> Icons.Default.Tune to ElectricCyan
            }

            UpgradeStatCard(
                stat = stat,
                icon = icon,
                accentColor = accent,
                currentLevel = currentLevel,
                nextCost = nextCost,
                isMaxed = isMaxed,
                canAfford = canAfford,
                onUpgradeClick = { onPurchaseUpgrade(carId, stat) }
            )
        }
    }
}

@Composable
private fun UpgradeStatCard(
    stat: UpgradeStat,
    icon: ImageVector,
    accentColor: Color,
    currentLevel: Int,
    nextCost: Int?,
    isMaxed: Boolean,
    canAfford: Boolean,
    onUpgradeClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("upgrade_card_${stat.id}"),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = CarbonSurface),
        border = BorderStroke(1.dp, DividerSlate)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = stat.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = CrispWhite
                    )
                    Text(
                        text = "LV $currentLevel/${CarUpgrades.MAX_LEVEL}",
                        style = MaterialTheme.typography.labelSmall,
                        color = accentColor,
                        modifier = Modifier.testTag("upgrade_level_${stat.id}")
                    )
                }

                Text(
                    text = if (isMaxed) "Maximum tier reached" else stat.boostDescription,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedSlate
                )

                // 5-segment tier progress bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    for (tier in 1..CarUpgrades.MAX_LEVEL) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(6.dp)
                                .clip(RoundedCornerShape(50))
                                .background(
                                    if (tier <= currentLevel) accentColor else CarbonSurfaceElevated
                                )
                        )
                    }
                }
            }

            Button(
                onClick = onUpgradeClick,
                enabled = !isMaxed && canAfford,
                modifier = Modifier
                    .height(48.dp)
                    .testTag("upgrade_button_${stat.id}"),
                shape = MaterialTheme.shapes.small,
                colors = ButtonDefaults.buttonColors(
                    containerColor = GoldBright,
                    contentColor = AsphaltDark,
                    disabledContainerColor = if (isMaxed) EmeraldJungle.copy(alpha = 0.25f) else CarbonSurfaceElevated,
                    disabledContentColor = if (isMaxed) EmeraldJungle else MutedSlate
                )
            ) {
                if (isMaxed) {
                    Text(
                        text = "MAXED",
                        style = MaterialTheme.typography.labelLarge
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.MonetizationOn,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "$nextCost",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun UnlockCarPanel(
    car: CarSpec,
    coinBalance: Int,
    onUnlockClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val canAfford = coinBalance >= car.unlockCostCoins
    val missing = (car.unlockCostCoins - coinBalance).coerceAtLeast(0)

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = CarbonSurface),
        border = BorderStroke(1.5.dp, GoldBright.copy(alpha = 0.7f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Locked Vehicle",
                    tint = GoldBright,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = "UNLOCK ${car.name.uppercase()} • ${car.unlockCostCoins} COINS",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = CrispWhite
                )
            }

            Text(
                text = if (canAfford) {
                    "You have enough Gold Coins to add ${car.name} to your garage!"
                } else {
                    "Collect $missing more Gold Coins in races to unlock ${car.name}."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MutedSlate
            )

            Button(
                onClick = onUnlockClick,
                enabled = canAfford,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("btn_unlock_car"),
                shape = MaterialTheme.shapes.medium,
                colors = ButtonDefaults.buttonColors(
                    containerColor = GoldBright,
                    contentColor = AsphaltDark,
                    disabledContainerColor = CarbonSurfaceElevated,
                    disabledContentColor = MutedSlate
                )
            ) {
                Icon(imageVector = Icons.Default.MonetizationOn, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "UNLOCK FOR ${car.unlockCostCoins} COINS",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun CarSelectorList(
    cars: List<CarSpec>,
    previewCar: CarSpec,
    settings: GameSettings,
    onCarCardClick: (CarSpec) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        cars.chunked(2).forEach { rowCars ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                rowCars.forEach { baseCar ->
                    val carUpgrades = settings.upgradesForCar(baseCar.id)
                    val effectiveCar = CarCatalog.withUpgrades(baseCar, carUpgrades)
                    val isUnlocked = settings.isCarUnlocked(baseCar.id)
                    val isPreviewed = baseCar.id == previewCar.id
                    val isEquipped = baseCar.id == settings.selectedCarId
                    val swatch = Color(
                        red = baseCar.primaryColorRgb.first,
                        green = baseCar.primaryColorRgb.second,
                        blue = baseCar.primaryColorRgb.third
                    )
                    Card(
                        onClick = { onCarCardClick(baseCar) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("car_button_${baseCar.id}"),
                        shape = MaterialTheme.shapes.medium,
                        colors = CardDefaults.cardColors(
                            containerColor = if (isPreviewed) CarbonSurfaceElevated else CarbonSurface
                        ),
                        border = BorderStroke(
                            width = if (isPreviewed) 2.dp else 1.dp,
                            color = when {
                                isPreviewed && !isUnlocked -> GoldBright
                                isPreviewed -> ChampionshipGold
                                else -> DividerSlate
                            }
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = swatch,
                                    shape = CircleShape,
                                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.45f)),
                                    modifier = Modifier.size(22.dp)
                                ) {}
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    if (!isUnlocked) {
                                        Icon(
                                            imageVector = Icons.Default.Lock,
                                            contentDescription = "Locked",
                                            tint = GoldBright,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = "${baseCar.unlockCostCoins}",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = GoldBright
                                        )
                                    } else {
                                        if (carUpgrades.totalLevels() > 0) {
                                            Text(
                                                text = "LV ${carUpgrades.totalLevels()}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = EmeraldJungle
                                            )
                                        }
                                        if (isEquipped) {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = "Selected",
                                                tint = ChampionshipGold,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                            Text(
                                text = baseCar.name,
                                style = MaterialTheme.typography.titleMedium,
                                color = CrispWhite,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${effectiveCar.maxSpeedKmh.toInt()} km/h",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MutedSlate
                            )
                        }
                    }
                }
                if (rowCars.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun RaceCarButton(
    car: CarSpec,
    onRaceNow: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onRaceNow,
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp)
            .testTag("btn_race_selected_car"),
        shape = MaterialTheme.shapes.medium,
        colors = ButtonDefaults.buttonColors(
            containerColor = RacingCrimson,
            contentColor = CrispWhite
        )
    ) {
        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "DRIVE ${car.name.uppercase()}",
            style = MaterialTheme.typography.labelLarge
        )
    }
}
