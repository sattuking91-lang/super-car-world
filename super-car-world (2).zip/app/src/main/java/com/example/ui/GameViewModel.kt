package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.audio.SoundEngine
import com.example.data.GamePreferencesRepository
import com.example.data.PreferencesSource
import com.example.engine.Gl3DRenderer
import com.example.engine.RaceEngine
import com.example.engine.RenderMode
import com.example.model.CarCatalog
import com.example.model.CarSpec
import com.example.model.CarUpgrades
import com.example.model.ControlInput
import com.example.model.GameMap
import com.example.model.GameSettings
import com.example.model.RaceHudState
import com.example.model.UpgradeStat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicReference

class GameViewModel(
    private val preferences: PreferencesSource,
    private val soundEngine: SoundEngine = SoundEngine()
) : ViewModel() {

    private val raceLock = Any()
    val raceEngine = RaceEngine()
    val renderer = Gl3DRenderer(raceEngine)

    private val _settings = MutableStateFlow(GameSettings())
    val settings: StateFlow<GameSettings> = _settings.asStateFlow()

    private val _hudState = MutableStateFlow(raceEngine.getHudState())
    val hudState: StateFlow<RaceHudState> = _hudState.asStateFlow()

    private val _isRacingScreen = MutableStateFlow(false)
    val isRacingScreen: StateFlow<Boolean> = _isRacingScreen.asStateFlow()

    private val inputRef = AtomicReference(ControlInput())

    init {
        raceEngine.onCoinCollected = {
            soundEngine.playCoin()
            _settings.update { it.copy(coinBalance = it.coinBalance + 1) }
            viewModelScope.launch {
                preferences.addCoins(1)
            }
        }
        raceEngine.onCollision = {
            soundEngine.playCollision()
        }
        raceEngine.onNewBestScore = { map, newBest ->
            viewModelScope.launch {
                preferences.updateBestScore(map, newBest)
            }
        }

        renderer.onFrameTick = { dt ->
            stepRaceFrame(dt)
        }

        viewModelScope.launch {
            preferences.settingsFlow.collect { loaded ->
                _settings.value = loaded
                soundEngine.setSfxEnabled(loaded.soundEffectsEnabled)
                soundEngine.setMusicEnabled(loaded.musicEnabled)
                val effectiveSelectedCar = resolveEffectiveCar(loaded.selectedCarId, loaded)
                renderer.showcaseMap = loaded.selectedMap
                renderer.showcaseCar = effectiveSelectedCar
                if (!_isRacingScreen.value) {
                    synchronized(raceLock) {
                        val mapBest = loaded.bestScores[loaded.selectedMap] ?: 0
                        raceEngine.reset(
                            map = loaded.selectedMap,
                            car = effectiveSelectedCar,
                            mapBestScore = mapBest
                        )
                        _hudState.value = raceEngine.getHudState()
                    }
                }
            }
        }
    }

    fun selectMap(map: GameMap) {
        soundEngine.playClick()
        renderer.showcaseMap = map
        _settings.update { it.copy(selectedMap = map) }
        viewModelScope.launch {
            preferences.setSelectedMap(map)
        }
    }

    fun selectCar(car: CarSpec) {
        val canonical = CarCatalog.fromId(car.id)
        val effective = resolveEffectiveCar(canonical.id)
        renderer.showcaseCar = effective
        renderer.garageFocusedCarId = canonical.id

        if (!_settings.value.isCarUnlocked(canonical.id)) {
            soundEngine.playClick()
            return
        }

        soundEngine.playClick()
        _settings.update { it.copy(selectedCarId = canonical.id) }
        viewModelScope.launch {
            preferences.setSelectedCar(canonical.id)
        }
    }

    fun previewCarInShowroom(car: CarSpec) {
        val canonical = CarCatalog.fromId(car.id)
        val effective = resolveEffectiveCar(canonical.id)
        renderer.showcaseCar = effective
        renderer.garageFocusedCarId = canonical.id
    }

    fun unlockCar(carId: String): Boolean {
        val current = _settings.value
        val spec = CarCatalog.fromId(carId)
        if (current.isCarUnlocked(spec.id)) {
            selectCar(spec)
            return true
        }
        if (current.coinBalance < spec.unlockCostCoins) {
            soundEngine.playClick()
            return false
        }

        val updated = current.copy(
            coinBalance = current.coinBalance - spec.unlockCostCoins,
            unlockedCarIds = current.unlockedCarIds + spec.id,
            selectedCarId = spec.id
        )
        _settings.value = updated
        val effective = resolveEffectiveCar(spec.id, updated)
        renderer.showcaseCar = effective
        renderer.garageFocusedCarId = spec.id
        soundEngine.playUpgrade()

        if (!_isRacingScreen.value) {
            synchronized(raceLock) {
                raceEngine.reset(
                    map = updated.selectedMap,
                    car = effective,
                    mapBestScore = updated.bestScores[updated.selectedMap] ?: 0
                )
                _hudState.value = raceEngine.getHudState()
            }
        }

        viewModelScope.launch {
            preferences.unlockCar(spec.id)
        }
        return true
    }

    fun purchaseUpgrade(carId: String, stat: UpgradeStat) {
        val currentSettings = _settings.value
        val validCarId = CarCatalog.fromId(carId).id
        val currentUpgrades = currentSettings.upgradesForCar(validCarId)
        val currentLevel = currentUpgrades.levelFor(stat)
        val cost = CarUpgrades.costForNextLevel(currentLevel) ?: return
        if (currentSettings.coinBalance < cost) {
            soundEngine.playClick()
            return
        }

        val updatedUpgrades = currentUpgrades.withIncremented(stat)
        val updatedSettings = currentSettings.copy(
            coinBalance = currentSettings.coinBalance - cost,
            carUpgrades = currentSettings.carUpgrades + (validCarId to updatedUpgrades)
        )
        _settings.value = updatedSettings
        soundEngine.playUpgrade()

        if (updatedSettings.selectedCarId == validCarId) {
            val effective = resolveEffectiveCar(validCarId, updatedSettings)
            renderer.showcaseCar = effective
            if (!_isRacingScreen.value) {
                synchronized(raceLock) {
                    raceEngine.reset(
                        map = updatedSettings.selectedMap,
                        car = effective,
                        mapBestScore = updatedSettings.bestScores[updatedSettings.selectedMap] ?: 0
                    )
                    _hudState.value = raceEngine.getHudState()
                }
            }
        }

        viewModelScope.launch {
            preferences.purchaseUpgrade(validCarId, stat)
        }
    }

    fun resolveEffectiveCar(
        carId: String = _settings.value.selectedCarId,
        settingsSnapshot: GameSettings = _settings.value
    ): CarSpec {
        val base = CarCatalog.fromId(carId)
        return CarCatalog.withUpgrades(base, settingsSnapshot.upgradesForCar(base.id))
    }

    fun setSoundEffectsEnabled(enabled: Boolean) {
        _settings.update { it.copy(soundEffectsEnabled = enabled) }
        soundEngine.setSfxEnabled(enabled)
        if (enabled) soundEngine.playClick()
        viewModelScope.launch {
            preferences.setSoundEffectsEnabled(enabled)
        }
    }

    fun setMusicEnabled(enabled: Boolean) {
        soundEngine.playClick()
        _settings.update { it.copy(musicEnabled = enabled) }
        soundEngine.setMusicEnabled(enabled)
        viewModelScope.launch {
            preferences.setMusicEnabled(enabled)
        }
    }

    fun resetBestScores() {
        soundEngine.playClick()
        _settings.update { it.copy(bestScores = emptyMap()) }
        viewModelScope.launch {
            preferences.resetBestScores()
        }
    }

    fun playClickSound() {
        soundEngine.playClick()
    }

    fun startRace(mapOverride: GameMap? = null, carOverride: CarSpec? = null) {
        soundEngine.playClick()
        val chosenMap = mapOverride ?: _settings.value.selectedMap
        val candidateCarId = carOverride?.id ?: _settings.value.selectedCarId
        val chosenCarId = if (_settings.value.isCarUnlocked(candidateCarId)) {
            candidateCarId
        } else {
            _settings.value.selectedCarId
        }
        val chosenCar = resolveEffectiveCar(chosenCarId)
        val bestForMap = _settings.value.bestScores[chosenMap] ?: 0

        synchronized(raceLock) {
            inputRef.set(ControlInput())
            raceEngine.reset(map = chosenMap, car = chosenCar, mapBestScore = bestForMap)
            _hudState.value = raceEngine.getHudState()
        }
        renderer.showcaseMap = chosenMap
        renderer.showcaseCar = chosenCar
        renderer.renderMode = RenderMode.RACE
        _isRacingScreen.value = true
        soundEngine.setRacingActive(true, 0f)
    }

    fun restartRace() {
        soundEngine.playClick()
        val currentMap = raceEngine.currentMap
        val currentCar = resolveEffectiveCar(raceEngine.currentCar.id)
        val bestForMap = maxOf(_settings.value.bestScores[currentMap] ?: 0, raceEngine.bestScore)
        synchronized(raceLock) {
            inputRef.set(ControlInput())
            raceEngine.reset(map = currentMap, car = currentCar, mapBestScore = bestForMap)
            _hudState.value = raceEngine.getHudState()
        }
        soundEngine.setRacingActive(true, 0f)
    }

    fun pauseRace() {
        soundEngine.playClick()
        synchronized(raceLock) {
            raceEngine.setPaused(true)
            inputRef.set(ControlInput())
            _hudState.value = raceEngine.getHudState()
        }
        soundEngine.setRacingActive(false)
    }

    fun resumeRace() {
        soundEngine.playClick()
        synchronized(raceLock) {
            raceEngine.setPaused(false)
            _hudState.value = raceEngine.getHudState()
        }
        soundEngine.setRacingActive(!raceEngine.isGameOver, (raceEngine.speedMps / (raceEngine.currentCar.maxSpeedKmh / 3.6f)))
    }

    fun exitRaceToMenu() {
        soundEngine.playClick()
        _isRacingScreen.value = false
        inputRef.set(ControlInput())
        soundEngine.setRacingActive(false)
        renderer.renderMode = RenderMode.MENU_SHOWCASE
    }

    fun setRenderMode(mode: RenderMode) {
        renderer.renderMode = mode
    }

    fun rotateShowroom(deltaX: Float) {
        renderer.showroomYawDeg = (renderer.showroomYawDeg + deltaX * 0.45f) % 360f
    }

    fun updateTiltSteer(tiltAxis: Float) {
        inputRef.updateAndGet { it.copy(tiltSteer = tiltAxis.coerceIn(-1f, 1f)) }
    }

    fun updateLeftPressed(pressed: Boolean) {
        inputRef.updateAndGet { it.copy(leftPressed = pressed) }
    }

    fun updateRightPressed(pressed: Boolean) {
        inputRef.updateAndGet { it.copy(rightPressed = pressed) }
    }

    fun updateAcceleratePressed(pressed: Boolean) {
        inputRef.updateAndGet { it.copy(acceleratePressed = pressed) }
    }

    fun updateBrakePressed(pressed: Boolean) {
        inputRef.updateAndGet { it.copy(brakePressed = pressed) }
    }

    fun stepRaceFrame(dtSeconds: Float) {
        val currentInput = inputRef.get()
        val snapshot: RaceHudState
        val maxMps: Float
        val curMps: Float
        synchronized(raceLock) {
            raceEngine.step(dtSeconds, currentInput)
            snapshot = raceEngine.getHudState()
            maxMps = raceEngine.currentCar.maxSpeedKmh / 3.6f
            curMps = raceEngine.speedMps
        }
        _hudState.value = snapshot
        soundEngine.setRacingActive(
            active = _isRacingScreen.value && !snapshot.isPaused && !snapshot.isGameOver,
            speedRatio = (curMps / maxMps).coerceIn(0f, 1f)
        )
    }

    fun onAppResumed(resumed: Boolean) {
        soundEngine.onAppResumed(resumed)
        if (!resumed && _isRacingScreen.value && !_hudState.value.isGameOver) {
            synchronized(raceLock) {
                raceEngine.setPaused(true)
                inputRef.set(ControlInput())
                _hudState.value = raceEngine.getHudState()
            }
            soundEngine.setRacingActive(false)
        }
    }

    override fun onCleared() {
        super.onCleared()
        soundEngine.release()
    }

    class Factory(private val app: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return GameViewModel(GamePreferencesRepository(app.applicationContext)) as T
        }
    }
}
