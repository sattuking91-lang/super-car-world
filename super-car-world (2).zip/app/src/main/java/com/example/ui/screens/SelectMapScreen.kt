package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.GameMap
import com.example.model.GameSettings
import com.example.ui.components.MapPreviewIllustration
import com.example.ui.theme.AsphaltDark
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.CarbonSurfaceElevated
import com.example.ui.theme.ChampionshipGold
import com.example.ui.theme.CrispWhite
import com.example.ui.theme.DividerSlate
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldJungle
import com.example.ui.theme.MutedSlate
import com.example.ui.theme.RacingCrimson
import com.example.ui.theme.VillageSun

@Composable
fun SelectMapScreen(
    settings: GameSettings,
    onSelectMap: (GameMap) -> Unit,
    onPlayMap: (GameMap) -> Unit,
    onBack: () -> Unit
) {
    val maps = GameMap.entries

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(AsphaltDark, Color(0xFF101829)))
            )
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("btn_back_from_map")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = CrispWhite
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "SELECT MAP",
                    style = MaterialTheme.typography.headlineMedium,
                    color = CrispWhite
                )
                Text(
                    text = "Choose one of three separate 3D environments",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedSlate
                )
            }
        }

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val isLandscape = maxWidth > maxHeight
            if (isLandscape) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    maps.forEach { map ->
                        Box(modifier = Modifier.weight(1f)) {
                            MapCard(
                                map = map,
                                isSelected = settings.selectedMap == map,
                                bestScore = settings.bestScores[map] ?: 0,
                                onSelect = { onSelectMap(map) },
                                onRaceNow = { onPlayMap(map) }
                            )
                        }
                    }
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    maps.forEach { map ->
                        MapCard(
                            map = map,
                            isSelected = settings.selectedMap == map,
                            bestScore = settings.bestScores[map] ?: 0,
                            onSelect = { onSelectMap(map) },
                            onRaceNow = { onPlayMap(map) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MapCard(
    map: GameMap,
    isSelected: Boolean,
    bestScore: Int,
    onSelect: () -> Unit,
    onRaceNow: () -> Unit
) {
    val accent = when (map) {
        GameMap.CITY -> ElectricCyan
        GameMap.VILLAGE -> VillageSun
        GameMap.JUNGLE -> EmeraldJungle
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("map_card_${map.id}"),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) CarbonSurfaceElevated else CarbonSurface
        ),
        border = BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) accent else DividerSlate
        )
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(145.dp)
                    .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            ) {
                MapPreviewIllustration(
                    map = map,
                    modifier = Modifier.fillMaxSize()
                )

                // Best score badge
                Surface(
                    color = AsphaltDark.copy(alpha = 0.80f),
                    shape = RoundedCornerShape(50),
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = null,
                            tint = ChampionshipGold,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Best: $bestScore",
                            style = MaterialTheme.typography.labelSmall,
                            color = CrispWhite
                        )
                    }
                }

                if (isSelected) {
                    Surface(
                        color = accent,
                        shape = RoundedCornerShape(50),
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Selected",
                                tint = AsphaltDark,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "SELECTED",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = AsphaltDark
                            )
                        }
                    }
                }
            }

            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = map.displayName,
                    style = MaterialTheme.typography.titleLarge,
                    color = CrispWhite
                )
                Text(
                    text = map.subtitle,
                    style = MaterialTheme.typography.labelLarge,
                    color = accent
                )
                Text(
                    text = map.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedSlate
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Dedicated separate selection button for this map
                    OutlinedButton(
                        onClick = onSelect,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("map_button_${map.id}"),
                        shape = MaterialTheme.shapes.medium,
                        border = BorderStroke(1.5.dp, accent),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (isSelected) accent.copy(alpha = 0.16f) else Color.Transparent,
                            contentColor = if (isSelected) accent else CrispWhite
                        )
                    ) {
                        Text(
                            text = if (isSelected) "SELECTED" else "SELECT",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }

                    Button(
                        onClick = onRaceNow,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("map_play_${map.id}"),
                        shape = MaterialTheme.shapes.medium,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = RacingCrimson,
                            contentColor = CrispWhite
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "RACE",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        }
    }
}
