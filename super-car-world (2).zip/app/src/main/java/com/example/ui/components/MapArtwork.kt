package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import com.example.model.GameMap

@Composable
fun MapPreviewIllustration(
    map: GameMap,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        when (map) {
            GameMap.CITY -> {
                // Twilight skyline
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(Color(0xFF0A1128), Color(0xFF1D3557), Color(0xFF2B4C7E))
                    )
                )
                // Distant stars/lights
                drawCircle(Color(0x66F8FAFC), radius = 2f, center = Offset(w * 0.15f, h * 0.14f))
                drawCircle(Color(0x66F8FAFC), radius = 2.5f, center = Offset(w * 0.72f, h * 0.10f))
                drawCircle(Color(0x66FACC15), radius = 2f, center = Offset(w * 0.45f, h * 0.18f))

                // Skyscrapers
                val buildings = listOf(
                    Triple(0.04f, 0.16f, 0.22f),
                    Triple(0.18f, 0.14f, 0.12f),
                    Triple(0.30f, 0.13f, 0.30f),
                    Triple(0.60f, 0.14f, 0.24f),
                    Triple(0.73f, 0.15f, 0.14f),
                    Triple(0.86f, 0.13f, 0.28f)
                )
                buildings.forEachIndexed { idx, (bx, bw, topY) ->
                    val bColor = if (idx % 2 == 0) Color(0xFF17253D) else Color(0xFF20324F)
                    drawRect(
                        color = bColor,
                        topLeft = Offset(w * bx, h * topY),
                        size = Size(w * bw, h * (0.64f - topY))
                    )
                    // Glowing windows
                    val winColor = if (idx % 2 == 0) Color(0xFF38BDF8) else Color(0xFFFACC15)
                    var wy = topY + 0.05f
                    while (wy < 0.56f) {
                        drawRect(
                            color = winColor.copy(alpha = 0.75f),
                            topLeft = Offset(w * (bx + 0.02f), h * wy),
                            size = Size(w * (bw - 0.04f), h * 0.028f)
                        )
                        wy += 0.07f
                    }
                }

                // Wide 4-lane road perspective
                val roadPath = Path().apply {
                    moveTo(w * 0.38f, h * 0.62f)
                    lineTo(w * 0.62f, h * 0.62f)
                    lineTo(w * 0.96f, h)
                    lineTo(w * 0.04f, h)
                    close()
                }
                drawPath(roadPath, Color(0xFF1A202C))
                // Yellow center divider
                drawLine(
                    color = Color(0xFFFACC15),
                    start = Offset(w * 0.50f, h * 0.63f),
                    end = Offset(w * 0.50f, h),
                    strokeWidth = 4f
                )
                // Street lights
                drawLine(Color(0xFF94A3B8), Offset(w * 0.24f, h * 0.78f), Offset(w * 0.24f, h * 0.48f), 4f)
                drawCircle(Color(0xFFFDE047), radius = 6f, center = Offset(w * 0.28f, h * 0.48f))
                drawLine(Color(0xFF94A3B8), Offset(w * 0.76f, h * 0.78f), Offset(w * 0.76f, h * 0.48f), 4f)
                drawCircle(Color(0xFFFDE047), radius = 6f, center = Offset(w * 0.72f, h * 0.48f))
            }

            GameMap.VILLAGE -> {
                // Bright sunny sky
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(Color(0xFF0284C7), Color(0xFF7DD3FC), Color(0xFFBAE6FD))
                    )
                )
                // Warm sun
                drawCircle(Color(0xFFFDE047), radius = h * 0.11f, center = Offset(w * 0.80f, h * 0.22f))

                // Rolling green fields
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(Color(0xFF22C55E), Color(0xFF15803D))
                    ),
                    topLeft = Offset(0f, h * 0.55f),
                    size = Size(w, h * 0.45f)
                )

                // Golden farm field patch
                val farmPatch = Path().apply {
                    moveTo(0f, h * 0.62f)
                    lineTo(w * 0.34f, h * 0.62f)
                    lineTo(w * 0.22f, h * 0.88f)
                    lineTo(0f, h * 0.88f)
                    close()
                }
                drawPath(farmPatch, Color(0xFFEAB308).copy(alpha = 0.75f))

                // Scenic village road
                val roadPath = Path().apply {
                    moveTo(w * 0.44f, h * 0.56f)
                    lineTo(w * 0.56f, h * 0.56f)
                    lineTo(w * 0.84f, h)
                    lineTo(w * 0.16f, h)
                    close()
                }
                drawPath(roadPath, Color(0xFF475569))
                drawLine(
                    color = Color(0xFFFEF08A),
                    start = Offset(w * 0.50f, h * 0.58f),
                    end = Offset(w * 0.50f, h),
                    strokeWidth = 3f
                )

                // Village cottage on right
                drawRect(Color(0xFFFEF3C7), Offset(w * 0.68f, h * 0.46f), Size(w * 0.20f, h * 0.18f))
                val roof = Path().apply {
                    moveTo(w * 0.65f, h * 0.46f)
                    lineTo(w * 0.78f, h * 0.33f)
                    lineTo(w * 0.91f, h * 0.46f)
                    close()
                }
                drawPath(roof, Color(0xFFDC2626))
                drawRect(Color(0xFFF59E0B), Offset(w * 0.73f, h * 0.51f), Size(w * 0.04f, h * 0.05f))

                // Oak trees
                drawRect(Color(0xFF78350F), Offset(w * 0.14f, h * 0.48f), Size(w * 0.03f, h * 0.16f))
                drawCircle(Color(0xFF16A34A), radius = h * 0.11f, center = Offset(w * 0.155f, h * 0.43f))
                drawRect(Color(0xFF78350F), Offset(w * 0.28f, h * 0.47f), Size(w * 0.025f, h * 0.12f))
                drawCircle(Color(0xFF15803D), radius = h * 0.08f, center = Offset(w * 0.292f, h * 0.44f))
            }

            GameMap.JUNGLE -> {
                // Misty emerald rainforest sky
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(Color(0xFF064E3B), Color(0xFF0F766E), Color(0xFF6EE7B7))
                    )
                )
                // Towering misty mountains
                val mtn1 = Path().apply {
                    moveTo(0f, h * 0.60f)
                    lineTo(w * 0.26f, h * 0.16f)
                    lineTo(w * 0.56f, h * 0.60f)
                    close()
                }
                drawPath(mtn1, Color(0xFF115E59))
                val mtn2 = Path().apply {
                    moveTo(w * 0.40f, h * 0.60f)
                    lineTo(w * 0.74f, h * 0.12f)
                    lineTo(w, h * 0.60f)
                    close()
                }
                drawPath(mtn2, Color(0xFF134E4A))

                // Rainforest floor
                drawRect(Color(0xFF065F46), Offset(0f, h * 0.58f), Size(w, h * 0.42f))

                // Jungle highway
                val roadPath = Path().apply {
                    moveTo(w * 0.43f, h * 0.58f)
                    lineTo(w * 0.57f, h * 0.58f)
                    lineTo(w * 0.86f, h)
                    lineTo(w * 0.14f, h)
                    close()
                }
                drawPath(roadPath, Color(0xFF334155))
                drawLine(Color(0xFFFDE047), Offset(w * 0.50f, h * 0.60f), Offset(w * 0.50f, h), 3f)

                // Dense jungle trees & palms
                val treeCenters = listOf(0.08f, 0.20f, 0.31f, 0.70f, 0.82f, 0.93f)
                treeCenters.forEachIndexed { i, tx ->
                    val treeTop = if (i % 2 == 0) h * 0.34f else h * 0.42f
                    drawRoundRect(
                        color = Color(0xFF451A03),
                        topLeft = Offset(w * tx - 4f, treeTop + 16f),
                        size = Size(8f, h * 0.68f - treeTop),
                        cornerRadius = CornerRadius(4f, 4f)
                    )
                    drawCircle(
                        color = if (i % 2 == 0) Color(0xFF16A34A) else Color(0xFF15803D),
                        radius = h * 0.13f,
                        center = Offset(w * tx, treeTop + 12f)
                    )
                }
            }
        }
    }
}
