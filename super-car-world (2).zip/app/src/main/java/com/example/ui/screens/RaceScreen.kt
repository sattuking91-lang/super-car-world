package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.PointerId
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.engine.Gl3DRenderer
import com.example.engine.TiltSteeringMonitor
import com.example.model.GameSettings
import com.example.model.RaceHudState
import com.example.ui.components.GameGlViewport
import com.example.ui.theme.AsphaltDark
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.ChampionshipGold
import com.example.ui.theme.CrispWhite
import com.example.ui.theme.DividerSlate
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldJungle
import com.example.ui.theme.GoldBright
import com.example.ui.theme.MutedSlate
import com.example.ui.theme.RacingCrimson
import kotlinx.coroutines.delay
import java.util.Locale

@Composable
fun RaceScreen(
    renderer: Gl3DRenderer,
    hudState: RaceHudState,
    settings: GameSettings,
    onTiltSteerChanged: (Float) -> Unit,
    onLeftChanged: (Boolean) -> Unit,
    onRightChanged: (Boolean) -> Unit,
    onAccelerateChanged: (Boolean) -> Unit,
    onBrakeChanged: (Boolean) -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onRestart: () -> Unit,
    onExitToMenu: () -> Unit,
    onToggleSfx: (Boolean) -> Unit,
    onToggleMusic: (Boolean) -> Unit
) {
    var accelActive by remember { mutableStateOf(false) }
    var brakeActive by remember { mutableStateOf(false) }

    var showCollisionFlash by remember { mutableStateOf(false) }
    var showCoinPopup by remember { mutableStateOf(false) }
    var showTiltHint by remember { mutableStateOf(true) }
    val focusRequester = remember { FocusRequester() }

    val currentOnTiltSteerChanged by rememberUpdatedState(onTiltSteerChanged)

    LaunchedEffect(Unit) {
        delay(2600)
        showTiltHint = false
    }

    LaunchedEffect(hudState.isPaused, hudState.isGameOver) {
        if (hudState.isPaused || hudState.isGameOver) {
            accelActive = false
            brakeActive = false
            currentOnTiltSteerChanged(0f)
            onLeftChanged(false)
            onRightChanged(false)
            onAccelerateChanged(false)
            onBrakeChanged(false)
        } else {
            runCatching { focusRequester.requestFocus() }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            currentOnTiltSteerChanged(0f)
            onLeftChanged(false)
            onRightChanged(false)
            onAccelerateChanged(false)
            onBrakeChanged(false)
        }
    }

    TiltSteeringMonitor(
        enabled = !hudState.isPaused && !hudState.isGameOver,
        onTiltSteerChanged = { axis ->
            currentOnTiltSteerChanged(axis)
            if (showTiltHint && kotlin.math.abs(axis) > 0.22f) {
                showTiltHint = false
            }
        }
    )

    LaunchedEffect(hudState.collisionFlashCounter) {
        if (hudState.collisionFlashCounter > 0) {
            showCollisionFlash = true
            delay(280)
            showCollisionFlash = false
        }
    }

    LaunchedEffect(hudState.coinPopupCounter) {
        if (hudState.coinPopupCounter > 0) {
            showCoinPopup = true
            delay(550)
            showCoinPopup = false
        }
    }

    BackHandler {
        if (hudState.isGameOver) {
            onExitToMenu()
        } else if (hudState.isPaused) {
            onResume()
        } else {
            onPause()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .focusRequester(focusRequester)
            .focusable()
            .onPreviewKeyEvent { keyEvent ->
                if (hudState.isPaused || hudState.isGameOver) return@onPreviewKeyEvent false
                val isDown = when (keyEvent.type) {
                    KeyEventType.KeyDown -> true
                    KeyEventType.KeyUp -> false
                    else -> return@onPreviewKeyEvent false
                }
                when (keyEvent.key) {
                    Key.DirectionLeft, Key.A -> {
                        onLeftChanged(isDown)
                        true
                    }
                    Key.DirectionRight, Key.D -> {
                        onRightChanged(isDown)
                        true
                    }
                    Key.DirectionUp, Key.W -> {
                        accelActive = isDown
                        onAccelerateChanged(isDown)
                        true
                    }
                    Key.DirectionDown, Key.S, Key.Spacebar -> {
                        brakeActive = isDown
                        onBrakeChanged(isDown)
                        true
                    }
                    else -> false
                }
            }
    ) {
        // 1. Live Full-Screen 3D Racing Viewport
        GameGlViewport(renderer = renderer, modifier = Modifier.fillMaxSize())

        // 2. Red collision flash vignette
        AnimatedVisibility(
            visible = showCollisionFlash,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(RacingCrimson.copy(alpha = 0.32f))
            )
        }

        // 4. Clean Translucent HUD & Bottom-Corner Driving Pedals
        Box(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            // Top Minimal HUD: Small Score, Coins, Speed + discrete transparent Pause icon
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = AsphaltDark.copy(alpha = 0.34f),
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.18f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Small Score
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "SCORE ",
                                style = MaterialTheme.typography.labelSmall,
                                color = CrispWhite.copy(alpha = 0.72f)
                            )
                            Text(
                                text = "${hudState.score}",
                                style = MaterialTheme.typography.labelLarge,
                                color = CrispWhite,
                                modifier = Modifier.testTag("hud_score")
                            )
                        }

                        // Small Coins
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.MonetizationOn,
                                contentDescription = "Gold Coins",
                                tint = GoldBright,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${hudState.coins}",
                                style = MaterialTheme.typography.labelLarge,
                                color = GoldBright,
                                modifier = Modifier.testTag("hud_coins")
                            )
                        }

                        // Small Speed
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Speed,
                                contentDescription = "Speed",
                                tint = ElectricCyan,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${hudState.speedKmh} KM/H",
                                style = MaterialTheme.typography.labelLarge,
                                color = CrispWhite,
                                modifier = Modifier.testTag("hud_speed")
                            )
                        }
                    }
                }

                Surface(
                    color = AsphaltDark.copy(alpha = 0.32f),
                    shape = CircleShape,
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.20f))
                ) {
                    IconButton(
                        onClick = onPause,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("btn_pause")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Pause,
                            contentDescription = "Pause",
                            tint = CrispWhite
                        )
                    }
                }
            }

            // Coin collected floating indicator
            AnimatedVisibility(
                visible = showCoinPopup,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 48.dp)
            ) {
                Surface(
                    color = GoldBright.copy(alpha = 0.90f),
                    shape = RoundedCornerShape(50)
                ) {
                    Text(
                        text = "+100 GOLD COIN!",
                        style = MaterialTheme.typography.labelLarge,
                        color = AsphaltDark,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }
            }

            // Brief subtle tilt-to-steer onboarding hint at start
            AnimatedVisibility(
                visible = showTiltHint && !hudState.isPaused && !hudState.isGameOver,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 26.dp)
            ) {
                Surface(
                    color = AsphaltDark.copy(alpha = 0.32f),
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.18f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ScreenRotation,
                            contentDescription = null,
                            tint = ElectricCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "TILT PHONE LEFT / RIGHT TO STEER",
                            style = MaterialTheme.typography.labelSmall,
                            color = CrispWhite.copy(alpha = 0.88f)
                        )
                    }
                }
            }

            // Bottom-Left: One Big Transparent BRAKE Button
            TransparentPedalButton(
                title = "BRAKE",
                subtitle = "STOP",
                icon = Icons.Default.StopCircle,
                accentColor = RacingCrimson,
                isPressed = brakeActive,
                onPressedChange = { pressed ->
                    brakeActive = pressed
                    onBrakeChanged(pressed)
                },
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .size(width = 138.dp, height = 102.dp)
                    .testTag("btn_brake")
            )

            // Bottom-Right: One Big Transparent RACE / GAS Button
            TransparentPedalButton(
                title = "RACE",
                subtitle = "GAS",
                icon = Icons.Default.Speed,
                accentColor = EmeraldJungle,
                isPressed = accelActive,
                onPressedChange = { pressed ->
                    accelActive = pressed
                    onAccelerateChanged(pressed)
                },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(width = 152.dp, height = 110.dp)
                    .testTag("btn_accelerate")
            )
        }

        // 5. Pause Modal Overlay
        if (hudState.isPaused && !hudState.isGameOver) {
            PauseOverlay(
                hudState = hudState,
                settings = settings,
                onResume = onResume,
                onRestart = onRestart,
                onToggleSfx = onToggleSfx,
                onToggleMusic = onToggleMusic,
                onExitToMenu = onExitToMenu
            )
        }

        // 6. Race Over Overlay
        if (hudState.isGameOver) {
            GameOverOverlay(
                hudState = hudState,
                coinWallet = settings.coinBalance,
                onRestart = onRestart,
                onExitToMenu = onExitToMenu
            )
        }
    }
}

@Composable
private fun TransparentPedalButton(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    isPressed: Boolean,
    onPressedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val currentOnPressedChange by rememberUpdatedState(onPressedChange)
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
            .semantics { role = Role.Button }
            .pointerInput(Unit) {
                awaitEachGesture {
                    val activeIds = mutableSetOf<PointerId>()
                    val down = awaitFirstDown(requireUnconsumed = false)
                    down.consume()
                    activeIds.add(down.id)
                    currentOnPressedChange(true)
                    try {
                        while (activeIds.isNotEmpty()) {
                            val event = awaitPointerEvent()
                            for (change in event.changes) {
                                if (change.pressed) {
                                    activeIds.add(change.id)
                                    change.consume()
                                } else {
                                    activeIds.remove(change.id)
                                }
                            }
                        }
                    } finally {
                        currentOnPressedChange(false)
                    }
                }
            },
        shape = RoundedCornerShape(24.dp),
        color = if (isPressed) accentColor.copy(alpha = 0.34f) else AsphaltDark.copy(alpha = 0.16f),
        border = BorderStroke(
            width = if (isPressed) 2.5.dp else 1.5.dp,
            color = if (isPressed) accentColor.copy(alpha = 0.92f) else Color.White.copy(alpha = 0.34f)
        )
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isPressed) CrispWhite else accentColor.copy(alpha = 0.92f),
                modifier = Modifier.size(34.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = CrispWhite.copy(alpha = if (isPressed) 1f else 0.90f)
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = CrispWhite.copy(alpha = 0.65f)
            )
        }
    }
}

@Composable
private fun PauseOverlay(
    hudState: RaceHudState,
    settings: GameSettings,
    onResume: () -> Unit,
    onRestart: () -> Unit,
    onToggleSfx: (Boolean) -> Unit,
    onToggleMusic: (Boolean) -> Unit,
    onExitToMenu: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AsphaltDark.copy(alpha = 0.78f)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .padding(24.dp)
                .widthIn(max = 380.dp)
                .fillMaxWidth(),
            shape = MaterialTheme.shapes.large,
            colors = CardDefaults.cardColors(containerColor = CarbonSurface),
            border = BorderStroke(1.5.dp, DividerSlate)
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "RACE PAUSED",
                    style = MaterialTheme.typography.headlineMedium,
                    color = CrispWhite
                )
                Text(
                    text = "${hudState.map.displayName} • ${hudState.car.name}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedSlate
                )
                Text(
                    text = "Wallet: ${settings.coinBalance} Gold Coins",
                    style = MaterialTheme.typography.labelLarge,
                    color = GoldBright
                )

                Button(
                    onClick = onResume,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("btn_resume"),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldJungle, contentColor = AsphaltDark)
                ) {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "RESUME", style = MaterialTheme.typography.labelLarge)
                }

                OutlinedButton(
                    onClick = onRestart,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_restart"),
                    border = BorderStroke(1.dp, ChampionshipGold),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = ChampionshipGold)
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "RESTART", style = MaterialTheme.typography.labelLarge)
                }

                // Quick audio toggles
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = null, tint = ElectricCyan, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Sound FX", style = MaterialTheme.typography.bodyMedium, color = CrispWhite)
                    }
                    Switch(checked = settings.soundEffectsEnabled, onCheckedChange = onToggleSfx)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MusicNote, contentDescription = null, tint = ChampionshipGold, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Music", style = MaterialTheme.typography.bodyMedium, color = CrispWhite)
                    }
                    Switch(checked = settings.musicEnabled, onCheckedChange = onToggleMusic)
                }

                OutlinedButton(
                    onClick = onExitToMenu,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_exit_menu"),
                    border = BorderStroke(1.dp, DividerSlate),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CrispWhite)
                ) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "MAIN MENU", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

@Composable
private fun GameOverOverlay(
    hudState: RaceHudState,
    coinWallet: Int,
    onRestart: () -> Unit,
    onExitToMenu: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AsphaltDark.copy(alpha = 0.84f)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .padding(24.dp)
                .widthIn(max = 390.dp)
                .fillMaxWidth(),
            shape = MaterialTheme.shapes.large,
            colors = CardDefaults.cardColors(containerColor = CarbonSurface),
            border = BorderStroke(1.5.dp, RacingCrimson)
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "RACE FINISHED",
                    style = MaterialTheme.typography.headlineMedium,
                    color = RacingCrimson
                )
                if (hudState.isNewRecord) {
                    Surface(color = ChampionshipGold, shape = RoundedCornerShape(50)) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = AsphaltDark, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("NEW TRACK RECORD!", style = MaterialTheme.typography.labelSmall, color = AsphaltDark)
                        }
                    }
                }

                SummaryRow("Final Score", "${hudState.score}")
                SummaryRow("Run Gold Coins", "+${hudState.coins}")
                SummaryRow("Garage Wallet", "$coinWallet Coins")
                SummaryRow("Time", formatRaceTime(hudState.elapsedMs))
                SummaryRow("Track Best", "${hudState.bestScore}")

                Spacer(modifier = Modifier.height(4.dp))

                Button(
                    onClick = onRestart,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("btn_gameover_restart"),
                    colors = ButtonDefaults.buttonColors(containerColor = RacingCrimson, contentColor = CrispWhite)
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "RESTART RACE", style = MaterialTheme.typography.labelLarge)
                }

                OutlinedButton(
                    onClick = onExitToMenu,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_gameover_menu"),
                    border = BorderStroke(1.dp, DividerSlate),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CrispWhite)
                ) {
                    Text(text = "MAIN MENU", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

@Composable
private fun SummaryRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyLarge, color = MutedSlate)
        Text(text = value, style = MaterialTheme.typography.titleMedium, color = CrispWhite)
    }
}

fun formatRaceTime(elapsedMs: Long): String {
    val totalTenths = (elapsedMs / 100L).coerceAtLeast(0L)
    val tenths = totalTenths % 10L
    val totalSeconds = totalTenths / 10L
    val seconds = totalSeconds % 60L
    val minutes = totalSeconds / 60L
    return String.format(Locale.US, "%02d:%02d.%d", minutes, seconds, tenths)
}
