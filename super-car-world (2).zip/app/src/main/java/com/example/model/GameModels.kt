package com.example.model

enum class GameMap(
    val id: String,
    val displayName: String,
    val subtitle: String,
    val description: String,
    val roadHalfWidth: Float,
    val laneCount: Int
) {
    CITY(
        id = "city",
        displayName = "CITY MAP",
        subtitle = "Metropolis Expressway",
        description = "Modern skyscrapers, wide 4-lane roads, bright street lights & busy city traffic.",
        roadHalfWidth = 7.2f,
        laneCount = 4
    ),
    VILLAGE(
        id = "village",
        displayName = "VILLAGE MAP",
        subtitle = "Sunlit Country Road",
        description = "Green farm fields, charming village houses, leafy trees & scenic rural roads.",
        roadHalfWidth = 5.4f,
        laneCount = 2
    ),
    JUNGLE(
        id = "jungle",
        displayName = "JUNGLE MAP",
        subtitle = "Emerald Mountain Pass",
        description = "Dense tropical forest, towering mountain peaks, palm trees & winding jungle roads.",
        roadHalfWidth = 5.8f,
        laneCount = 2
    );

    companion object {
        fun fromId(id: String?): GameMap = entries.firstOrNull { it.id == id } ?: CITY
    }
}

enum class UpgradeStat(
    val id: String,
    val title: String,
    val boostDescription: String
) {
    TOP_SPEED(
        id = "top_speed",
        title = "Top Speed",
        boostDescription = "+8 km/h peak velocity per level"
    ),
    ACCELERATION(
        id = "acceleration",
        title = "Acceleration",
        boostDescription = "+3.2 m/s² launch & pull per level"
    ),
    BRAKING(
        id = "braking",
        title = "Braking",
        boostDescription = "+7.5 m/s² stopping power per level"
    ),
    HANDLING(
        id = "handling",
        title = "Handling",
        boostDescription = "+12% steering agility per level"
    )
}

data class CarUpgrades(
    val topSpeedLevel: Int = 0,
    val accelerationLevel: Int = 0,
    val brakingLevel: Int = 0,
    val handlingLevel: Int = 0
) {
    fun levelFor(stat: UpgradeStat): Int = when (stat) {
        UpgradeStat.TOP_SPEED -> topSpeedLevel
        UpgradeStat.ACCELERATION -> accelerationLevel
        UpgradeStat.BRAKING -> brakingLevel
        UpgradeStat.HANDLING -> handlingLevel
    }.coerceIn(0, MAX_LEVEL)

    fun withIncremented(stat: UpgradeStat): CarUpgrades = when (stat) {
        UpgradeStat.TOP_SPEED -> copy(topSpeedLevel = (topSpeedLevel + 1).coerceAtMost(MAX_LEVEL))
        UpgradeStat.ACCELERATION -> copy(accelerationLevel = (accelerationLevel + 1).coerceAtMost(MAX_LEVEL))
        UpgradeStat.BRAKING -> copy(brakingLevel = (brakingLevel + 1).coerceAtMost(MAX_LEVEL))
        UpgradeStat.HANDLING -> copy(handlingLevel = (handlingLevel + 1).coerceAtMost(MAX_LEVEL))
    }

    fun totalLevels(): Int =
        topSpeedLevel + accelerationLevel + brakingLevel + handlingLevel

    companion object {
        const val MAX_LEVEL = 5
        const val INITIAL_STARTER_COINS = 150
        val TIER_COSTS = listOf(50, 100, 175, 275, 400)

        fun costForNextLevel(currentLevel: Int): Int? =
            TIER_COSTS.getOrNull(currentLevel)
    }
}

enum class CarBodyStyle {
    SPORTS_CAR,
    BOXY_SUV
}

data class CarSpec(
    val id: String,
    val name: String,
    val tagline: String,
    val primaryColorRgb: Triple<Float, Float, Float>,
    val accentColorRgb: Triple<Float, Float, Float>,
    val maxSpeedKmh: Float,
    val accelerationRate: Float,
    val brakingDeceleration: Float,
    val handlingRating: Float,
    val speedRating: Int,
    val accelRating: Int,
    val brakingRating: Int,
    val handlingScore: Int,
    val hasTwinStripe: Boolean,
    val spoilerHeight: Float,
    val bodyStyle: CarBodyStyle = CarBodyStyle.SPORTS_CAR,
    val wheelScale: Float = 1.0f,
    val unlockCostCoins: Int = 0
)

object CarCatalog {
    val RED_SPORTS_CAR = CarSpec(
        id = "crimson_viper",
        name = "Crimson Viper",
        tagline = "Signature Red Sports Car",
        primaryColorRgb = Triple(0.92f, 0.12f, 0.18f),
        accentColorRgb = Triple(0.98f, 0.78f, 0.16f),
        maxSpeedKmh = 240f,
        accelerationRate = 28f,
        brakingDeceleration = 38f,
        handlingRating = 1.05f,
        speedRating = 80,
        accelRating = 78,
        brakingRating = 78,
        handlingScore = 80,
        hasTwinStripe = true,
        spoilerHeight = 0.42f
    )

    val VOLT_GT = CarSpec(
        id = "volt_gt",
        name = "Volt GT",
        tagline = "Precision Cobalt Coupe",
        primaryColorRgb = Triple(0.14f, 0.44f, 0.96f),
        accentColorRgb = Triple(0.95f, 0.98f, 1.0f),
        maxSpeedKmh = 232f,
        accelerationRate = 30f,
        brakingDeceleration = 42f,
        handlingRating = 1.25f,
        speedRating = 76,
        accelRating = 82,
        brakingRating = 85,
        handlingScore = 88,
        hasTwinStripe = true,
        spoilerHeight = 0.34f
    )

    val SOLARIS_APEX = CarSpec(
        id = "solaris_apex",
        name = "Solaris Apex",
        tagline = "Extreme Velocity Hypercar",
        primaryColorRgb = Triple(0.98f, 0.58f, 0.08f),
        accentColorRgb = Triple(0.12f, 0.14f, 0.18f),
        maxSpeedKmh = 265f,
        accelerationRate = 26f,
        brakingDeceleration = 36f,
        handlingRating = 0.95f,
        speedRating = 88,
        accelRating = 74,
        brakingRating = 74,
        handlingScore = 72,
        hasTwinStripe = false,
        spoilerHeight = 0.54f
    )

    val PHANTOM_ONYX = CarSpec(
        id = "phantom_onyx",
        name = "Phantom Onyx",
        tagline = "Twin-Turbo Night Racer",
        primaryColorRgb = Triple(0.16f, 0.19f, 0.25f),
        accentColorRgb = Triple(0.06f, 0.85f, 0.94f),
        maxSpeedKmh = 250f,
        accelerationRate = 34f,
        brakingDeceleration = 40f,
        handlingRating = 1.12f,
        speedRating = 84,
        accelRating = 88,
        brakingRating = 82,
        handlingScore = 82,
        hasTwinStripe = true,
        spoilerHeight = 0.46f
    )

    val THAR_SUV = CarSpec(
        id = "thar",
        name = "Thar",
        tagline = "Black Boxy Off-Road SUV • Big Tires",
        primaryColorRgb = Triple(0.08f, 0.09f, 0.11f),
        accentColorRgb = Triple(0.76f, 0.80f, 0.86f),
        maxSpeedKmh = 262f,
        accelerationRate = 35f,
        brakingDeceleration = 41f,
        handlingRating = 1.14f,
        speedRating = 87,
        accelRating = 89,
        brakingRating = 83,
        handlingScore = 84,
        hasTwinStripe = false,
        spoilerHeight = 0f,
        bodyStyle = CarBodyStyle.BOXY_SUV,
        wheelScale = 1.42f,
        unlockCostCoins = 5000
    )

    val allCars: List<CarSpec> = listOf(
        RED_SPORTS_CAR,
        VOLT_GT,
        SOLARIS_APEX,
        PHANTOM_ONYX,
        THAR_SUV
    )

    fun defaultUnlockedIds(): Set<String> =
        allCars.filter { it.unlockCostCoins <= 0 }.map { it.id }.toSet()

    fun fromId(id: String?): CarSpec = allCars.firstOrNull { it.id == id } ?: RED_SPORTS_CAR

    fun withUpgrades(base: CarSpec, upgrades: CarUpgrades): CarSpec = base.copy(
        maxSpeedKmh = base.maxSpeedKmh + upgrades.topSpeedLevel * 8f,
        accelerationRate = base.accelerationRate + upgrades.accelerationLevel * 3.2f,
        brakingDeceleration = base.brakingDeceleration + upgrades.brakingLevel * 7.5f,
        handlingRating = base.handlingRating + upgrades.handlingLevel * 0.12f,
        speedRating = (base.speedRating + upgrades.topSpeedLevel * 4).coerceAtMost(100),
        accelRating = (base.accelRating + upgrades.accelerationLevel * 4).coerceAtMost(100),
        brakingRating = (base.brakingRating + upgrades.brakingLevel * 4).coerceAtMost(100),
        handlingScore = (base.handlingScore + upgrades.handlingLevel * 4).coerceAtMost(100)
    )
}

data class ControlInput(
    val leftPressed: Boolean = false,
    val rightPressed: Boolean = false,
    val acceleratePressed: Boolean = false,
    val brakePressed: Boolean = false,
    val tiltSteer: Float = 0f
)

data class TrafficVehicle(
    val id: Int,
    var x: Float,
    var z: Float,
    val speedMps: Float,
    val width: Float,
    val length: Float,
    val style: Int,
    val colorRgb: Triple<Float, Float, Float>
)

data class GoldCoin(
    val id: Int,
    val x: Float,
    val z: Float,
    var collected: Boolean = false
)

data class RaceHudState(
    val map: GameMap = GameMap.CITY,
    val car: CarSpec = CarCatalog.RED_SPORTS_CAR,
    val speedKmh: Int = 0,
    val score: Int = 0,
    val coins: Int = 0,
    val elapsedMs: Long = 0L,
    val shields: Int = 3,
    val maxShields: Int = 3,
    val isPaused: Boolean = false,
    val isGameOver: Boolean = false,
    val bestScore: Int = 0,
    val isNewRecord: Boolean = false,
    val coinPopupCounter: Int = 0,
    val collisionFlashCounter: Int = 0
)

data class GameSettings(
    val soundEffectsEnabled: Boolean = true,
    val musicEnabled: Boolean = true,
    val selectedMap: GameMap = GameMap.CITY,
    val selectedCarId: String = CarCatalog.RED_SPORTS_CAR.id,
    val bestScores: Map<GameMap, Int> = emptyMap(),
    val coinBalance: Int = CarUpgrades.INITIAL_STARTER_COINS,
    val carUpgrades: Map<String, CarUpgrades> = emptyMap(),
    val unlockedCarIds: Set<String> = CarCatalog.defaultUnlockedIds()
) {
    fun upgradesForCar(carId: String): CarUpgrades = carUpgrades[carId] ?: CarUpgrades()

    fun isCarUnlocked(carId: String): Boolean {
        val spec = CarCatalog.fromId(carId)
        return spec.unlockCostCoins <= 0 || spec.id in unlockedCarIds
    }
}
