package com.example.engine

import android.opengl.GLES20
import com.example.model.CarBodyStyle
import com.example.model.CarSpec
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Interleaved 3D mesh: [x, y, z, nx, ny, nz, r, g, b, a]
 */
class Mesh3D(vertices: FloatArray) {
    val vertexCount: Int = vertices.size / FLOATS_PER_VERTEX
    private val buffer: FloatBuffer = ByteBuffer
        .allocateDirect(vertices.size * 4)
        .order(ByteOrder.nativeOrder())
        .asFloatBuffer()
        .apply {
            put(vertices)
            position(0)
        }

    fun draw(posHandle: Int, normalHandle: Int, colorHandle: Int) {
        buffer.position(0)
        GLES20.glVertexAttribPointer(posHandle, 3, GLES20.GL_FLOAT, false, STRIDE_BYTES, buffer)
        GLES20.glEnableVertexAttribArray(posHandle)

        buffer.position(3)
        GLES20.glVertexAttribPointer(normalHandle, 3, GLES20.GL_FLOAT, false, STRIDE_BYTES, buffer)
        GLES20.glEnableVertexAttribArray(normalHandle)

        buffer.position(6)
        GLES20.glVertexAttribPointer(colorHandle, 4, GLES20.GL_FLOAT, false, STRIDE_BYTES, buffer)
        GLES20.glEnableVertexAttribArray(colorHandle)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, vertexCount)
    }

    companion object {
        const val FLOATS_PER_VERTEX = 10
        const val STRIDE_BYTES = FLOATS_PER_VERTEX * 4
    }
}

class MeshVertexCollector {
    private var data = FloatArray(1024)
    private var count = 0

    fun addTriangle(
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        x3: Float, y3: Float, z3: Float,
        r: Float, g: Float, b: Float, a: Float = 1f
    ) {
        // Compute face normal
        val ux = x2 - x1
        val uy = y2 - y1
        val uz = z2 - z1
        val vx = x3 - x1
        val vy = y3 - y1
        val vz = z3 - z1
        var nx = uy * vz - uz * vy
        var ny = uz * vx - ux * vz
        var nz = ux * vy - uy * vx
        val len = kotlin.math.sqrt(nx * nx + ny * ny + nz * nz).coerceAtLeast(0.0001f)
        nx /= len
        ny /= len
        nz /= len

        pushVertex(x1, y1, z1, nx, ny, nz, r, g, b, a)
        pushVertex(x2, y2, z2, nx, ny, nz, r, g, b, a)
        pushVertex(x3, y3, z3, nx, ny, nz, r, g, b, a)
    }

    fun addQuad(
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        x3: Float, y3: Float, z3: Float,
        x4: Float, y4: Float, z4: Float,
        r: Float, g: Float, b: Float, a: Float = 1f
    ) {
        addTriangle(x1, y1, z1, x2, y2, z2, x3, y3, z3, r, g, b, a)
        addTriangle(x1, y1, z1, x3, y3, z3, x4, y4, z4, r, g, b, a)
    }

    fun addBox(
        minX: Float, minY: Float, minZ: Float,
        maxX: Float, maxY: Float, maxZ: Float,
        r: Float, g: Float, b: Float, a: Float = 1f
    ) {
        // Front (+Z)
        addQuad(minX, minY, maxZ, maxX, minY, maxZ, maxX, maxY, maxZ, minX, maxY, maxZ, r, g, b, a)
        // Back (-Z)
        addQuad(maxX, minY, minZ, minX, minY, minZ, minX, maxY, minZ, maxX, maxY, minZ, r * 0.9f, g * 0.9f, b * 0.9f, a)
        // Top (+Y)
        addQuad(minX, maxY, maxZ, maxX, maxY, maxZ, maxX, maxY, minZ, minX, maxY, minZ,
            (r * 1.12f).coerceAtMost(1f), (g * 1.12f).coerceAtMost(1f), (b * 1.12f).coerceAtMost(1f), a)
        // Bottom (-Y)
        addQuad(minX, minY, minZ, maxX, minY, minZ, maxX, minY, maxZ, minX, minY, maxZ, r * 0.6f, g * 0.6f, b * 0.6f, a)
        // Right (+X)
        addQuad(maxX, minY, maxZ, maxX, minY, minZ, maxX, maxY, minZ, maxX, maxY, maxZ, r * 0.85f, g * 0.85f, b * 0.85f, a)
        // Left (-X)
        addQuad(minX, minY, minZ, minX, minY, maxZ, minX, maxY, maxZ, minX, maxY, minZ, r * 0.85f, g * 0.85f, b * 0.85f, a)
    }

    fun addTaperedBlock(
        bx0: Float, bx1: Float, bz0: Float, bz1: Float, y0: Float,
        tx0: Float, tx1: Float, tz0: Float, tz1: Float, y1: Float,
        r: Float, g: Float, b: Float
    ) {
        // Top
        addQuad(tx0, y1, tz1, tx1, y1, tz1, tx1, y1, tz0, tx0, y1, tz0,
            (r * 1.1f).coerceAtMost(1f), (g * 1.1f).coerceAtMost(1f), (b * 1.1f).coerceAtMost(1f))
        // Front (+Z)
        addQuad(bx0, y0, bz1, bx1, y0, bz1, tx1, y1, tz1, tx0, y1, tz1, r, g, b)
        // Back (-Z)
        addQuad(bx1, y0, bz0, bx0, y0, bz0, tx0, y1, tz0, tx1, y1, tz0, r * 0.9f, g * 0.9f, b * 0.9f)
        // Right (+X)
        addQuad(bx1, y0, bz1, bx1, y0, bz0, tx1, y1, tz0, tx1, y1, tz1, r * 0.86f, g * 0.86f, b * 0.86f)
        // Left (-X)
        addQuad(bx0, y0, bz0, bx0, y0, bz1, tx0, y1, tz1, tx0, y1, tz0, r * 0.86f, g * 0.86f, b * 0.86f)
    }

    fun addPyramid(
        cx: Float, baseY: Float, cz: Float,
        halfW: Float, halfD: Float, height: Float,
        r: Float, g: Float, b: Float
    ) {
        val topY = baseY + height
        val x0 = cx - halfW
        val x1 = cx + halfW
        val z0 = cz - halfD
        val z1 = cz + halfD
        addTriangle(x0, baseY, z1, x1, baseY, z1, cx, topY, cz, r, g, b)
        addTriangle(x1, baseY, z1, x1, baseY, z0, cx, topY, cz, r * 0.9f, g * 0.9f, b * 0.9f)
        addTriangle(x1, baseY, z0, x0, baseY, z0, cx, topY, cz, r * 0.82f, g * 0.82f, b * 0.82f)
        addTriangle(x0, baseY, z0, x0, baseY, z1, cx, topY, cz, r * 0.92f, g * 0.92f, b * 0.92f)
    }

    fun addCylinderY(
        cx: Float, baseY: Float, cz: Float,
        radiusBottom: Float, radiusTop: Float, height: Float,
        segments: Int,
        r: Float, g: Float, b: Float
    ) {
        val topY = baseY + height
        for (i in 0 until segments) {
            val a0 = (i.toFloat() / segments) * (2f * PI.toFloat())
            val a1 = ((i + 1).toFloat() / segments) * (2f * PI.toFloat())
            val bx0 = cx + cos(a0) * radiusBottom
            val bz0 = cz + sin(a0) * radiusBottom
            val bx1 = cx + cos(a1) * radiusBottom
            val bz1 = cz + sin(a1) * radiusBottom

            val tx0 = cx + cos(a0) * radiusTop
            val tz0 = cz + sin(a0) * radiusTop
            val tx1 = cx + cos(a1) * radiusTop
            val tz1 = cz + sin(a1) * radiusTop

            addQuad(bx0, baseY, bz0, bx1, baseY, bz1, tx1, topY, tz1, tx0, topY, tz0, r, g, b)
            if (radiusTop > 0.01f) {
                addTriangle(cx, topY, cz, tx0, topY, tz0, tx1, topY, tz1,
                    (r * 1.1f).coerceAtMost(1f), (g * 1.1f).coerceAtMost(1f), (b * 1.1f).coerceAtMost(1f))
            }
        }
    }

    private fun pushVertex(
        x: Float, y: Float, z: Float,
        nx: Float, ny: Float, nz: Float,
        r: Float, g: Float, b: Float, a: Float
    ) {
        if (count + 10 >= data.size) {
            data = data.copyOf(data.size * 2)
        }
        data[count++] = x
        data[count++] = y
        data[count++] = z
        data[count++] = nx
        data[count++] = ny
        data[count++] = nz
        data[count++] = r
        data[count++] = g
        data[count++] = b
        data[count++] = a
    }

    fun build(): Mesh3D = Mesh3D(data.copyOf(count))
}

object GlMeshBuilder {

    fun buildSportsCarBody(car: CarSpec, braking: Boolean): Mesh3D {
        val c = MeshVertexCollector()
        val (r, g, b) = car.primaryColorRgb
        val (ar, ag, ab) = car.accentColorRgb

        // Carbon lower splitter & side skirts
        c.addBox(-0.96f, 0.16f, -2.08f, 0.96f, 0.28f, 2.08f, 0.12f, 0.14f, 0.18f)

        // Sculpted main chassis lower hull
        c.addTaperedBlock(
            -0.94f, 0.94f, -2.02f, 2.04f, 0.28f,
            -0.88f, 0.88f, -1.92f, 1.96f, 0.68f,
            r, g, b
        )

        // Aerodynamic front nose slope
        c.addTaperedBlock(
            -0.88f, 0.88f, 1.10f, 2.04f, 0.56f,
            -0.82f, 0.82f, 0.65f, 1.98f, 0.72f,
            r, g, b
        )

        // Sleek cockpit cabin with dark tinted glass look
        c.addTaperedBlock(
            -0.78f, 0.78f, -1.12f, 0.92f, 0.68f,
            -0.62f, 0.62f, -0.78f, 0.36f, 1.14f,
            0.09f, 0.14f, 0.22f
        )

        // Painted roof panel
        c.addBox(-0.60f, 1.13f, -0.76f, 0.60f, 1.18f, 0.34f, r, g, b)

        // Twin racing stripes along hood, roof, and rear deck
        if (car.hasTwinStripe) {
            c.addBox(-0.22f, 0.73f, 0.88f, -0.06f, 0.745f, 1.96f, ar, ag, ab)
            c.addBox(0.06f, 0.73f, 0.88f, 0.22f, 0.745f, 1.96f, ar, ag, ab)
            c.addBox(-0.20f, 1.18f, -0.75f, -0.05f, 1.195f, 0.33f, ar, ag, ab)
            c.addBox(0.05f, 1.18f, -0.75f, 0.20f, 1.195f, 0.33f, ar, ag, ab)
            c.addBox(-0.22f, 0.685f, -1.92f, -0.06f, 0.70f, -1.12f, ar, ag, ab)
            c.addBox(0.06f, 0.685f, -1.92f, 0.22f, 0.70f, -1.12f, ar, ag, ab)
        }

        // Rear aero spoiler struts and wing
        val wingY = 0.68f + car.spoilerHeight
        c.addBox(-0.55f, 0.68f, -1.86f, -0.45f, wingY, -1.68f, 0.12f, 0.14f, 0.18f)
        c.addBox(0.45f, 0.68f, -1.86f, 0.55f, wingY, -1.68f, 0.12f, 0.14f, 0.18f)
        c.addBox(-0.92f, wingY, -1.96f, 0.92f, wingY + 0.08f, -1.60f, ar, ag, ab)

        // Glowing LED headlights (front +Z)
        c.addBox(-0.78f, 0.42f, 1.97f, -0.46f, 0.56f, 2.06f, 1.0f, 0.98f, 0.82f)
        c.addBox(0.46f, 0.42f, 1.97f, 0.78f, 0.56f, 2.06f, 1.0f, 0.98f, 0.82f)

        // Brake / Tail light bar (rear -Z)
        val tailR = if (braking) 1.0f else 0.78f
        val tailG = if (braking) 0.22f else 0.05f
        val tailB = if (braking) 0.15f else 0.05f
        c.addBox(-0.82f, 0.46f, -2.05f, -0.34f, 0.58f, -1.98f, tailR, tailG, tailB)
        c.addBox(0.34f, 0.46f, -2.05f, 0.82f, 0.58f, -1.98f, tailR, tailG, tailB)

        // Exhaust tips
        c.addBox(-0.46f, 0.22f, -2.08f, -0.28f, 0.34f, -1.98f, 0.75f, 0.78f, 0.82f)
        c.addBox(0.28f, 0.22f, -2.08f, 0.46f, 0.34f, -1.98f, 0.75f, 0.78f, 0.82f)

        return c.build()
    }

    fun buildBoxySuvBody(car: CarSpec, braking: Boolean): Mesh3D {
        val c = MeshVertexCollector()
        val (br, bg, bb) = car.primaryColorRgb
        // Keep black body facets visible with slight specular tint under OpenGL directional light
        val r = br.coerceAtLeast(0.11f)
        val g = bg.coerceAtLeast(0.12f)
        val b = bb.coerceAtLeast(0.14f)
        val (ar, ag, ab) = car.accentColorRgb

        // Rugged off-road underbody chassis & skid plate
        c.addBox(-0.88f, 0.40f, -1.96f, 0.88f, 0.52f, 1.98f, 0.07f, 0.08f, 0.10f)
        c.addBox(-0.56f, 0.36f, 1.72f, 0.56f, 0.50f, 2.04f, 0.58f, 0.62f, 0.66f)

        // Heavy front & rear matte steel off-road bumpers
        c.addBox(-1.02f, 0.42f, 1.94f, 1.02f, 0.62f, 2.14f, 0.05f, 0.06f, 0.07f)
        c.addBox(-1.02f, 0.42f, -2.10f, 1.02f, 0.62f, -1.92f, 0.05f, 0.06f, 0.07f)

        // Side rock-slider footboards
        c.addBox(-1.08f, 0.42f, -0.82f, -0.88f, 0.50f, 0.82f, 0.18f, 0.20f, 0.24f)
        c.addBox(0.88f, 0.42f, -0.82f, 1.08f, 0.50f, 0.82f, 0.18f, 0.20f, 0.24f)

        // Main boxy SUV lower tub (high ground clearance)
        c.addBox(-0.92f, 0.52f, -1.94f, 0.92f, 1.18f, 1.96f, r, g, b)

        // Flared boxy fender arches above the big front & rear tires
        c.addBox(-1.12f, 0.96f, 0.92f, -0.88f, 1.10f, 1.84f, 0.06f, 0.07f, 0.08f)
        c.addBox(0.88f, 0.96f, 0.92f, 1.12f, 1.10f, 1.84f, 0.06f, 0.07f, 0.08f)
        c.addBox(-1.12f, 0.96f, -1.84f, -0.88f, 1.10f, -0.92f, 0.06f, 0.07f, 0.08f)
        c.addBox(0.88f, 0.96f, -1.84f, 1.12f, 1.10f, -0.92f, 0.06f, 0.07f, 0.08f)

        // Flat muscular hood & power bulge
        c.addBox(-0.84f, 1.16f, 0.72f, 0.84f, 1.24f, 1.94f, r * 1.12f, g * 1.12f, b * 1.12f)

        // Iconic 5-slot vertical Thar front grille & metallic surround
        c.addBox(-0.56f, 0.68f, 1.95f, 0.56f, 1.14f, 2.00f, 0.05f, 0.05f, 0.06f)
        for (slot in -2..2) {
            val gx = slot * 0.20f
            c.addBox(gx - 0.04f, 0.72f, 1.99f, gx + 0.04f, 1.10f, 2.03f, ar, ag, ab)
        }

        // Bright round/square LED headlamps
        c.addBox(-0.84f, 0.78f, 1.96f, -0.58f, 1.04f, 2.04f, 1.0f, 0.97f, 0.84f)
        c.addBox(0.58f, 0.78f, 1.96f, 0.84f, 1.04f, 2.04f, 1.0f, 0.97f, 0.84f)

        // Upright boxy hardtop cabin & tinted windows
        c.addTaperedBlock(
            -0.86f, 0.86f, -1.84f, 0.80f, 1.18f,
            -0.80f, 0.80f, -1.78f, 0.56f, 1.88f,
            0.12f, 0.18f, 0.26f
        )
        // Glossy black A/B/C pillars & hardtop roof shell
        c.addBox(-0.84f, 1.84f, -1.80f, 0.84f, 1.96f, 0.58f, 0.07f, 0.08f, 0.10f)
        c.addBox(-0.86f, 1.18f, -1.84f, -0.76f, 1.86f, -1.56f, r, g, b)
        c.addBox(0.76f, 1.18f, -1.84f, 0.86f, 1.86f, -1.56f, r, g, b)
        // Side mirrors
        c.addBox(-1.04f, 1.18f, 0.52f, -0.86f, 1.34f, 0.70f, 0.08f, 0.09f, 0.11f)
        c.addBox(0.86f, 1.18f, 0.52f, 1.04f, 1.34f, 0.70f, 0.08f, 0.09f, 0.11f)

        // Rugged roof rails
        c.addBox(-0.74f, 1.96f, -1.68f, -0.66f, 2.04f, 0.42f, ar * 0.8f, ag * 0.8f, ab * 0.8f)
        c.addBox(0.66f, 1.96f, -1.68f, 0.74f, 2.04f, 0.42f, ar * 0.8f, ag * 0.8f, ab * 0.8f)

        // Tailgate-mounted full-size spare tire (unmistakable Thar rear view)
        val spareSegments = 12
        val spareCenterY = 1.06f
        val spareZ0 = -2.20f
        val spareZ1 = -1.94f
        val spareOuterR = 0.42f
        val spareInnerR = 0.23f
        for (i in 0 until spareSegments) {
            val a0 = (i.toFloat() / spareSegments) * (2f * PI.toFloat())
            val a1 = ((i + 1).toFloat() / spareSegments) * (2f * PI.toFloat())
            val x0 = cos(a0) * spareOuterR
            val y0 = spareCenterY + sin(a0) * spareOuterR
            val x1 = cos(a1) * spareOuterR
            val y1 = spareCenterY + sin(a1) * spareOuterR
            c.addQuad(x0, y0, spareZ0, x0, y0, spareZ1, x1, y1, spareZ1, x1, y1, spareZ0, 0.09f, 0.10f, 0.12f)
            c.addTriangle(0f, spareCenterY, spareZ0, x1, y1, spareZ0, x0, y0, spareZ0, 0.14f, 0.15f, 0.18f)

            val rx0 = cos(a0) * spareInnerR
            val ry0 = spareCenterY + sin(a0) * spareInnerR
            val rx1 = cos(a1) * spareInnerR
            val ry1 = spareCenterY + sin(a1) * spareInnerR
            val hubShade = if (i % 2 == 0) 0.78f else 0.52f
            c.addTriangle(0f, spareCenterY, spareZ0 - 0.01f, rx1, ry1, spareZ0 - 0.01f, rx0, ry0, spareZ0 - 0.01f, hubShade, hubShade, hubShade * 1.04f)
        }

        // Boxy vertical rear tail lights
        val tailR = if (braking) 1.0f else 0.82f
        val tailG = if (braking) 0.22f else 0.06f
        val tailB = if (braking) 0.14f else 0.05f
        c.addBox(-0.92f, 0.72f, -2.01f, -0.72f, 1.08f, -1.92f, tailR, tailG, tailB)
        c.addBox(0.72f, 0.72f, -2.01f, 0.92f, 1.08f, -1.92f, tailR, tailG, tailB)

        return c.build()
    }

    fun buildWheel(
        tireRadius: Float = 0.35f,
        rimRadius: Float = 0.22f,
        halfWidth: Float = 0.14f
    ): Mesh3D {
        val c = MeshVertexCollector()
        val segments = 14

        for (i in 0 until segments) {
            val a0 = (i.toFloat() / segments) * (2f * PI.toFloat())
            val a1 = ((i + 1).toFloat() / segments) * (2f * PI.toFloat())
            val y0 = cos(a0) * tireRadius
            val z0 = sin(a0) * tireRadius
            val y1 = cos(a1) * tireRadius
            val z1 = sin(a1) * tireRadius

            // Outer tread
            c.addQuad(-halfWidth, y0, z0, halfWidth, y0, z0, halfWidth, y1, z1, -halfWidth, y1, z1, 0.11f, 0.12f, 0.15f)
            // Sidewalls (+X and -X)
            c.addTriangle(halfWidth, 0f, 0f, halfWidth, y0, z0, halfWidth, y1, z1, 0.16f, 0.18f, 0.22f)
            c.addTriangle(-halfWidth, 0f, 0f, -halfWidth, y1, z1, -halfWidth, y0, z0, 0.16f, 0.18f, 0.22f)

            // Metallic alloy rim hub
            val ry0 = cos(a0) * rimRadius
            val rz0 = sin(a0) * rimRadius
            val ry1 = cos(a1) * rimRadius
            val rz1 = sin(a1) * rimRadius
            val shade = if (i % 2 == 0) 0.86f else 0.58f
            c.addTriangle(halfWidth + 0.01f, 0f, 0f, halfWidth + 0.01f, ry0, rz0, halfWidth + 0.01f, ry1, rz1, shade, shade, shade * 1.05f)
            c.addTriangle(-halfWidth - 0.01f, 0f, 0f, -halfWidth - 0.01f, ry1, rz1, -halfWidth - 0.01f, ry0, rz0, shade, shade, shade * 1.05f)
        }
        return c.build()
    }

    fun buildTrafficVehicle(colorRgb: Triple<Float, Float, Float>, style: Int): Mesh3D {
        val c = MeshVertexCollector()
        val (r, g, b) = colorRgb
        if (style == 0) {
            // Sedan
            c.addBox(-0.90f, 0.28f, -1.90f, 0.90f, 0.78f, 1.90f, r, g, b)
            c.addTaperedBlock(-0.78f, 0.78f, -1.05f, 0.85f, 0.78f, -0.66f, 0.66f, -0.75f, 0.45f, 1.32f, 0.15f, 0.22f, 0.30f)
            c.addBox(-0.64f, 1.31f, -0.72f, 0.64f, 1.36f, 0.42f, r, g, b)
        } else {
            // SUV / Pickup
            c.addBox(-0.94f, 0.32f, -2.15f, 0.94f, 0.92f, 2.15f, r, g, b)
            c.addBox(-0.82f, 0.92f, -1.75f, 0.82f, 1.56f, 0.95f, r * 0.92f, g * 0.92f, b * 0.92f)
            c.addBox(-0.78f, 0.98f, 0.88f, 0.78f, 1.46f, 1.02f, 0.16f, 0.24f, 0.32f)
        }
        // Rear red taillights
        c.addBox(-0.82f, 0.48f, -1.96f, -0.45f, 0.66f, -1.88f, 0.98f, 0.16f, 0.14f)
        c.addBox(0.45f, 0.48f, -1.96f, 0.82f, 0.66f, -1.88f, 0.98f, 0.16f, 0.14f)
        // Four dark wheels baked into traffic mesh
        val wheelPositions = listOf(-0.88f to 1.25f, 0.88f to 1.25f, -0.88f to -1.25f, 0.88f to -1.25f)
        for ((wx, wz) in wheelPositions) {
            c.addBox(wx - 0.14f, 0.0f, wz - 0.34f, wx + 0.14f, 0.62f, wz + 0.34f, 0.10f, 0.11f, 0.14f)
        }
        return c.build()
    }

    fun buildGoldCoin(): Mesh3D {
        val c = MeshVertexCollector()
        val segments = 14
        val outerR = 0.72f
        val innerR = 0.46f
        val halfThick = 0.11f
        for (i in 0 until segments) {
            val a0 = (i.toFloat() / segments) * (2f * PI.toFloat())
            val a1 = ((i + 1).toFloat() / segments) * (2f * PI.toFloat())
            val x0 = cos(a0) * outerR
            val y0 = sin(a0) * outerR
            val x1 = cos(a1) * outerR
            val y1 = sin(a1) * outerR
            // Outer rim
            c.addQuad(x0, y0, -halfThick, x0, y0, halfThick, x1, y1, halfThick, x1, y1, -halfThick, 0.92f, 0.68f, 0.05f)
            // Front & back gold faces
            c.addTriangle(0f, 0f, halfThick, x0, y0, halfThick, x1, y1, halfThick, 1.0f, 0.85f, 0.14f)
            c.addTriangle(0f, 0f, -halfThick, x1, y1, -halfThick, x0, y0, -halfThick, 0.96f, 0.78f, 0.10f)
            // Inner gleam
            val ix0 = cos(a0) * innerR
            val iy0 = sin(a0) * innerR
            val ix1 = cos(a1) * innerR
            val iy1 = sin(a1) * innerR
            c.addTriangle(0f, 0f, halfThick + 0.02f, ix0, iy0, halfThick + 0.02f, ix1, iy1, halfThick + 0.02f, 1.0f, 0.96f, 0.55f)
            c.addTriangle(0f, 0f, -halfThick - 0.02f, ix1, iy1, -halfThick - 0.02f, ix0, iy0, -halfThick - 0.02f, 1.0f, 0.92f, 0.45f)
        }
        return c.build()
    }

    fun buildSkyscraper(height: Float, width: Float, depth: Float, wallRgb: Triple<Float, Float, Float>, windowRgb: Triple<Float, Float, Float>): Mesh3D {
        val c = MeshVertexCollector()
        val (r, g, b) = wallRgb
        val (wr, wg, wb) = windowRgb
        val hw = width * 0.5f
        val hd = depth * 0.5f
        c.addBox(-hw, 0f, -hd, hw, height, hd, r, g, b)
        // Crown ledge
        c.addBox(-hw - 0.3f, height, -hd - 0.3f, hw + 0.3f, height + 1.2f, hd + 0.3f, r * 0.75f, g * 0.75f, b * 0.75f)
        // Lit window bands along the road-facing and front faces
        val floors = (height / 3.8f).toInt().coerceAtLeast(2)
        for (f in 1 until floors) {
            val wy = f * 3.6f
            c.addBox(-hw - 0.06f, wy, -hd * 0.75f, hw + 0.06f, wy + 1.15f, hd * 0.75f, wr, wg, wb)
            c.addBox(-hw * 0.75f, wy, -hd - 0.06f, hw * 0.75f, wy + 1.15f, hd + 0.06f, wr, wg, wb)
        }
        return c.build()
    }

    fun buildStreetLight(facingSign: Float): Mesh3D {
        val c = MeshVertexCollector()
        // Vertical steel pole
        c.addBox(-0.14f, 0f, -0.14f, 0.14f, 7.6f, 0.14f, 0.36f, 0.42f, 0.50f)
        // Overhang arm pointing toward road center (facingSign is +1 if pole is on left, -1 if on right)
        val armX0 = if (facingSign > 0) 0f else -2.6f
        val armX1 = if (facingSign > 0) 2.6f else 0f
        c.addBox(armX0, 7.45f, -0.12f, armX1, 7.72f, 0.12f, 0.42f, 0.48f, 0.56f)
        // Glowing warm street lamp head
        val lampX0 = if (facingSign > 0) 1.9f else -2.7f
        val lampX1 = if (facingSign > 0) 2.7f else -1.9f
        c.addBox(lampX0, 7.22f, -0.26f, lampX1, 7.48f, 0.26f, 1.0f, 0.92f, 0.64f)
        return c.build()
    }

    fun buildVillageHouse(wallRgb: Triple<Float, Float, Float>, roofRgb: Triple<Float, Float, Float>): Mesh3D {
        val c = MeshVertexCollector()
        val (wr, wg, wb) = wallRgb
        val (rr, rg, rb) = roofRgb
        // Cottage walls
        c.addBox(-3.2f, 0f, -3.0f, 3.2f, 3.6f, 3.0f, wr, wg, wb)
        // Pitched roof
        c.addPyramid(0f, 3.6f, 0f, 3.7f, 3.5f, 2.5f, rr, rg, rb)
        // Chimney
        c.addBox(1.4f, 4.4f, -1.2f, 2.1f, 6.4f, -0.5f, 0.58f, 0.26f, 0.22f)
        // Warm glowing windows & wooden door
        c.addBox(-2.2f, 1.2f, -3.08f, -1.0f, 2.3f, 3.08f, 1.0f, 0.88f, 0.48f)
        c.addBox(1.0f, 1.2f, -3.08f, 2.2f, 2.3f, 3.08f, 1.0f, 0.88f, 0.48f)
        c.addBox(-0.55f, 0f, -3.08f, 0.55f, 2.1f, 3.08f, 0.44f, 0.24f, 0.12f)
        return c.build()
    }

    fun buildOakTree(): Mesh3D {
        val c = MeshVertexCollector()
        c.addCylinderY(0f, 0f, 0f, 0.48f, 0.34f, 3.6f, 7, 0.44f, 0.27f, 0.14f)
        c.addCylinderY(0f, 3.1f, 0f, 2.4f, 1.6f, 2.2f, 8, 0.16f, 0.56f, 0.22f)
        c.addCylinderY(0f, 4.9f, 0f, 1.8f, 0.3f, 2.1f, 8, 0.22f, 0.66f, 0.26f)
        return c.build()
    }

    fun buildFarmFenceAndHay(): Mesh3D {
        val c = MeshVertexCollector()
        // Wooden fence posts & rails along Z
        c.addBox(-0.12f, 0f, -3.6f, 0.12f, 1.25f, -3.36f, 0.52f, 0.34f, 0.18f)
        c.addBox(-0.12f, 0f, -0.12f, 0.12f, 1.25f, 0.12f, 0.52f, 0.34f, 0.18f)
        c.addBox(-0.12f, 0f, 3.36f, 0.12f, 1.25f, 3.6f, 0.52f, 0.34f, 0.18f)
        c.addBox(-0.08f, 0.48f, -3.6f, 0.08f, 0.64f, 3.6f, 0.62f, 0.42f, 0.24f)
        c.addBox(-0.08f, 0.92f, -3.6f, 0.08f, 1.08f, 3.6f, 0.62f, 0.42f, 0.24f)
        // Golden hay bale behind fence
        c.addCylinderY(2.2f, 0f, 0f, 0.95f, 0.95f, 1.35f, 8, 0.90f, 0.74f, 0.24f)
        return c.build()
    }

    fun buildPalmTree(): Mesh3D {
        val c = MeshVertexCollector()
        // Segmented tropical trunk
        c.addCylinderY(0f, 0f, 0f, 0.42f, 0.30f, 4.5f, 7, 0.48f, 0.32f, 0.18f)
        c.addCylinderY(0.25f, 4.2f, 0f, 0.30f, 0.20f, 4.2f, 7, 0.52f, 0.36f, 0.20f)
        // Radiating palm fronds
        val crownY = 8.2f
        val fronds = 6
        for (i in 0 until fronds) {
            val angle = (i.toFloat() / fronds) * (2f * PI.toFloat())
            val dx = cos(angle) * 3.4f
            val dz = sin(angle) * 3.4f
            val px = -sin(angle) * 0.55f
            val pz = cos(angle) * 0.55f
            c.addTriangle(
                0.25f, crownY, 0f,
                0.25f + dx * 0.55f + px, crownY + 0.55f, dz * 0.55f + pz,
                0.25f + dx, crownY - 1.1f, dz,
                0.12f, 0.64f, 0.24f
            )
            c.addTriangle(
                0.25f, crownY, 0f,
                0.25f + dx, crownY - 1.1f, dz,
                0.25f + dx * 0.55f - px, crownY + 0.55f, dz * 0.55f - pz,
                0.18f, 0.74f, 0.30f
            )
        }
        return c.build()
    }

    fun buildJungleCanopyTree(): Mesh3D {
        val c = MeshVertexCollector()
        c.addCylinderY(0f, 0f, 0f, 0.65f, 0.46f, 6.2f, 7, 0.36f, 0.24f, 0.14f)
        c.addCylinderY(0f, 5.4f, 0f, 3.6f, 2.4f, 2.8f, 8, 0.08f, 0.44f, 0.18f)
        c.addCylinderY(0f, 7.6f, 0f, 2.5f, 0.4f, 2.2f, 8, 0.12f, 0.55f, 0.22f)
        return c.build()
    }

    fun buildMountainPeak(width: Float, height: Float): Mesh3D {
        val c = MeshVertexCollector()
        c.addPyramid(0f, -2f, 0f, width * 0.5f, width * 0.45f, height, 0.14f, 0.32f, 0.26f)
        // Secondary ridge
        c.addPyramid(width * 0.22f, -2f, width * 0.15f, width * 0.36f, width * 0.34f, height * 0.72f, 0.18f, 0.38f, 0.30f)
        return c.build()
    }

    fun buildShowroomTurntable(): Mesh3D {
        val c = MeshVertexCollector()
        c.addCylinderY(0f, -0.28f, 0f, 3.4f, 3.2f, 0.28f, 24, 0.16f, 0.20f, 0.28f)
        c.addCylinderY(0f, -0.02f, 0f, 2.85f, 2.85f, 0.04f, 24, 0.25f, 0.30f, 0.40f)
        return c.build()
    }

    fun buildGarageShed(): Mesh3D {
        val c = MeshVertexCollector()

        // Concrete garage floor & dark apron
        c.addBox(-15.5f, -0.25f, -7.8f, 15.5f, 0.0f, 14.0f, 0.22f, 0.24f, 0.27f)
        // Safety yellow workshop stripes & bay dividers for 5 parked vehicles
        val bayCenters = floatArrayOf(-8.4f, -4.2f, 0f, 4.2f, 8.4f)
        for (bx in bayCenters) {
            c.addBox(bx - 1.75f, 0.004f, -3.2f, bx + 1.75f, 0.012f, 3.2f, 0.16f, 0.18f, 0.22f)
            c.addBox(bx - 1.82f, 0.012f, -3.2f, bx - 1.72f, 0.018f, 3.2f, 0.94f, 0.72f, 0.14f)
            c.addBox(bx + 1.72f, 0.012f, -3.2f, bx + 1.82f, 0.018f, 3.2f, 0.94f, 0.72f, 0.14f)
        }

        // Back shed wall (corrugated steel upper + brick/concrete lower wainscot)
        c.addBox(-15.2f, 0.0f, -7.6f, 15.2f, 1.4f, -7.1f, 0.28f, 0.22f, 0.20f)
        c.addBox(-15.2f, 1.4f, -7.6f, 15.2f, 6.8f, -7.1f, 0.24f, 0.28f, 0.34f)

        // 5 Tall industrial roll-up garage shutter doors along the back wall
        for (bx in bayCenters) {
            // Door frame
            c.addBox(bx - 1.68f, 0.0f, -7.12f, bx + 1.68f, 4.4f, -6.96f, 0.12f, 0.14f, 0.18f)
            // Ribbed silver/grey shutter slats
            for (slat in 0 until 7) {
                val y0 = 0.25f + slat * 0.56f
                val shade = if (slat % 2 == 0) 0.44f else 0.38f
                c.addBox(bx - 1.54f, y0, -6.97f, bx + 1.54f, y0 + 0.46f, -6.88f, shade, shade + 0.02f, shade + 0.05f)
            }
        }

        // Red workshop tool cabinets between bays & spare tire rack on left wall
        c.addBox(-10.8f, 0.0f, -6.9f, -9.8f, 1.45f, -5.8f, 0.78f, 0.14f, 0.16f)
        c.addBox(9.8f, 0.0f, -6.9f, 10.8f, 1.45f, -5.8f, 0.78f, 0.14f, 0.16f)
        c.addBox(-14.3f, 0.0f, -4.5f, -13.2f, 2.2f, -1.5f, 0.14f, 0.16f, 0.20f)

        // Left & Right corrugated shed walls
        c.addBox(-15.2f, 0.0f, -7.6f, -14.6f, 6.2f, 11.0f, 0.22f, 0.26f, 0.32f)
        c.addBox(14.6f, 0.0f, -7.6f, 15.2f, 6.2f, 11.0f, 0.22f, 0.26f, 0.32f)

        // Heavy steel I-beam structural pillars along walls
        for (px in floatArrayOf(-14.3f, -6.3f, 6.3f, 14.3f)) {
            c.addBox(px - 0.22f, 0.0f, -7.0f, px + 0.22f, 6.6f, -6.55f, 0.34f, 0.38f, 0.44f)
        }
        for (pz in floatArrayOf(-4.5f, 0.5f, 5.5f)) {
            c.addBox(-14.65f, 0.0f, pz - 0.22f, -14.15f, 6.1f, pz + 0.22f, 0.34f, 0.38f, 0.44f)
            c.addBox(14.15f, 0.0f, pz - 0.22f, 14.65f, 6.1f, pz + 0.22f, 0.34f, 0.38f, 0.44f)
        }

        // Big pitched corrugated shed roof & overhead steel trusses + bright LED light strips
        c.addQuad(-15.4f, 6.0f, 11.0f, 0f, 8.2f, 11.0f, 0f, 8.2f, -7.8f, -15.4f, 6.0f, -7.8f, 0.20f, 0.24f, 0.30f)
        c.addQuad(0f, 8.2f, 11.0f, 15.4f, 6.0f, 11.0f, 15.4f, 6.0f, -7.8f, 0f, 8.2f, -7.8f, 0.20f, 0.24f, 0.30f)

        for (tz in floatArrayOf(-5.0f, 0.0f, 5.0f)) {
            c.addBox(-14.6f, 5.85f, tz - 0.14f, 14.6f, 6.12f, tz + 0.14f, 0.32f, 0.36f, 0.42f)
        }
        // Overhead bright LED workshop light bars above each car bay
        for (bx in bayCenters) {
            c.addBox(bx - 1.1f, 5.72f, -0.8f, bx + 1.1f, 5.86f, 0.8f, 0.98f, 0.97f, 0.88f)
        }

        return c.build()
    }

    fun buildGarageBayHighlight(): Mesh3D {
        val c = MeshVertexCollector()
        c.addBox(-1.62f, 0.015f, -2.55f, 1.62f, 0.035f, 2.55f, 0.98f, 0.78f, 0.18f)
        c.addBox(-1.46f, 0.036f, -2.38f, 1.46f, 0.044f, 2.38f, 0.16f, 0.20f, 0.26f)
        return c.build()
    }
}
