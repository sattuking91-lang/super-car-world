package com.example.engine

import com.example.model.CarCatalog
import com.example.model.CarSpec
import com.example.model.ControlInput
import com.example.model.GameMap
import com.example.model.GoldCoin
import com.example.model.RaceHudState
import com.example.model.TrafficVehicle
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * Pure Kotlin 3D race simulation engine.
 * Handles player physics, steering, road curvature/elevation per map,
 * traffic AI, gold coin spawning & collection, collision detection, and timer.
 */
class RaceEngine(
    initialMap: GameMap = GameMap.CITY,
    initialCar: CarSpec = CarCatalog.RED_SPORTS_CAR,
    initialBestScore: Int = 0
) {
    var currentMap: GameMap = initialMap
        private set
    var currentCar: CarSpec = initialCar
        private set

    var playerX: Float = 0f
        private set
    var distanceZ: Float = 0f
        private set
    var speedMps: Float = 0f
        private set
    var steerVisualAngle: Float = 0f
        private set
    var carHeadingDeg: Float = 0f
        private set
    var steerInputSmoothed: Float = 0f
        private set
    var lateralVelocity: Float = 0f
        private set
    var bodyRollAngle: Float = 0f
        private set
    var bodyPitchAngle: Float = 0f
        private set
    var wheelSpinDeg: Float = 0f
        private set
    var isBrakingVisual: Boolean = false
        private set
    var resetGeneration: Int = 0
        private set

    var score: Int = 0
        private set
    var coinsCollected: Int = 0
        private set
    var elapsedMs: Long = 0L
        private set
    var shields: Int = 3
        private set
    val maxShields: Int = 3
    var isPaused: Boolean = false
        private set
    var isGameOver: Boolean = false
        private set
    var bestScore: Int = initialBestScore
        private set
    var isNewRecord: Boolean = false
        private set

    var invulnerabilityTimer: Float = 0f
        private set
    var cameraShakeAmount: Float = 0f
        private set

    private var coinPopupCounter: Int = 0
    private var collisionFlashCounter: Int = 0
    private var fractionalScoreDist: Float = 0f
    private var nextCoinSpawnZ: Float = 38f
    private var nextEntityId: Int = 1

    private val random = Random(1337)
    val trafficVehicles = mutableListOf<TrafficVehicle>()
    val goldCoins = mutableListOf<GoldCoin>()

    var onCoinCollected: (() -> Unit)? = null
    var onCollision: (() -> Unit)? = null
    var onNewBestScore: ((GameMap, Int) -> Unit)? = null

    init {
        reset(initialMap, initialCar, initialBestScore)
    }

    fun reset(map: GameMap = currentMap, car: CarSpec = currentCar, mapBestScore: Int = bestScore) {
        currentMap = map
        currentCar = car
        bestScore = mapBestScore
        playerX = if (map.laneCount == 4) -1.8f else 0f
        distanceZ = 0f
        speedMps = 0f // Starts stationary until RACE / GAS is pressed
        steerVisualAngle = 0f
        carHeadingDeg = 0f
        steerInputSmoothed = 0f
        lateralVelocity = 0f
        bodyRollAngle = 0f
        bodyPitchAngle = 0f
        wheelSpinDeg = 0f
        isBrakingVisual = false
        resetGeneration++
        score = 0
        coinsCollected = 0
        elapsedMs = 0L
        shields = maxShields
        isPaused = false
        isGameOver = false
        isNewRecord = false
        invulnerabilityTimer = 0f
        cameraShakeAmount = 0f
        coinPopupCounter = 0
        collisionFlashCounter = 0
        fractionalScoreDist = 0f
        nextCoinSpawnZ = 34f
        trafficVehicles.clear()
        goldCoins.clear()

        spawnInitialEntities()
    }

    fun setPaused(paused: Boolean) {
        if (!isGameOver) {
            isPaused = paused
        }
    }

    fun roadCenterX(z: Float): Float = trackCenterX(currentMap, z)

    fun roadElevationY(z: Float): Float = trackElevationY(currentMap, z)

    fun roadSlopeAngle(z: Float): Float = trackSlopeAngle(currentMap, z)

    fun step(dtSeconds: Float, input: ControlInput) {
        if (isPaused || isGameOver) return
        val dt = dtSeconds.coerceIn(0.001f, 0.05f)

        elapsedMs += (dt * 1000f).toLong()
        if (invulnerabilityTimer > 0f) {
            invulnerabilityTimer = (invulnerabilityTimer - dt).coerceAtLeast(0f)
        }
        if (cameraShakeAmount > 0f) {
            cameraShakeAmount = (cameraShakeAmount - dt * 2.8f).coerceAtLeast(0f)
        }

        val maxSpeedMps = currentCar.maxSpeedKmh / 3.6f
        isBrakingVisual = input.brakePressed

        // Acceleration, Slow Coast Release & Firm Braking Physics
        when {
            input.brakePressed -> {
                speedMps = (speedMps - currentCar.brakingDeceleration * dt).coerceAtLeast(0f)
                bodyPitchAngle = lerp(bodyPitchAngle, 2.4f, dt * 8f)
            }
            input.acceleratePressed -> {
                val accelCurve = 1f - (speedMps / maxSpeedMps) * 0.35f
                speedMps = (speedMps + currentCar.accelerationRate * accelCurve * dt).coerceAtMost(maxSpeedMps)
                bodyPitchAngle = lerp(bodyPitchAngle, -1.8f, dt * 6f)
            }
            else -> {
                // Slow down slowly when RACE / GAS is released
                speedMps = (speedMps - 3.6f * dt).coerceAtLeast(0f)
                bodyPitchAngle = lerp(bodyPitchAngle, 0f, dt * 5f)
            }
        }

        // Smooth Tilt Steering (+ Keyboard Fallback):
        // Camera looks down +Z with up = +Y, so right-handed Screen Left is +X and Screen Right is -X.
        val keySteerInput = when {
            input.leftPressed && !input.rightPressed -> 1f
            input.rightPressed && !input.leftPressed -> -1f
            else -> 0f
        }
        val manualSteerInput = if (keySteerInput != 0f) {
            keySteerInput
        } else {
            input.tiltSteer.coerceIn(-1f, 1f)
        }

        val isCounterSteering = manualSteerInput != 0f && manualSteerInput * steerInputSmoothed < 0f
        val steerRate = when {
            manualSteerInput == 0f -> 8.2f
            isCounterSteering -> 13.5f + currentCar.handlingRating * 2.4f
            else -> 9.5f + currentCar.handlingRating * 2.4f
        }
        steerInputSmoothed = lerp(steerInputSmoothed, manualSteerInput, dt * steerRate)
        if (manualSteerInput == 0f && abs(steerInputSmoothed) < 0.005f) {
            steerInputSmoothed = 0f
        }

        val speedRatio = (speedMps / maxSpeedMps).coerceIn(0f, 1f)
        val moveAuthority = if (speedMps > 0.35f) {
            (0.45f + 0.55f * speedRatio) * (speedMps / 4.5f).coerceIn(0.28f, 1f)
        } else {
            0f
        }
        // Medium sensitivity lateral agility for smooth, predictable lane control
        val maxLateralSpeed = 11.2f * currentCar.handlingRating * moveAuthority
        val targetLateralVel = steerInputSmoothed * maxLateralSpeed

        // Centrifugal inertia on curved City, Village, and Jungle roads pulls gently toward the outside of bends
        val curvature = trackCurvature(currentMap, distanceZ)
        val centrifugalPull = if (speedMps > 2f) {
            (-curvature * speedMps * speedMps * 0.042f / currentCar.handlingRating).coerceIn(-3.6f, 3.6f)
        } else {
            0f
        }

        val gripRate = 7.4f + currentCar.handlingRating * 3.8f
        lateralVelocity = lerp(lateralVelocity, targetLateralVel + centrifugalPull, dt * gripRate)
        playerX += lateralVelocity * dt

        val maxOffset = currentMap.roadHalfWidth - 1.15f
        if (playerX < -maxOffset) {
            playerX = -maxOffset
            if (lateralVelocity < 0f) lateralVelocity *= 0.2f
        } else if (playerX > maxOffset) {
            playerX = maxOffset
            if (lateralVelocity > 0f) lateralVelocity *= 0.2f
        }

        // Front wheel steering angle, smooth body yaw into turns, and realistic lateral weight roll
        steerVisualAngle = steerInputSmoothed * 26f
        val targetHeading = steerInputSmoothed * 17f * (0.4f + 0.6f * speedRatio) +
            (lateralVelocity * 0.65f).coerceIn(-12f, 12f)
        carHeadingDeg = lerp(carHeadingDeg, targetHeading, dt * 11f)
        val targetRoll = (lateralVelocity / 12.5f).coerceIn(-1.2f, 1.2f) * 5.6f
        bodyRollAngle = lerp(bodyRollAngle, targetRoll, dt * 9f)

        // Forward movement & wheel rotation
        val dz = speedMps * dt
        distanceZ += dz
        wheelSpinDeg = (wheelSpinDeg + (dz / 0.35f) * (180f / PI.toFloat())) % 360f

        // Distance score
        fractionalScoreDist += dz * 1.4f
        if (fractionalScoreDist >= 1f) {
            val pts = fractionalScoreDist.toInt()
            fractionalScoreDist -= pts
            addScore(pts)
        }

        // Update Traffic Vehicles
        updateTraffic(dt)

        // Update & Spawn Gold Coins
        updateCoins()

        // Check Collisions
        checkCollisions()
    }

    fun getHudState(): RaceHudState = RaceHudState(
        map = currentMap,
        car = currentCar,
        speedKmh = (speedMps * 3.6f).toInt(),
        score = score,
        coins = coinsCollected,
        elapsedMs = elapsedMs,
        shields = shields,
        maxShields = maxShields,
        isPaused = isPaused,
        isGameOver = isGameOver,
        bestScore = bestScore,
        isNewRecord = isNewRecord,
        coinPopupCounter = coinPopupCounter,
        collisionFlashCounter = collisionFlashCounter
    )

    private fun addScore(points: Int) {
        score += points
        if (score > bestScore) {
            bestScore = score
            isNewRecord = true
            onNewBestScore?.invoke(currentMap, bestScore)
        }
    }

    private fun spawnInitialEntities() {
        val trafficCount = when (currentMap) {
            GameMap.CITY -> 8
            GameMap.VILLAGE -> 5
            GameMap.JUNGLE -> 6
        }
        for (i in 0 until trafficCount) {
            val z = 55f + i * 32f + random.nextFloat() * 10f
            trafficVehicles.add(createTrafficVehicle(z))
        }
        repeat(4) {
            spawnCoinLine(nextCoinSpawnZ)
            nextCoinSpawnZ += 44f
        }
    }

    private fun createTrafficVehicle(z: Float): TrafficVehicle {
        val lanes = lanePositions()
        val laneX = lanes[random.nextInt(lanes.size)]
        val baseSpeed = when (currentMap) {
            GameMap.CITY -> 16f + random.nextFloat() * 12f
            GameMap.VILLAGE -> 11f + random.nextFloat() * 7f
            GameMap.JUNGLE -> 14f + random.nextFloat() * 9f
        }
        val palette = when (currentMap) {
            GameMap.CITY -> listOf(
                Triple(0.95f, 0.78f, 0.12f), // City Taxi
                Triple(0.22f, 0.56f, 0.92f), // Blue Sedan
                Triple(0.86f, 0.88f, 0.92f), // Silver Coupe
                Triple(0.18f, 0.76f, 0.54f)  // Green Hybrid
            )
            GameMap.VILLAGE -> listOf(
                Triple(0.85f, 0.34f, 0.18f), // Rust Pickup
                Triple(0.26f, 0.62f, 0.34f), // Farm Truck
                Triple(0.92f, 0.85f, 0.62f)  // Cream Sedan
            )
            GameMap.JUNGLE -> listOf(
                Triple(0.24f, 0.44f, 0.28f), // Safari SUV
                Triple(0.92f, 0.52f, 0.14f), // Expedition 4x4
                Triple(0.76f, 0.72f, 0.54f)  // Khaki Jeep
            )
        }
        val style = random.nextInt(2)
        return TrafficVehicle(
            id = nextEntityId++,
            x = laneX,
            z = z,
            speedMps = baseSpeed,
            width = 1.9f,
            length = if (style == 1) 4.4f else 3.9f,
            style = style,
            colorRgb = palette[random.nextInt(palette.size)]
        )
    }

    private fun lanePositions(): List<Float> = if (currentMap.laneCount == 4) {
        listOf(-5.1f, -1.75f, 1.75f, 5.1f)
    } else {
        listOf(-2.45f, 2.45f)
    }

    private fun spawnCoinLine(startZ: Float) {
        val lanes = lanePositions()
        val laneX = lanes[random.nextInt(lanes.size)]
        val count = 3 + random.nextInt(3)
        for (i in 0 until count) {
            goldCoins.add(
                GoldCoin(
                    id = nextEntityId++,
                    x = laneX,
                    z = startZ + i * 5.2f
                )
            )
        }
    }

    private fun updateTraffic(dt: Float) {
        val recycleHorizon = distanceZ + 230f
        for (i in trafficVehicles.indices) {
            val v = trafficVehicles[i]
            v.z += v.speedMps * dt
            if (v.z < distanceZ - 22f) {
                val lanes = lanePositions()
                val newZ = recycleHorizon + random.nextFloat() * 45f
                trafficVehicles[i] = v.copy(
                    x = lanes[random.nextInt(lanes.size)],
                    z = newZ
                )
            }
        }
    }

    private fun updateCoins() {
        val iter = goldCoins.iterator()
        while (iter.hasNext()) {
            val coin = iter.next()
            if (coin.z < distanceZ - 14f) {
                iter.remove()
                continue
            }
            if (!coin.collected &&
                abs(playerX - coin.x) < 1.65f &&
                abs(distanceZ - coin.z) < 2.4f
            ) {
                coin.collected = true
                coinsCollected += 1
                coinPopupCounter += 1
                addScore(100)
                onCoinCollected?.invoke()
                iter.remove()
            }
        }

        while (nextCoinSpawnZ < distanceZ + 190f) {
            spawnCoinLine(nextCoinSpawnZ)
            nextCoinSpawnZ += 42f + random.nextFloat() * 18f
        }
    }

    private fun checkCollisions() {
        if (invulnerabilityTimer > 0f) return
        for (v in trafficVehicles) {
            val dx = abs(playerX - v.x)
            val dz = abs(distanceZ - v.z)
            if (dx < 1.65f && dz < 3.4f) {
                shields = (shields - 1).coerceAtLeast(0)
                invulnerabilityTimer = 1.5f
                cameraShakeAmount = 1.0f
                collisionFlashCounter += 1
                speedMps = (speedMps * 0.45f).coerceAtLeast(6f)
                // Gently nudge player clear of traffic lane
                playerX = if (playerX >= v.x) {
                    (v.x + 2.1f).coerceAtMost(currentMap.roadHalfWidth - 1.2f)
                } else {
                    (v.x - 2.1f).coerceAtLeast(-(currentMap.roadHalfWidth - 1.2f))
                }
                onCollision?.invoke()
                if (shields <= 0) {
                    speedMps = 0f
                    isGameOver = true
                }
                break
            }
        }
    }

    private fun lerp(a: Float, b: Float, t: Float): Float {
        val f = t.coerceIn(0f, 1f)
        return a + (b - a) * f
    }

    companion object {
        fun trackCenterX(map: GameMap, z: Float): Float = when (map) {
            GameMap.CITY -> sin(z * 0.022f) * 8.5f + sin(z * 0.009f) * 5.0f
            GameMap.VILLAGE -> sin(z * 0.028f) * 9.5f + sin(z * 0.012f) * 4.8f
            GameMap.JUNGLE -> sin(z * 0.033f) * 10.5f + sin(z * 0.015f) * 5.5f
        }

        fun trackElevationY(map: GameMap, z: Float): Float = when (map) {
            GameMap.CITY -> sin(z * 0.009f) * 1.1f
            GameMap.VILLAGE -> sin(z * 0.014f) * 2.4f
            GameMap.JUNGLE -> sin(z * 0.017f) * 3.6f + cos(z * 0.008f) * 1.4f
        }

        fun trackSlopeAngle(map: GameMap, z: Float): Float {
            val dz = 1.0f
            val dx = trackCenterX(map, z + dz) - trackCenterX(map, z - dz)
            return kotlin.math.atan2(dx, dz * 2f) * (180f / PI.toFloat())
        }

        fun trackCurvature(map: GameMap, z: Float): Float {
            val h = 2.0f
            return (trackCenterX(map, z + h) - 2f * trackCenterX(map, z) + trackCenterX(map, z - h)) / (h * h)
        }
    }
}

