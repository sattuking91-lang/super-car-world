package com.example.engine

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import com.example.model.CarBodyStyle
import com.example.model.CarCatalog
import com.example.model.CarSpec
import com.example.model.GameMap
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

enum class RenderMode {
    RACE,
    MENU_SHOWCASE,
    CAR_SHOWROOM,
    GARAGE
}

/**
 * Full OpenGL ES 2.0 3D renderer for Super Car World.
 * Supports:
 * - Active Racing Mode (with dynamic curved 3D road, City/Village/Jungle scenery, traffic, spinning gold coins, and player car)
 * - Main Menu 3D Live Showcase Mode
 * - Interactive 3D Car Showroom Turntable Mode
 */
class Gl3DRenderer(
    private val raceEngine: RaceEngine
) : GLSurfaceView.Renderer {

    @Volatile
    var renderMode: RenderMode = RenderMode.MENU_SHOWCASE

    @Volatile
    var showcaseMap: GameMap = GameMap.CITY

    @Volatile
    var showcaseCar: CarSpec = CarCatalog.RED_SPORTS_CAR

    @Volatile
    var showroomYawDeg: Float = 32f

    @Volatile
    var garageFocusedCarId: String = CarCatalog.RED_SPORTS_CAR.id

    var onFrameTick: ((Float) -> Unit)? = null

    private var program = 0
    private var mvpMatrixHandle = 0
    private var modelMatrixHandle = 0
    private var lightDirHandle = 0
    private var fogColorHandle = 0
    private var fogDensityHandle = 0
    private var posHandle = 0
    private var normalHandle = 0
    private var colorHandle = 0

    private val projectionMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val modelMatrix = FloatArray(16)
    private val vpMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)

    // Pre-allocated dynamic buffer for road & terrain strips (zero per-frame GC churn)
    private val maxRoadFloats = 32000
    private val roadFloatArray = FloatArray(maxRoadFloats)
    private var roadFloatCount = 0
    private val roadBuffer: FloatBuffer = ByteBuffer
        .allocateDirect(maxRoadFloats * 4)
        .order(ByteOrder.nativeOrder())
        .asFloatBuffer()

    // Sky quad buffer
    private val skyBuffer: FloatBuffer = ByteBuffer
        .allocateDirect(6 * Mesh3D.FLOATS_PER_VERTEX * 4)
        .order(ByteOrder.nativeOrder())
        .asFloatBuffer()

    // Cached static meshes
    private val carMeshCache = mutableMapOf<Pair<String, Boolean>, Mesh3D>()
    private lateinit var wheelMesh: Mesh3D
    private lateinit var suvWheelMesh: Mesh3D
    private lateinit var goldCoinMesh: Mesh3D
    private lateinit var turntableMesh: Mesh3D
    private lateinit var garageShedMesh: Mesh3D
    private lateinit var garageBayHighlightMesh: Mesh3D

    private val trafficMeshes = mutableMapOf<Pair<Int, Triple<Float, Float, Float>>, Mesh3D>()
    private lateinit var skyscraperVariants: List<Mesh3D>
    private lateinit var streetLightLeft: Mesh3D
    private lateinit var streetLightRight: Mesh3D
    private lateinit var villageHouses: List<Mesh3D>
    private lateinit var oakTreeMesh: Mesh3D
    private lateinit var farmFenceMesh: Mesh3D
    private lateinit var palmTreeMesh: Mesh3D
    private lateinit var jungleCanopyMesh: Mesh3D
    private lateinit var mountainPeaks: List<Mesh3D>

    private var lastTimeNs = System.nanoTime()
    private var menuTimeSec = 0f
    private var lastSeenResetGen = -1
    private var smoothCamOffsetX = 0f
    private var smoothLookOffsetX = 0f
    private var smoothGarageCamX = 0f

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glEnable(GLES20.GL_CULL_FACE)
        GLES20.glCullFace(GLES20.GL_BACK)

        program = createShaderProgram()
        mvpMatrixHandle = GLES20.glGetUniformLocation(program, "uMvpMatrix")
        modelMatrixHandle = GLES20.glGetUniformLocation(program, "uModelMatrix")
        lightDirHandle = GLES20.glGetUniformLocation(program, "uLightDir")
        fogColorHandle = GLES20.glGetUniformLocation(program, "uFogColor")
        fogDensityHandle = GLES20.glGetUniformLocation(program, "uFogDensity")

        posHandle = GLES20.glGetAttribLocation(program, "aPosition")
        normalHandle = GLES20.glGetAttribLocation(program, "aNormal")
        colorHandle = GLES20.glGetAttribLocation(program, "aColor")

        initMeshes()
        lastTimeNs = System.nanoTime()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        val aspect = width.toFloat() / height.coerceAtLeast(1).toFloat()
        Matrix.perspectiveM(projectionMatrix, 0, 56f, aspect, 0.4f, 260f)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = ((now - lastTimeNs) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
        lastTimeNs = now
        menuTimeSec += dt

        if (renderMode == RenderMode.RACE) {
            onFrameTick?.invoke(dt)
        }

        val activeMap = when (renderMode) {
            RenderMode.RACE -> raceEngine.currentMap
            RenderMode.MENU_SHOWCASE -> showcaseMap
            RenderMode.CAR_SHOWROOM -> showcaseMap
            RenderMode.GARAGE -> showcaseMap
        }

        val skyPalette = mapPalette(activeMap)
        if (renderMode == RenderMode.GARAGE) {
            GLES20.glClearColor(0.11f, 0.13f, 0.17f, 1f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
            GLES20.glUseProgram(program)
            GLES20.glUniform3f(lightDirHandle, 0.25f, 0.92f, 0.48f)
            GLES20.glUniform3f(fogColorHandle, 0.11f, 0.13f, 0.17f)
        } else {
            GLES20.glClearColor(skyPalette.horizonR, skyPalette.horizonG, skyPalette.horizonB, 1f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

            GLES20.glUseProgram(program)
            GLES20.glUniform3f(lightDirHandle, skyPalette.lightX, skyPalette.lightY, skyPalette.lightZ)
            GLES20.glUniform3f(fogColorHandle, skyPalette.horizonR, skyPalette.horizonG, skyPalette.horizonB)

            drawSkyGradient(skyPalette)
        }

        when (renderMode) {
            RenderMode.CAR_SHOWROOM -> drawShowroomScene(dt)
            RenderMode.GARAGE -> drawGarageScene(dt)
            RenderMode.MENU_SHOWCASE -> {
                val demoWave = sin(menuTimeSec * 0.55f)
                val demoDeriv = cos(menuTimeSec * 0.55f)
                drawTrackScene(
                    map = showcaseMap,
                    car = showcaseCar,
                    camZ = menuTimeSec * 20f,
                    playerX = demoWave * 2.4f,
                    headingDeg = demoDeriv * 11f,
                    steerAngle = demoDeriv * 18f,
                    rollAngle = demoDeriv * 3.8f,
                    pitchAngle = 0f,
                    wheelSpinDeg = (menuTimeSec * 720f) % 360f,
                    braking = false,
                    invulnBlink = false,
                    shake = 0f,
                    dt = dt,
                    isMenu = true
                )
            }
            RenderMode.RACE -> {
                val blink = raceEngine.invulnerabilityTimer > 0f && ((raceEngine.invulnerabilityTimer * 12f).toInt() % 2 == 0)
                drawTrackScene(
                    map = raceEngine.currentMap,
                    car = raceEngine.currentCar,
                    camZ = raceEngine.distanceZ,
                    playerX = raceEngine.playerX,
                    headingDeg = raceEngine.carHeadingDeg,
                    steerAngle = raceEngine.steerVisualAngle,
                    rollAngle = raceEngine.bodyRollAngle,
                    pitchAngle = raceEngine.bodyPitchAngle,
                    wheelSpinDeg = raceEngine.wheelSpinDeg,
                    braking = raceEngine.isBrakingVisual,
                    invulnBlink = blink,
                    shake = raceEngine.cameraShakeAmount,
                    dt = dt,
                    isMenu = false
                )
            }
        }
    }

    private fun drawShowroomScene(dt: Float) {
        GLES20.glUniform1f(fogDensityHandle, 0.0f)
        Matrix.setLookAtM(
            viewMatrix, 0,
            0f, 2.35f, 6.4f,
            0f, 0.65f, 0f,
            0f, 1f, 0f
        )
        Matrix.multiplyMM(vpMatrix, 0, projectionMatrix, 0, viewMatrix, 0)

        // Slow idle spin + user drag yaw
        showroomYawDeg = (showroomYawDeg + dt * 16f) % 360f

        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.rotateM(modelMatrix, 0, showroomYawDeg, 0f, 1f, 0f)
        drawMesh(turntableMesh, modelMatrix)

        drawSportsCar(
            car = showcaseCar,
            worldX = 0f,
            worldY = 0.02f,
            worldZ = 0f,
            yawDeg = showroomYawDeg,
            rollDeg = 0f,
            pitchDeg = 0f,
            steerDeg = 12f,
            wheelSpinDeg = (menuTimeSec * 80f) % 360f,
            braking = false
        )
    }

    private fun drawGarageScene(dt: Float) {
        GLES20.glUniform1f(fogDensityHandle, 0.008f)
        val cars = CarCatalog.allCars
        val baySpacing = 4.2f
        val startBayX = -((cars.size - 1) * baySpacing) * 0.5f
        val focusedIndex = cars.indexOfFirst { it.id == garageFocusedCarId }.coerceAtLeast(0)
        val targetFocusX = startBayX + focusedIndex * baySpacing
        smoothGarageCamX += (targetFocusX - smoothGarageCamX) * (dt * 5.0f).coerceIn(0f, 1f)

        // Elevated wide workshop camera showing the big shed and all parked cars side by side
        Matrix.setLookAtM(
            viewMatrix, 0,
            smoothGarageCamX * 0.34f, 4.15f, 12.8f,
            smoothGarageCamX * 0.42f, 1.15f, -0.4f,
            0f, 1f, 0f
        )
        Matrix.multiplyMM(vpMatrix, 0, projectionMatrix, 0, viewMatrix, 0)

        Matrix.setIdentityM(modelMatrix, 0)
        drawMesh(garageShedMesh, modelMatrix)

        cars.forEachIndexed { index, car ->
            val bayX = startBayX + index * baySpacing
            val isFocused = car.id == garageFocusedCarId
            val bayZ = if (isFocused) 0.65f else 0.0f

            if (isFocused) {
                Matrix.setIdentityM(modelMatrix, 0)
                Matrix.translateM(modelMatrix, 0, bayX, 0f, bayZ)
                Matrix.rotateM(modelMatrix, 0, 14f, 0f, 1f, 0f)
                drawMesh(garageBayHighlightMesh, modelMatrix)
            }

            drawSportsCar(
                car = car,
                worldX = bayX,
                worldY = 0.01f,
                worldZ = bayZ,
                yawDeg = 14f,
                rollDeg = 0f,
                pitchDeg = 0f,
                steerDeg = if (isFocused) 12f else 0f,
                wheelSpinDeg = 0f,
                braking = false
            )
        }
    }

    private fun drawTrackScene(
        map: GameMap,
        car: CarSpec,
        camZ: Float,
        playerX: Float,
        headingDeg: Float,
        steerAngle: Float,
        rollAngle: Float,
        pitchAngle: Float,
        wheelSpinDeg: Float,
        braking: Boolean,
        invulnBlink: Boolean,
        shake: Float,
        dt: Float,
        isMenu: Boolean
    ) {
        val fogDensity = when (map) {
            GameMap.CITY -> 0.0046f
            GameMap.VILLAGE -> 0.0034f
            GameMap.JUNGLE -> 0.0052f
        }
        GLES20.glUniform1f(fogDensityHandle, fogDensity)

        val playerCenterX = RaceEngine.trackCenterX(map, camZ) + playerX
        val playerY = RaceEngine.trackElevationY(map, camZ)

        if (isMenu || lastSeenResetGen != raceEngine.resetGeneration) {
            lastSeenResetGen = raceEngine.resetGeneration
            smoothCamOffsetX = playerX * 0.52f
            smoothLookOffsetX = playerX * 0.25f
        } else {
            val camLerp = (dt * 6.0f).coerceIn(0f, 1f)
            val lookLerp = (dt * 7.5f).coerceIn(0f, 1f)
            smoothCamOffsetX += (playerX * 0.52f - smoothCamOffsetX) * camLerp
            smoothLookOffsetX += (playerX * 0.25f + headingDeg * 0.08f - smoothLookOffsetX) * lookLerp
        }

        val shakeX = if (shake > 0f) sin(menuTimeSec * 48f) * 0.35f * shake else 0f
        val shakeY = if (shake > 0f) cos(menuTimeSec * 55f) * 0.25f * shake else 0f

        val eyeZ = camZ - 7.4f
        val eyeX = RaceEngine.trackCenterX(map, eyeZ) + smoothCamOffsetX + shakeX
        val eyeY = RaceEngine.trackElevationY(map, eyeZ) + 3.05f + shakeY

        val lookZ = camZ + 19f
        val lookX = RaceEngine.trackCenterX(map, lookZ) + smoothLookOffsetX
        val lookY = RaceEngine.trackElevationY(map, lookZ) + 1.0f

        Matrix.setLookAtM(
            viewMatrix, 0,
            eyeX, eyeY, eyeZ,
            lookX, lookY, lookZ,
            0f, 1f, 0f
        )
        Matrix.multiplyMM(vpMatrix, 0, projectionMatrix, 0, viewMatrix, 0)

        // 1. Dynamic 3D road & ground terrain
        drawDynamicRoadAndGround(map, camZ)

        // 2. Map-specific 3D environment props (City skyscrapers/streetlights, Village cottages/fields/trees, Jungle mountains/forest)
        drawMapScenery(map, camZ)

        if (!isMenu) {
            // 3. Spinning 3D Gold Coins
            val coinSpin = (menuTimeSec * 190f) % 360f
            val coinBob = sin(menuTimeSec * 4.5f) * 0.16f
            for (coin in raceEngine.goldCoins) {
                if (coin.z < camZ - 10f || coin.z > camZ + 200f) continue
                val cx = RaceEngine.trackCenterX(map, coin.z) + coin.x
                val cy = RaceEngine.trackElevationY(map, coin.z) + 0.95f + coinBob
                Matrix.setIdentityM(modelMatrix, 0)
                Matrix.translateM(modelMatrix, 0, cx, cy, coin.z)
                Matrix.rotateM(modelMatrix, 0, coinSpin, 0f, 1f, 0f)
                drawMesh(goldCoinMesh, modelMatrix)
            }

            // 4. 3D Traffic Vehicles
            for (v in raceEngine.trafficVehicles) {
                if (v.z < camZ - 16f || v.z > camZ + 210f) continue
                val vx = RaceEngine.trackCenterX(map, v.z) + v.x
                val vy = RaceEngine.trackElevationY(map, v.z)
                val vYaw = RaceEngine.trackSlopeAngle(map, v.z)
                val mesh = trafficMeshes.getOrPut(v.style to v.colorRgb) {
                    GlMeshBuilder.buildTrafficVehicle(v.colorRgb, v.style)
                }
                Matrix.setIdentityM(modelMatrix, 0)
                Matrix.translateM(modelMatrix, 0, vx, vy, v.z)
                Matrix.rotateM(modelMatrix, 0, vYaw, 0f, 1f, 0f)
                drawMesh(mesh, modelMatrix)
            }
        }

        // 5. Player's 3D Sports Car
        if (!invulnBlink) {
            val carYaw = RaceEngine.trackSlopeAngle(map, camZ) + headingDeg
            drawSportsCar(
                car = car,
                worldX = playerCenterX,
                worldY = playerY,
                worldZ = camZ,
                yawDeg = carYaw,
                rollDeg = rollAngle,
                pitchDeg = pitchAngle,
                steerDeg = steerAngle,
                wheelSpinDeg = wheelSpinDeg,
                braking = braking
            )
        }
    }

    private fun drawSportsCar(
        car: CarSpec,
        worldX: Float,
        worldY: Float,
        worldZ: Float,
        yawDeg: Float,
        rollDeg: Float,
        pitchDeg: Float,
        steerDeg: Float,
        wheelSpinDeg: Float,
        braking: Boolean
    ) {
        val isSuv = car.bodyStyle == CarBodyStyle.BOXY_SUV
        val bodyMesh = carMeshCache.getOrPut(car.id to braking) {
            if (isSuv) {
                GlMeshBuilder.buildBoxySuvBody(car, braking)
            } else {
                GlMeshBuilder.buildSportsCarBody(car, braking)
            }
        }
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, worldX, worldY, worldZ)
        Matrix.rotateM(modelMatrix, 0, yawDeg, 0f, 1f, 0f)
        Matrix.rotateM(modelMatrix, 0, rollDeg, 0f, 0f, 1f)
        Matrix.rotateM(modelMatrix, 0, pitchDeg, 1f, 0f, 0f)
        drawMesh(bodyMesh, modelMatrix)

        // Draw 4 independently rotating & steering 3D wheels (oversized off-road tires for Thar SUV)
        val activeWheelMesh = if (isSuv) suvWheelMesh else wheelMesh
        val wheelX = if (isSuv) 1.02f else 0.88f
        val wheelY = if (isSuv) 0.49f else 0.35f
        val wheelZ = if (isSuv) 1.38f else 1.32f
        val wheelConfigs = listOf(
            Triple(-wheelX, wheelZ, true),
            Triple(wheelX, wheelZ, true),
            Triple(-wheelX, -wheelZ, false),
            Triple(wheelX, -wheelZ, false)
        )
        for ((wx, wz, isFront) in wheelConfigs) {
            Matrix.setIdentityM(modelMatrix, 0)
            Matrix.translateM(modelMatrix, 0, worldX, worldY, worldZ)
            Matrix.rotateM(modelMatrix, 0, yawDeg, 0f, 1f, 0f)
            Matrix.translateM(modelMatrix, 0, wx, wheelY, wz)
            if (isFront) {
                Matrix.rotateM(modelMatrix, 0, steerDeg, 0f, 1f, 0f)
            }
            Matrix.rotateM(modelMatrix, 0, wheelSpinDeg, 1f, 0f, 0f)
            drawMesh(activeWheelMesh, modelMatrix)
        }
    }

    private fun drawDynamicRoadAndGround(map: GameMap, camZ: Float) {
        roadFloatCount = 0
        val step = 4f
        val startZ = floor((camZ - 16f) / step) * step
        val segments = 52
        val hw = map.roadHalfWidth
        val curbW = 0.65f
        val groundSpan = 105f

        val (groundR, groundG, groundB) = when (map) {
            GameMap.CITY -> Triple(0.16f, 0.19f, 0.25f)
            GameMap.VILLAGE -> Triple(0.16f, 0.54f, 0.19f)
            GameMap.JUNGLE -> Triple(0.07f, 0.32f, 0.14f)
        }
        val (roadR, roadG, roadB) = when (map) {
            GameMap.CITY -> Triple(0.11f, 0.13f, 0.17f)
            GameMap.VILLAGE -> Triple(0.26f, 0.27f, 0.29f)
            GameMap.JUNGLE -> Triple(0.19f, 0.20f, 0.22f)
        }

        for (i in 0 until segments) {
            val z0 = startZ + i * step
            val z1 = z0 + step
            val segIdx = (z0 / step).toInt()
            val cx0 = RaceEngine.trackCenterX(map, z0)
            val cy0 = RaceEngine.trackElevationY(map, z0)
            val cx1 = RaceEngine.trackCenterX(map, z1)
            val cy1 = RaceEngine.trackElevationY(map, z1)

            // Alternating terrain patch tint for rich speed sensation
            val alt = if (abs(segIdx) % 2 == 0) 1.0f else 0.88f
            val gR = if (map == GameMap.VILLAGE && abs(segIdx) % 5 == 0) 0.72f else groundR * alt
            val gG = if (map == GameMap.VILLAGE && abs(segIdx) % 5 == 0) 0.62f else groundG * alt
            val gB = if (map == GameMap.VILLAGE && abs(segIdx) % 5 == 0) 0.22f else groundB * alt

            // Left & Right terrain strips
            pushRoadQuad(
                cx0 - groundSpan, cy0 - 0.12f, z0,
                cx0 - hw - curbW, cy0 - 0.04f, z0,
                cx1 - hw - curbW, cy1 - 0.04f, z1,
                cx1 - groundSpan, cy1 - 0.12f, z1,
                gR, gG, gB
            )
            pushRoadQuad(
                cx0 + hw + curbW, cy0 - 0.04f, z0,
                cx0 + groundSpan, cy0 - 0.12f, z0,
                cx1 + groundSpan, cy1 - 0.12f, z1,
                cx1 + hw + curbW, cy1 - 0.04f, z1,
                gR, gG, gB
            )

            // Curbs / road shoulders
            val curbTint = if (abs(segIdx) % 2 == 0) {
                when (map) {
                    GameMap.CITY -> Triple(0.75f, 0.78f, 0.84f)
                    GameMap.VILLAGE -> Triple(0.56f, 0.44f, 0.30f)
                    GameMap.JUNGLE -> Triple(0.45f, 0.36f, 0.24f)
                }
            } else {
                when (map) {
                    GameMap.CITY -> Triple(0.92f, 0.22f, 0.22f)
                    GameMap.VILLAGE -> Triple(0.64f, 0.52f, 0.36f)
                    GameMap.JUNGLE -> Triple(0.32f, 0.36f, 0.32f)
                }
            }
            pushRoadQuad(
                cx0 - hw - curbW, cy0 + 0.02f, z0,
                cx0 - hw, cy0 + 0.02f, z0,
                cx1 - hw, cy1 + 0.02f, z1,
                cx1 - hw - curbW, cy1 + 0.02f, z1,
                curbTint.first, curbTint.second, curbTint.third
            )
            pushRoadQuad(
                cx0 + hw, cy0 + 0.02f, z0,
                cx0 + hw + curbW, cy0 + 0.02f, z0,
                cx1 + hw + curbW, cy1 + 0.02f, z1,
                cx1 + hw, cy1 + 0.02f, z1,
                curbTint.first, curbTint.second, curbTint.third
            )

            // Asphalt road surface
            val rAlt = if (abs(segIdx) % 2 == 0) 1.0f else 0.94f
            pushRoadQuad(
                cx0 - hw, cy0, z0,
                cx0 + hw, cy0, z0,
                cx1 + hw, cy1, z1,
                cx1 - hw, cy1, z1,
                roadR * rAlt, roadG * rAlt, roadB * rAlt
            )

            // Lane dividers
            if (map == GameMap.CITY) {
                // Yellow double center line + dashed outer lane lines
                pushRoadQuad(
                    cx0 - 0.14f, cy0 + 0.025f, z0,
                    cx0 + 0.14f, cy0 + 0.025f, z0,
                    cx1 + 0.14f, cy1 + 0.025f, z1,
                    cx1 - 0.14f, cy1 + 0.025f, z1,
                    0.96f, 0.78f, 0.14f
                )
                if (abs(segIdx) % 2 == 0) {
                    val laneOffsets = floatArrayOf(-3.5f, 3.5f)
                    for (lo in laneOffsets) {
                        pushRoadQuad(
                            cx0 + lo - 0.10f, cy0 + 0.025f, z0,
                            cx0 + lo + 0.10f, cy0 + 0.025f, z0,
                            cx1 + lo + 0.10f, cy1 + 0.025f, z1,
                            cx1 + lo - 0.10f, cy1 + 0.025f, z1,
                            0.94f, 0.96f, 1.0f
                        )
                    }
                }
            } else {
                // Dashed center line for Village & Jungle 2-lane roads
                if (abs(segIdx) % 2 == 0) {
                    pushRoadQuad(
                        cx0 - 0.12f, cy0 + 0.025f, z0,
                        cx0 + 0.12f, cy0 + 0.025f, z0,
                        cx1 + 0.12f, cy1 + 0.025f, z1,
                        cx1 - 0.12f, cy1 + 0.025f, z1,
                        0.96f, 0.92f, 0.72f
                    )
                }
            }
        }

        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.multiplyMM(mvpMatrix, 0, vpMatrix, 0, modelMatrix, 0)
        GLES20.glUniformMatrix4fv(mvpMatrixHandle, 1, false, mvpMatrix, 0)
        GLES20.glUniformMatrix4fv(modelMatrixHandle, 1, false, modelMatrix, 0)

        roadBuffer.clear()
        roadBuffer.put(roadFloatArray, 0, roadFloatCount)
        roadBuffer.position(0)

        GLES20.glVertexAttribPointer(posHandle, 3, GLES20.GL_FLOAT, false, Mesh3D.STRIDE_BYTES, roadBuffer)
        GLES20.glEnableVertexAttribArray(posHandle)
        roadBuffer.position(3)
        GLES20.glVertexAttribPointer(normalHandle, 3, GLES20.GL_FLOAT, false, Mesh3D.STRIDE_BYTES, roadBuffer)
        GLES20.glEnableVertexAttribArray(normalHandle)
        roadBuffer.position(6)
        GLES20.glVertexAttribPointer(colorHandle, 4, GLES20.GL_FLOAT, false, Mesh3D.STRIDE_BYTES, roadBuffer)
        GLES20.glEnableVertexAttribArray(colorHandle)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, roadFloatCount / Mesh3D.FLOATS_PER_VERTEX)
    }

    private fun drawMapScenery(map: GameMap, camZ: Float) {
        val spacing = when (map) {
            GameMap.CITY -> 18f
            GameMap.VILLAGE -> 20f
            GameMap.JUNGLE -> 16f
        }
        val firstSeg = floor((camZ - 12f) / spacing).toInt()
        val lastSeg = floor((camZ + 205f) / spacing).toInt()

        for (seg in firstSeg..lastSeg) {
            val z = seg * spacing
            val cx = RaceEngine.trackCenterX(map, z)
            val cy = RaceEngine.trackElevationY(map, z)
            val slopeYaw = RaceEngine.trackSlopeAngle(map, z)
            val hash = abs(seg * 73856093 xor 19349663)

            when (map) {
                GameMap.CITY -> {
                    // Street lights on both sidewalks aligned with road curve
                    drawRoadsideMesh(streetLightLeft, cx, cy, z, slopeYaw, -map.roadHalfWidth - 1.2f)
                    drawRoadsideMesh(streetLightRight, cx, cy, z, slopeYaw, map.roadHalfWidth + 1.2f)

                    // Modern skyscrapers flanking left & right avenues
                    val leftBldg = skyscraperVariants[hash % skyscraperVariants.size]
                    val rightBldg = skyscraperVariants[(hash / 7) % skyscraperVariants.size]
                    drawRoadsideMesh(leftBldg, cx, cy, z, slopeYaw, -map.roadHalfWidth - 10.5f)
                    drawRoadsideMesh(rightBldg, cx, cy, z, slopeYaw, map.roadHalfWidth + 10.5f)
                }

                GameMap.VILLAGE -> {
                    // Wooden fence + hay bales on alternating sides
                    if (seg % 2 == 0) {
                        drawRoadsideMesh(farmFenceMesh, cx, cy, z, slopeYaw, -map.roadHalfWidth - 2.2f)
                    }
                    // Village houses + oak trees
                    if (hash % 3 == 0) {
                        val house = villageHouses[hash % villageHouses.size]
                        drawRoadsideMesh(house, cx, cy, z, slopeYaw, map.roadHalfWidth + 7.5f)
                    } else {
                        drawRoadsideMesh(oakTreeMesh, cx, cy, z, slopeYaw, map.roadHalfWidth + 5.2f)
                    }
                    if ((hash / 5) % 4 == 0) {
                        val house = villageHouses[(hash / 3) % villageHouses.size]
                        drawRoadsideMesh(house, cx, cy, z + 4f, slopeYaw, -map.roadHalfWidth - 8.5f)
                    } else {
                        drawRoadsideMesh(oakTreeMesh, cx, cy, z, slopeYaw, -map.roadHalfWidth - 5.4f)
                    }
                }

                GameMap.JUNGLE -> {
                    // Dense palm and canopy trees lining both sides
                    val leftTree = if (hash % 2 == 0) palmTreeMesh else jungleCanopyMesh
                    val rightTree = if ((hash / 3) % 2 == 0) jungleCanopyMesh else palmTreeMesh

                    drawRoadsideMesh(leftTree, cx, cy, z, slopeYaw, -map.roadHalfWidth - 4.4f - (hash % 4))
                    drawRoadsideMesh(rightTree, cx, cy, z, slopeYaw, map.roadHalfWidth + 4.4f + ((hash / 5) % 4))

                    // Second deeper layer of forest
                    drawRoadsideMesh(jungleCanopyMesh, cx, cy, z + 6f, slopeYaw, -map.roadHalfWidth - 13f)
                    drawRoadsideMesh(jungleCanopyMesh, cx, cy, z + 6f, slopeYaw, map.roadHalfWidth + 13f)

                    // Towering background mountain peaks every 3 segments
                    if (seg % 3 == 0) {
                        val mLeft = mountainPeaks[hash % mountainPeaks.size]
                        val mRight = mountainPeaks[(hash + 1) % mountainPeaks.size]
                        drawRoadsideMesh(mLeft, cx, cy, z, slopeYaw, -44f)
                        drawRoadsideMesh(mRight, cx, cy, z + 10f, slopeYaw, 44f)
                    }
                }
            }
        }
    }

    private fun drawRoadsideMesh(
        mesh: Mesh3D,
        centerX: Float,
        centerY: Float,
        centerZ: Float,
        roadYawDeg: Float,
        lateralOffsetX: Float
    ) {
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, centerX, centerY, centerZ)
        Matrix.rotateM(modelMatrix, 0, roadYawDeg, 0f, 1f, 0f)
        Matrix.translateM(modelMatrix, 0, lateralOffsetX, 0f, 0f)
        drawMesh(mesh, modelMatrix)
    }

    private fun drawMesh(mesh: Mesh3D, model: FloatArray) {
        Matrix.multiplyMM(mvpMatrix, 0, vpMatrix, 0, model, 0)
        GLES20.glUniformMatrix4fv(mvpMatrixHandle, 1, false, mvpMatrix, 0)
        GLES20.glUniformMatrix4fv(modelMatrixHandle, 1, false, model, 0)
        mesh.draw(posHandle, normalHandle, colorHandle)
    }

    private fun drawSkyGradient(palette: MapVisualPalette) {
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glUniform1f(fogDensityHandle, 0f)
        val identity = FloatArray(16).also { Matrix.setIdentityM(it, 0) }
        GLES20.glUniformMatrix4fv(mvpMatrixHandle, 1, false, identity, 0)
        GLES20.glUniformMatrix4fv(modelMatrixHandle, 1, false, identity, 0)

        // Fullscreen quad in NDC
        val zR = palette.zenithR
        val zG = palette.zenithG
        val zB = palette.zenithB
        val hR = palette.horizonR
        val hG = palette.horizonG
        val hB = palette.horizonB

        val verts = floatArrayOf(
            -1f, -1f, 0.99f, 0f, 1f, 0f, hR, hG, hB, 1f,
             1f, -1f, 0.99f, 0f, 1f, 0f, hR, hG, hB, 1f,
             1f,  1f, 0.99f, 0f, 1f, 0f, zR, zG, zB, 1f,
            -1f, -1f, 0.99f, 0f, 1f, 0f, hR, hG, hB, 1f,
             1f,  1f, 0.99f, 0f, 1f, 0f, zR, zG, zB, 1f,
            -1f,  1f, 0.99f, 0f, 1f, 0f, zR, zG, zB, 1f
        )
        skyBuffer.clear()
        skyBuffer.put(verts)
        skyBuffer.position(0)

        GLES20.glVertexAttribPointer(posHandle, 3, GLES20.GL_FLOAT, false, Mesh3D.STRIDE_BYTES, skyBuffer)
        GLES20.glEnableVertexAttribArray(posHandle)
        skyBuffer.position(3)
        GLES20.glVertexAttribPointer(normalHandle, 3, GLES20.GL_FLOAT, false, Mesh3D.STRIDE_BYTES, skyBuffer)
        GLES20.glEnableVertexAttribArray(normalHandle)
        skyBuffer.position(6)
        GLES20.glVertexAttribPointer(colorHandle, 4, GLES20.GL_FLOAT, false, Mesh3D.STRIDE_BYTES, skyBuffer)
        GLES20.glEnableVertexAttribArray(colorHandle)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
    }

    private fun pushRoadQuad(
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        x3: Float, y3: Float, z3: Float,
        x4: Float, y4: Float, z4: Float,
        r: Float, g: Float, b: Float
    ) {
        if (roadFloatCount + 60 >= maxRoadFloats) return
        // Notice winding order for upward +Y normal: (x1,z1)->(x4,z4)->(x3,z3)
        pushRoadVertex(x1, y1, z1, r, g, b)
        pushRoadVertex(x4, y4, z4, r, g, b)
        pushRoadVertex(x3, y3, z3, r, g, b)

        pushRoadVertex(x1, y1, z1, r, g, b)
        pushRoadVertex(x3, y3, z3, r, g, b)
        pushRoadVertex(x2, y2, z2, r, g, b)
    }

    private fun pushRoadVertex(x: Float, y: Float, z: Float, r: Float, g: Float, b: Float) {
        roadFloatArray[roadFloatCount++] = x
        roadFloatArray[roadFloatCount++] = y
        roadFloatArray[roadFloatCount++] = z
        roadFloatArray[roadFloatCount++] = 0f
        roadFloatArray[roadFloatCount++] = 1f
        roadFloatArray[roadFloatCount++] = 0f
        roadFloatArray[roadFloatCount++] = r
        roadFloatArray[roadFloatCount++] = g
        roadFloatArray[roadFloatCount++] = b
        roadFloatArray[roadFloatCount++] = 1f
    }


    private fun initMeshes() {
        wheelMesh = GlMeshBuilder.buildWheel()
        suvWheelMesh = GlMeshBuilder.buildWheel(tireRadius = 0.49f, rimRadius = 0.27f, halfWidth = 0.21f)
        goldCoinMesh = GlMeshBuilder.buildGoldCoin()
        turntableMesh = GlMeshBuilder.buildShowroomTurntable()
        garageShedMesh = GlMeshBuilder.buildGarageShed()
        garageBayHighlightMesh = GlMeshBuilder.buildGarageBayHighlight()

        skyscraperVariants = listOf(
            GlMeshBuilder.buildSkyscraper(34f, 9f, 9f, Triple(0.14f, 0.22f, 0.34f), Triple(0.42f, 0.86f, 0.98f)),
            GlMeshBuilder.buildSkyscraper(46f, 10f, 10f, Triple(0.18f, 0.20f, 0.28f), Triple(0.98f, 0.84f, 0.42f)),
            GlMeshBuilder.buildSkyscraper(26f, 8.5f, 8.5f, Triple(0.22f, 0.26f, 0.36f), Triple(0.94f, 0.56f, 0.32f)),
            GlMeshBuilder.buildSkyscraper(54f, 11f, 11f, Triple(0.10f, 0.16f, 0.26f), Triple(0.55f, 0.92f, 1.0f))
        )
        streetLightLeft = GlMeshBuilder.buildStreetLight(1f)
        streetLightRight = GlMeshBuilder.buildStreetLight(-1f)

        villageHouses = listOf(
            GlMeshBuilder.buildVillageHouse(Triple(0.96f, 0.92f, 0.82f), Triple(0.82f, 0.26f, 0.20f)),
            GlMeshBuilder.buildVillageHouse(Triple(0.92f, 0.84f, 0.66f), Triple(0.24f, 0.42f, 0.66f)),
            GlMeshBuilder.buildVillageHouse(Triple(0.95f, 0.88f, 0.78f), Triple(0.68f, 0.34f, 0.16f))
        )
        oakTreeMesh = GlMeshBuilder.buildOakTree()
        farmFenceMesh = GlMeshBuilder.buildFarmFenceAndHay()

        palmTreeMesh = GlMeshBuilder.buildPalmTree()
        jungleCanopyMesh = GlMeshBuilder.buildJungleCanopyTree()
        mountainPeaks = listOf(
            GlMeshBuilder.buildMountainPeak(36f, 32f),
            GlMeshBuilder.buildMountainPeak(44f, 42f),
            GlMeshBuilder.buildMountainPeak(32f, 26f)
        )
    }

    private data class MapVisualPalette(
        val zenithR: Float, val zenithG: Float, val zenithB: Float,
        val horizonR: Float, val horizonG: Float, val horizonB: Float,
        val lightX: Float, val lightY: Float, val lightZ: Float
    )

    private fun mapPalette(map: GameMap): MapVisualPalette = when (map) {
        GameMap.CITY -> MapVisualPalette(
            zenithR = 0.05f, zenithG = 0.08f, zenithB = 0.18f,
            horizonR = 0.16f, horizonG = 0.26f, horizonB = 0.44f,
            lightX = 0.45f, lightY = 0.78f, lightZ = -0.35f
        )
        GameMap.VILLAGE -> MapVisualPalette(
            zenithR = 0.18f, zenithG = 0.56f, zenithB = 0.92f,
            horizonR = 0.72f, horizonG = 0.90f, horizonB = 0.98f,
            lightX = 0.55f, lightY = 0.85f, lightZ = 0.30f
        )
        GameMap.JUNGLE -> MapVisualPalette(
            zenithR = 0.06f, zenithG = 0.28f, zenithB = 0.26f,
            horizonR = 0.42f, horizonG = 0.78f, horizonB = 0.64f,
            lightX = 0.35f, lightY = 0.88f, lightZ = -0.25f
        )
    }

    private fun createShaderProgram(): Int {
        val vertexShaderCode = """
            uniform mat4 uMvpMatrix;
            uniform mat4 uModelMatrix;
            attribute vec4 aPosition;
            attribute vec3 aNormal;
            attribute vec4 aColor;
            varying vec4 vColor;
            varying vec3 vNormal;
            varying float vDepth;
            void main() {
                vec4 clipPos = uMvpMatrix * aPosition;
                gl_Position = clipPos;
                vNormal = normalize((uModelMatrix * vec4(aNormal, 0.0)).xyz);
                vColor = aColor;
                vDepth = clipPos.z;
            }
        """.trimIndent()

        val fragmentShaderCode = """
            precision mediump float;
            uniform vec3 uLightDir;
            uniform vec3 uFogColor;
            uniform float uFogDensity;
            varying vec4 vColor;
            varying vec3 vNormal;
            varying float vDepth;
            void main() {
                float diff = max(dot(normalize(vNormal), normalize(uLightDir)), 0.0);
                float lighting = 0.48 + 0.52 * diff;
                vec3 litColor = vColor.rgb * lighting;
                float fogFactor = 1.0 - exp(-pow(max(vDepth, 0.0) * uFogDensity, 2.0));
                vec3 finalRgb = mix(litColor, uFogColor, clamp(fogFactor, 0.0, 1.0));
                gl_FragColor = vec4(finalRgb, vColor.a);
            }
        """.trimIndent()

        val vs = compileShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode)
        val fs = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode)
        return GLES20.glCreateProgram().also { prog ->
            GLES20.glAttachShader(prog, vs)
            GLES20.glAttachShader(prog, fs)
            GLES20.glLinkProgram(prog)
        }
    }

    private fun compileShader(type: Int, code: String): Int {
        return GLES20.glCreateShader(type).also { shader ->
            GLES20.glShaderSource(shader, code)
            GLES20.glCompileShader(shader)
        }
    }
}
