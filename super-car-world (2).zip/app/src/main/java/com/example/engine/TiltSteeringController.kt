package com.example.engine

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.view.Surface
import android.view.WindowManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Pure sensor fusion & medium-sensitivity tilt-to-steer processor.
 * Combines display-rotation-aware Accelerometer gravity tilt with optional Gyroscope angular rate
 * so tilting phone LEFT produces positive (+X screen-left) steering and tilting RIGHT produces negative (-X screen-right).
 */
class TiltSteeringProcessor {
    private var initialized = false
    private var fusedTilt = 0f
    private var upX = 0f
    private var upY = 1f
    private var upZ = 0f
    private var lastGyroTimestampNs = 0L

    fun reset() {
        initialized = false
        fusedTilt = 0f
        upX = 0f
        upY = 1f
        upZ = 0f
        lastGyroTimestampNs = 0L
    }

    fun onAccelerometerSample(
        ax: Float,
        ay: Float,
        az: Float,
        displayRotation: Int
    ): Float {
        val norm = sqrt(ax * ax + ay * ay + az * az)
        if (norm > 1.0f) {
            val inv = 1f / norm
            // Smooth estimated world-UP vector in device coordinates for gyro projection
            if (!initialized) {
                upX = ax * inv
                upY = ay * inv
                upZ = az * inv
            } else {
                upX = upX * 0.78f + (ax * inv) * 0.22f
                upY = upY * 0.78f + (ay * inv) * 0.22f
                upZ = upZ * 0.78f + (az * inv) * 0.22f
            }
        }

        val rawScreenRight = extractScreenRightGravity(ax, ay, displayRotation) / SensorManager.GRAVITY_EARTH
        val accelTilt = rawScreenRight.coerceIn(-1f, 1f)

        fusedTilt = if (!initialized) {
            initialized = true
            accelTilt * 0.35f
        } else {
            fusedTilt * 0.78f + accelTilt * 0.22f
        }
        return mapTiltToSteerAxis(fusedTilt)
    }

    fun onGyroscopeSample(
        gx: Float,
        gy: Float,
        gz: Float,
        timestampNs: Long,
        displayRotation: Int
    ): Float? {
        if (!initialized) return null
        if (lastGyroTimestampNs == 0L) {
            lastGyroTimestampNs = timestampNs
            return null
        }
        val dt = ((timestampNs - lastGyroTimestampNs) * 1e-9f).coerceIn(0f, 0.05f)
        lastGyroTimestampNs = timestampNs
        if (dt <= 0f) return null

        // Rate of change of dot(screenRight, worldUp) = omega dot (screenRight x worldUp)
        val (rx, ry) = screenRightUnitAxis(displayRotation)
        val crossX = ry * upZ
        val crossY = -rx * upZ
        val crossZ = rx * upY - ry * upX
        val tiltRate = gx * crossX + gy * crossY + gz * crossZ

        fusedTilt = (fusedTilt + tiltRate * dt * 0.85f).coerceIn(-1f, 1f)
        return mapTiltToSteerAxis(fusedTilt)
    }

    companion object {
        private const val DEADZONE = 0.065f
        private const val MAX_TILT_SIN = 0.48f // ~29 deg comfortable medium steering full lock

        internal fun screenRightUnitAxis(displayRotation: Int): Pair<Float, Float> = when (displayRotation) {
            Surface.ROTATION_0 -> 1f to 0f
            Surface.ROTATION_90 -> 0f to -1f
            Surface.ROTATION_180 -> -1f to 0f
            Surface.ROTATION_270 -> 0f to 1f
            else -> 0f to -1f
        }

        internal fun extractScreenRightGravity(ax: Float, ay: Float, displayRotation: Int): Float =
            when (displayRotation) {
                Surface.ROTATION_0 -> ax
                Surface.ROTATION_90 -> -ay
                Surface.ROTATION_180 -> -ax
                Surface.ROTATION_270 -> ay
                else -> -ay
            }

        /**
         * Maps normalized left-positive tilt (-1..1) with deadzone and medium-sensitivity curve.
         */
        fun mapTiltToSteerAxis(rawTilt: Float): Float {
            val mag = abs(rawTilt)
            if (mag <= DEADZONE) return 0f
            val normalized = ((mag - DEADZONE) / (MAX_TILT_SIN - DEADZONE)).coerceIn(0f, 1f)
            val curved = normalized.pow(1.25f)
            return if (rawTilt >= 0f) curved else -curved
        }
    }
}

@Composable
fun TiltSteeringMonitor(
    enabled: Boolean,
    onTiltSteerChanged: (Float) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val currentOnTiltChanged by rememberUpdatedState(onTiltSteerChanged)
    var isResumed by remember {
        mutableStateOf(lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED))
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> isResumed = true
                Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP -> isResumed = false
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val active = enabled && isResumed
    DisposableEffect(context, active) {
        if (!active) {
            currentOnTiltChanged(0f)
            return@DisposableEffect onDispose { }
        }

        val appContext = context.applicationContext
        val sensorManager = appContext.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            ?: sensorManager?.getDefaultSensor(Sensor.TYPE_GRAVITY)
        val gyroscope = sensorManager?.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

        if (sensorManager == null || accelerometer == null) {
            currentOnTiltChanged(0f)
            return@DisposableEffect onDispose { }
        }

        val processor = TiltSteeringProcessor()
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                val rotation = currentDisplayRotation(context)
                when (event.sensor.type) {
                    Sensor.TYPE_ACCELEROMETER, Sensor.TYPE_GRAVITY -> {
                        if (event.values.size >= 3) {
                            val steer = processor.onAccelerometerSample(
                                ax = event.values[0],
                                ay = event.values[1],
                                az = event.values[2],
                                displayRotation = rotation
                            )
                            currentOnTiltChanged(steer)
                        }
                    }
                    Sensor.TYPE_GYROSCOPE -> {
                        if (event.values.size >= 3) {
                            processor.onGyroscopeSample(
                                gx = event.values[0],
                                gy = event.values[1],
                                gz = event.values[2],
                                timestampNs = event.timestamp,
                                displayRotation = rotation
                            )?.let { steer ->
                                currentOnTiltChanged(steer)
                            }
                        }
                    }
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }

        sensorManager.registerListener(listener, accelerometer, SensorManager.SENSOR_DELAY_GAME)
        if (gyroscope != null) {
            sensorManager.registerListener(listener, gyroscope, SensorManager.SENSOR_DELAY_GAME)
        }

        onDispose {
            sensorManager.unregisterListener(listener)
            processor.reset()
            currentOnTiltChanged(0f)
        }
    }
}

@Suppress("DEPRECATION")
private fun currentDisplayRotation(context: Context): Int {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        runCatching { context.display.rotation }
            .getOrNull()
            ?.let { return it }
    }
    val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
    return runCatching { wm?.defaultDisplay?.rotation ?: Surface.ROTATION_90 }
        .getOrDefault(Surface.ROTATION_90)
}
