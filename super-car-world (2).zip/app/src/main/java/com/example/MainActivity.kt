package com.example

import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.engine.RenderMode
import com.example.ui.GameViewModel
import com.example.ui.screens.GarageScreen
import com.example.ui.screens.MainMenuScreen
import com.example.ui.screens.RaceScreen
import com.example.ui.screens.SelectCarScreen
import com.example.ui.screens.SelectMapScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.SuperCarWorldTheme

object Routes {
    const val MAIN_MENU = "main_menu"
    const val SELECT_MAP = "select_map"
    const val SELECT_CAR = "select_car"
    const val GARAGE = "garage"
    const val SETTINGS = "settings"
    const val RACE = "race"
}

class MainActivity : ComponentActivity() {

    private val viewModel: GameViewModel by viewModels {
        GameViewModel.Factory(application)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        hideSystemBars()
        setContent {
            SuperCarWorldTheme {
                SuperCarWorldApp(viewModel = viewModel)
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            hideSystemBars()
        }
    }

    override fun onResume() {
        super.onResume()
        hideSystemBars()
        viewModel.onAppResumed(true)
    }

    override fun onPause() {
        super.onPause()
        viewModel.onAppResumed(false)
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }
}

@Composable
fun SuperCarWorldApp(viewModel: GameViewModel) {
    val navController = rememberNavController()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val hudState by viewModel.hudState.collectAsStateWithLifecycle()

    NavHost(
        navController = navController,
        startDestination = Routes.MAIN_MENU
    ) {
        composable(Routes.MAIN_MENU) {
            LaunchedEffect(Unit) {
                viewModel.setRenderMode(RenderMode.MENU_SHOWCASE)
            }
            MainMenuScreen(
                renderer = viewModel.renderer,
                settings = settings,
                onPlayClick = {
                    viewModel.startRace()
                    navController.navigate(Routes.RACE) {
                        launchSingleTop = true
                    }
                },
                onSelectMapClick = {
                    viewModel.playClickSound()
                    navController.navigate(Routes.SELECT_MAP) {
                        launchSingleTop = true
                    }
                },
                onSelectCarClick = {
                    viewModel.playClickSound()
                    navController.navigate(Routes.SELECT_CAR) {
                        launchSingleTop = true
                    }
                },
                onGarageClick = {
                    viewModel.playClickSound()
                    navController.navigate(Routes.GARAGE) {
                        launchSingleTop = true
                    }
                },
                onSettingsClick = {
                    viewModel.playClickSound()
                    navController.navigate(Routes.SETTINGS) {
                        launchSingleTop = true
                    }
                }
            )
        }

        composable(Routes.SELECT_MAP) {
            SelectMapScreen(
                settings = settings,
                onSelectMap = { map ->
                    viewModel.selectMap(map)
                },
                onPlayMap = { map ->
                    viewModel.selectMap(map)
                    viewModel.startRace(mapOverride = map)
                    navController.navigate(Routes.RACE) {
                        popUpTo(Routes.MAIN_MENU)
                        launchSingleTop = true
                    }
                },
                onBack = {
                    viewModel.playClickSound()
                    navController.popBackStack()
                }
            )
        }

        composable(Routes.SELECT_CAR) {
            LaunchedEffect(Unit) {
                viewModel.setRenderMode(RenderMode.CAR_SHOWROOM)
            }
            SelectCarScreen(
                renderer = viewModel.renderer,
                settings = settings,
                onSelectCar = { car ->
                    viewModel.selectCar(car)
                },
                onPreviewCar = { car ->
                    viewModel.playClickSound()
                    viewModel.previewCarInShowroom(car)
                },
                onUnlockCar = { carId ->
                    viewModel.unlockCar(carId)
                },
                onPurchaseUpgrade = { carId, stat ->
                    viewModel.purchaseUpgrade(carId, stat)
                },
                onRotateShowroom = { delta ->
                    viewModel.rotateShowroom(delta)
                },
                onRaceNow = { car ->
                    viewModel.selectCar(car)
                    viewModel.startRace(carOverride = car)
                    navController.navigate(Routes.RACE) {
                        popUpTo(Routes.MAIN_MENU)
                        launchSingleTop = true
                    }
                },
                onBack = {
                    viewModel.playClickSound()
                    navController.popBackStack()
                }
            )
        }

        composable(Routes.GARAGE) {
            LaunchedEffect(Unit) {
                viewModel.renderer.garageFocusedCarId = settings.selectedCarId
                viewModel.setRenderMode(RenderMode.GARAGE)
            }
            GarageScreen(
                renderer = viewModel.renderer,
                settings = settings,
                onSelectCar = { car ->
                    viewModel.selectCar(car)
                },
                onUnlockCar = { carId ->
                    viewModel.unlockCar(carId)
                },
                onPreviewCar = { car ->
                    viewModel.playClickSound()
                    viewModel.previewCarInShowroom(car)
                },
                onRaceNow = {
                    viewModel.startRace()
                    navController.navigate(Routes.RACE) {
                        popUpTo(Routes.MAIN_MENU)
                        launchSingleTop = true
                    }
                },
                onBack = {
                    viewModel.playClickSound()
                    navController.popBackStack()
                }
            )
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(
                settings = settings,
                onToggleSfx = { viewModel.setSoundEffectsEnabled(it) },
                onToggleMusic = { viewModel.setMusicEnabled(it) },
                onResetScores = { viewModel.resetBestScores() },
                onBack = {
                    viewModel.playClickSound()
                    navController.popBackStack()
                }
            )
        }

        composable(Routes.RACE) {
            LaunchedEffect(Unit) {
                viewModel.setRenderMode(RenderMode.RACE)
            }
            RaceScreen(
                renderer = viewModel.renderer,
                hudState = hudState,
                settings = settings,
                onTiltSteerChanged = { viewModel.updateTiltSteer(it) },
                onLeftChanged = { viewModel.updateLeftPressed(it) },
                onRightChanged = { viewModel.updateRightPressed(it) },
                onAccelerateChanged = { viewModel.updateAcceleratePressed(it) },
                onBrakeChanged = { viewModel.updateBrakePressed(it) },
                onPause = { viewModel.pauseRace() },
                onResume = { viewModel.resumeRace() },
                onRestart = { viewModel.restartRace() },
                onExitToMenu = {
                    viewModel.exitRaceToMenu()
                    navController.popBackStack(Routes.MAIN_MENU, inclusive = false)
                },
                onToggleSfx = { viewModel.setSoundEffectsEnabled(it) },
                onToggleMusic = { viewModel.setMusicEnabled(it) }
            )
        }
    }
}
