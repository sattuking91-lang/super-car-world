package com.example

import android.view.Surface
import com.example.engine.RaceEngine
import com.example.engine.TiltSteeringProcessor
import com.example.model.CarCatalog
import com.example.model.CarUpgrades
import com.example.model.ControlInput
import com.example.model.GameMap
import com.example.model.GoldCoin
import com.example.model.TrafficVehicle
import com.example.model.UpgradeStat
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RaceEngineTest {

    @Test
    fun accelerateIncreasesSpeedCoastSlowsSlowlyAndBrakeStopsCar() {
        val engine = RaceEngine(initialMap = GameMap.CITY, initialCar = CarCatalog.RED_SPORTS_CAR)
        assertEquals("Car starts stationary until RACE / GAS is pressed", 0f, engine.speedMps, 0.001f)

        repeat(45) {
            engine.step(0.016f, ControlInput(acceleratePressed = true))
        }
        assertTrue("RACE/GAS should accelerate car forward", engine.speedMps > 12f)
        assertTrue("Car should move forward along Z", engine.distanceZ > 5f)

        // Releasing RACE / GAS slows down slowly (gentler than braking)
        val speedBeforeCoast = engine.speedMps
        repeat(25) {
            engine.step(0.016f, ControlInput())
        }
        val coastDrop = speedBeforeCoast - engine.speedMps
        assertTrue("Releasing gas should slow car down slowly", coastDrop > 0.5f && coastDrop < 5f)

        // Pressing BRAKE slows down firmly and brings car to a full stop
        repeat(80) {
            engine.step(0.016f, ControlInput(brakePressed = true))
        }
        assertEquals("BRAKE should slow down and stop the car", 0f, engine.speedMps, 0.01f)
    }

    @Test
    fun tiltSteeringMovesCarSmoothlyLeftAndRightAcrossAllMaps() {
        for (map in GameMap.entries) {
            val engine = RaceEngine(initialMap = map, initialCar = CarCatalog.RED_SPORTS_CAR).apply {
                trafficVehicles.clear()
            }
            val startX = engine.playerX

            // Tilt phone left -> positive tiltSteer (+X in GL screen space)
            repeat(24) {
                engine.step(0.016f, ControlInput(acceleratePressed = true, tiltSteer = 0.6f))
            }
            assertTrue("${map.displayName}: tilt left should move car left (+X)", engine.playerX > startX + 0.6f)
            assertTrue("${map.displayName}: tilt left should turn front wheels left", engine.steerVisualAngle > 6f)
            assertTrue("${map.displayName}: tilt left should angle car nose left", engine.carHeadingDeg > 3f)

            val afterLeftX = engine.playerX
            // Tilt phone right -> negative tiltSteer (-X in GL screen space)
            repeat(40) {
                engine.step(0.016f, ControlInput(acceleratePressed = true, tiltSteer = -0.6f))
            }
            assertTrue("${map.displayName}: tilt right should move car right (-X)", engine.playerX < afterLeftX - 1.2f)
            assertTrue("${map.displayName}: tilt right should turn front wheels right", engine.steerVisualAngle < -6f)
        }
    }

    @Test
    fun tiltProcessorMapsLandscapeLeftAndRightGravityAndAppliesMediumSensitivity() {
        // Near-level phone within deadzone produces 0 steering
        assertEquals(0f, TiltSteeringProcessor.mapTiltToSteerAxis(0.04f), 0.0001f)
        assertEquals(0f, TiltSteeringProcessor.mapTiltToSteerAxis(-0.04f), 0.0001f)

        // Medium (~18 deg) vs Full (~30 deg) tilt curves smoothly
        val medium = TiltSteeringProcessor.mapTiltToSteerAxis(0.30f)
        val full = TiltSteeringProcessor.mapTiltToSteerAxis(0.49f)
        assertTrue("Medium tilt should give smooth partial steering ($medium)", medium in 0.35f..0.7f)
        assertEquals(1f, full, 0.0001f)

        // ROTATION_90: tilting phone LEFT dips screen-left (+Y) down -> ay < 0
        val leftProcessor = TiltSteeringProcessor()
        var leftSteer = 0f
        repeat(15) {
            leftSteer = leftProcessor.onAccelerometerSample(
                ax = 9.2f,
                ay = -3.4f,
                az = 1.0f,
                displayRotation = Surface.ROTATION_90
            )
        }
        assertTrue("ROTATION_90 tilt left (ay < 0) must yield positive left steer ($leftSteer)", leftSteer > 0.3f)

        // ROTATION_90: tilting phone RIGHT dips screen-right (-Y) down -> ay > 0
        val rightProcessor = TiltSteeringProcessor()
        var rightSteer = 0f
        repeat(15) {
            rightSteer = rightProcessor.onAccelerometerSample(
                ax = 9.2f,
                ay = 3.4f,
                az = 1.0f,
                displayRotation = Surface.ROTATION_90
            )
        }
        assertTrue("ROTATION_90 tilt right (ay > 0) must yield negative right steer ($rightSteer)", rightSteer < -0.3f)

        // ROTATION_270: axes flip -> tilting phone LEFT gives ay > 0, still yields positive left steer
        val reverseLeftProcessor = TiltSteeringProcessor()
        var reverseLeftSteer = 0f
        repeat(15) {
            reverseLeftSteer = reverseLeftProcessor.onAccelerometerSample(
                ax = -9.2f,
                ay = 3.4f,
                az = 1.0f,
                displayRotation = Surface.ROTATION_270
            )
        }
        assertTrue("ROTATION_270 tilt left must yield positive left steer ($reverseLeftSteer)", reverseLeftSteer > 0.3f)
    }

    @Test
    fun leftAndRightSteeringMoveCarLaterallyWithinRoadBounds() {
        val engine = RaceEngine(initialMap = GameMap.VILLAGE, initialCar = CarCatalog.RED_SPORTS_CAR)
        val startX = engine.playerX

        repeat(24) {
            engine.step(0.016f, ControlInput(leftPressed = true, acceleratePressed = true))
        }
        assertTrue("Left button should steer car screen-left (+X)", engine.playerX > startX + 0.5f)
        assertTrue("Front wheels should turn left", engine.steerVisualAngle > 10f)
        assertTrue("Car nose heading should turn left", engine.carHeadingDeg > 5f)

        val afterLeftX = engine.playerX
        repeat(40) {
            engine.step(0.016f, ControlInput(rightPressed = true, acceleratePressed = true))
        }
        assertTrue("Right button should steer car screen-right (-X)", engine.playerX < afterLeftX - 1.0f)
        assertTrue("Front wheels should turn right", engine.steerVisualAngle < -10f)
        assertTrue("Car nose heading should turn right", engine.carHeadingDeg < -5f)
    }

    @Test
    fun allThreeMapsHaveCurvedRoadsAndSmoothSteeringAndNeverAutoChange() {
        for (map in GameMap.entries) {
            // Verify road actively turns left and right instead of driving in a straight line
            val samples = (0..200 step 10).map { z -> RaceEngine.trackCenterX(map, z.toFloat()) }
            val roadLateralSpan = samples.max() - samples.min()
            assertTrue(
                "${map.displayName} road must curve visibly (span=$roadLateralSpan)",
                roadLateralSpan > 10f
            )

            val engine = RaceEngine(initialMap = map, initialCar = CarCatalog.RED_SPORTS_CAR).apply {
                trafficVehicles.clear()
            }
            val startX = engine.playerX
            repeat(25) {
                engine.step(0.016f, ControlInput(leftPressed = true, acceleratePressed = true))
            }
            assertEquals("Map must never change automatically", map, engine.currentMap)
            assertTrue("${map.displayName}: Left steering should move +X", engine.playerX > startX + 0.6f)

            val peakLeftX = engine.playerX
            repeat(45) {
                engine.step(0.016f, ControlInput(rightPressed = true, acceleratePressed = true))
            }
            assertTrue("${map.displayName}: Right steering should move -X", engine.playerX < peakLeftX - 1.2f)

            // Releasing steering should smoothly self-center wheel angle & heading
            repeat(45) {
                engine.step(0.016f, ControlInput(acceleratePressed = true))
            }
            assertTrue(
                "${map.displayName}: Steering wheel should self-center on release",
                kotlin.math.abs(engine.steerVisualAngle) < 2.0f
            )
        }
        assertNotEquals(GameMap.CITY.roadHalfWidth, GameMap.VILLAGE.roadHalfWidth)
        assertNotEquals(GameMap.VILLAGE.roadHalfWidth, GameMap.JUNGLE.roadHalfWidth)
    }

    @Test
    fun collectingGoldCoinIncrementsCoinsAndAdds100Score() {
        val engine = RaceEngine(initialMap = GameMap.CITY, initialCar = CarCatalog.RED_SPORTS_CAR)
        engine.goldCoins.clear()
        engine.goldCoins.add(GoldCoin(id = 999, x = engine.playerX, z = engine.distanceZ + 0.5f))

        var coinCallbackFired = false
        engine.onCoinCollected = { coinCallbackFired = true }

        engine.step(0.016f, ControlInput(acceleratePressed = true))

        assertTrue(coinCallbackFired)
        assertEquals(1, engine.coinsCollected)
        assertTrue(engine.score >= 100)
    }

    @Test
    fun collisionDetectionDecrementsShieldsAndTriggersGameOverAfterThreeHits() {
        val engine = RaceEngine(initialMap = GameMap.JUNGLE, initialCar = CarCatalog.RED_SPORTS_CAR)
        var collisions = 0
        engine.onCollision = { collisions++ }

        repeat(3) { hitIdx ->
            // Clear invulnerability before placing next obstacle directly ahead
            repeat(100) {
                engine.trafficVehicles.clear()
                engine.step(0.02f, ControlInput())
            }
            engine.trafficVehicles.add(
                TrafficVehicle(
                    id = 500 + hitIdx,
                    x = engine.playerX,
                    z = engine.distanceZ + 0.5f,
                    speedMps = 0f,
                    width = 1.9f,
                    length = 4.0f,
                    style = 0,
                    colorRgb = Triple(1f, 1f, 1f)
                )
            )
            engine.step(0.016f, ControlInput(acceleratePressed = true))
        }

        assertEquals(3, collisions)
        assertEquals(0, engine.shields)
        assertTrue(engine.isGameOver)
    }

    @Test
    fun pauseFreezesTimerAndMovementUntilResumed() {
        val engine = RaceEngine(initialMap = GameMap.CITY, initialCar = CarCatalog.RED_SPORTS_CAR)
        engine.step(0.016f, ControlInput(acceleratePressed = true))
        val zBeforePause = engine.distanceZ
        val timeBeforePause = engine.elapsedMs

        engine.setPaused(true)
        repeat(30) {
            engine.step(0.016f, ControlInput(acceleratePressed = true))
        }
        assertEquals(zBeforePause, engine.distanceZ, 0.0001f)
        assertEquals(timeBeforePause, engine.elapsedMs)

        engine.setPaused(false)
        engine.step(0.016f, ControlInput(acceleratePressed = true))
        assertFalse(engine.isPaused)
        assertTrue(engine.distanceZ > zBeforePause)
        assertTrue(engine.elapsedMs > timeBeforePause)
    }

    @Test
    fun upgradesImproveTopSpeedAccelerationBrakingAndHandlingAcrossAllMaps() {
        val baseCar = CarCatalog.RED_SPORTS_CAR
        val maxedUpgrades = CarUpgrades(
            topSpeedLevel = 5,
            accelerationLevel = 5,
            brakingLevel = 5,
            handlingLevel = 5
        )
        val tunedCar = CarCatalog.withUpgrades(baseCar, maxedUpgrades)

        for (map in GameMap.entries) {
            val stockEngine = RaceEngine(initialMap = map, initialCar = baseCar).apply { trafficVehicles.clear() }
            val tunedEngine = RaceEngine(initialMap = map, initialCar = tunedCar).apply { trafficVehicles.clear() }

            // 1. Acceleration & Top Speed check across 4 seconds of full gas
            repeat(250) {
                stockEngine.step(0.016f, ControlInput(acceleratePressed = true))
                tunedEngine.step(0.016f, ControlInput(acceleratePressed = true))
            }
            assertTrue(
                "Tuned car should reach higher speed on ${map.displayName}",
                tunedEngine.speedMps > stockEngine.speedMps + 5f
            )
            assertTrue(
                "Tuned car should cover more distance on ${map.displayName}",
                tunedEngine.distanceZ > stockEngine.distanceZ
            )

            // 2. Braking check: accelerate cleanly, then brake for 0.32s -> tuned car sheds more speed
            val brakeStock = RaceEngine(initialMap = map, initialCar = baseCar).apply { trafficVehicles.clear() }
            val brakeTuned = RaceEngine(initialMap = map, initialCar = tunedCar).apply { trafficVehicles.clear() }
            repeat(150) {
                brakeStock.step(0.016f, ControlInput(acceleratePressed = true))
                brakeTuned.step(0.016f, ControlInput(acceleratePressed = true))
            }
            val stockDropStart = brakeStock.speedMps
            val tunedDropStart = brakeTuned.speedMps
            repeat(20) {
                brakeStock.step(0.016f, ControlInput(brakePressed = true))
                brakeTuned.step(0.016f, ControlInput(brakePressed = true))
            }
            val stockDelta = stockDropStart - brakeStock.speedMps
            val tunedDelta = tunedDropStart - brakeTuned.speedMps
            assertTrue(
                "Tuned braking should shed more speed on ${map.displayName}",
                tunedDelta > stockDelta + 5f
            )

            // 3. Handling check: lateral movement distance steering left (+X)
            val handleStock = RaceEngine(initialMap = map, initialCar = baseCar).apply { trafficVehicles.clear() }
            val handleTuned = RaceEngine(initialMap = map, initialCar = tunedCar).apply { trafficVehicles.clear() }
            val startX = handleStock.playerX
            repeat(22) {
                handleStock.step(0.016f, ControlInput(leftPressed = true, acceleratePressed = true))
                handleTuned.step(0.016f, ControlInput(leftPressed = true, acceleratePressed = true))
            }
            val stockSteerDist = handleStock.playerX - startX
            val tunedSteerDist = handleTuned.playerX - startX
            assertTrue(
                "Tuned handling should steer further laterally on ${map.displayName}",
                tunedSteerDist > stockSteerDist + 0.4f
            )
        }
    }

    @Test
    fun carUpgradesScalingCostsMatchFiveTiers() {
        assertEquals(listOf(50, 100, 175, 275, 400), CarUpgrades.TIER_COSTS)
        assertEquals(50, CarUpgrades.costForNextLevel(0))
        assertEquals(400, CarUpgrades.costForNextLevel(4))
        assertEquals(null, CarUpgrades.costForNextLevel(5))
        assertEquals(0, CarUpgrades().levelFor(UpgradeStat.BRAKING))
    }

    @Test
    fun tharSpecIsBlackBoxySuvWithBigTiresFasterThanPhantomOnyxAndCosts5000() {
        val thar = CarCatalog.THAR_SUV
        val phantom = CarCatalog.PHANTOM_ONYX
        assertEquals("thar", thar.id)
        assertEquals("Thar", thar.name)
        assertEquals(com.example.model.CarBodyStyle.BOXY_SUV, thar.bodyStyle)
        assertTrue("Thar should have black paint", thar.primaryColorRgb.first <= 0.12f && thar.primaryColorRgb.second <= 0.12f && thar.primaryColorRgb.third <= 0.14f)
        assertTrue("Thar should have big off-road tires", thar.wheelScale >= 1.35f)
        assertTrue("Thar top speed (${thar.maxSpeedKmh}) should be faster than Phantom Onyx (${phantom.maxSpeedKmh})", thar.maxSpeedKmh > phantom.maxSpeedKmh)
        assertEquals(5000, thar.unlockCostCoins)
        assertTrue("Thar should be in CarCatalog.allCars", CarCatalog.allCars.any { it.id == "thar" })
    }
}
