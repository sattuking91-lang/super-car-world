# SUPER CAR WORLD — Car Upgrade System Plan

Add a persistent, per-car performance upgrade system to **SUPER CAR WORLD** where players spend gold coins earned during races (plus a 150-coin starter bonus) inside the Garage to upgrade **Top Speed**, **Acceleration**, **Braking**, and **Handling** across 5 scaling tiers, directly enhancing driving physics across the City, Village, and Jungle maps.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> All four product decisions below were confirmed during clarification and drive the design of the upgrade system.

- **Confirmed Decision 1 — Per-Car Upgrade Ownership**: Upgrades are purchased and saved individually per car (`Crimson Viper`, `Volt GT`, `Solaris Apex`, `Phantom Onyx`) rather than globally, giving each vehicle its own distinct tuning progression.
- **Confirmed Decision 2 — 5 Upgrade Tiers with Scaling Coin Costs**: Each of the four performance stats advances from Level 0 to Level 5 with scaling coin prices (`50`, `100`, `175`, `275`, `400` coins per tier).
- **Confirmed Decision 3 — Integrated Garage Tuning UI**: Upgrades live directly inside the existing **Select Car** Garage screen so players select a car, inspect its live 3D model, and purchase upgrades in one seamless view.
- **Confirmed Decision 4 — 150 Starter Coins**: New players begin with **150 gold coins** in their wallet so they can test upgrades immediately before or after their first race.

---

## 1. Overview & Core Concept

- **What It Does**: Connects in-race gold coin collection to a permanent garage tuning economy. Every gold coin picked up on the road is banked into the player's persistent coin wallet, which can be spent in the Garage on four performance attributes (**Top Speed**, **Acceleration**, **Braking**, **Handling**) for any car.
- **Target Audience**: Arcade racing players who want tangible progression, faster lap speeds, sharper braking before traffic, and nimbler lane-switching across all three maps.
- **Key Value**: Transforms gold coins from a pure score bonus into meaningful vehicle progression that noticeably changes how each car accelerates, corners, and stops on the City, Village, and Jungle tracks.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **First Launch & Wallet Awareness**:
   - The player starts with `150` gold coins displayed in a championship gold coin pill on the Main Menu and Garage header.
2. **Selecting a Car & Purchasing Upgrades (Garage)**:
   - Player taps **SELECT CAR** from the Main Menu.
   - Player chooses any car from the 4-car selector (`Crimson Viper` selected by default, plus `Volt GT`, `Solaris Apex`, `Phantom Onyx`). The interactive 3D turntable updates immediately.
   - Inside the **Performance Tuning** panel, the player views the selected car's 4 upgrade cards: **Top Speed**, **Acceleration**, **Braking**, and **Handling**.
   - Each card shows current effective value, next-level gain preview (e.g., `+8 km/h`), a 5-pip tier meter (`Lv 0/5` to `Lv 5/5`), and an **UPGRADE** button displaying the coin cost.
   - Tapping **UPGRADE** deducts coins from the wallet, increments that car's stat level, plays a celebratory sound effect, and updates the stat bar immediately. If coins are insufficient, the button clearly indicates the deficit; at Level 5, it displays a `MAXED` state.
3. **Earning Coins & Feeling Upgrades on Track**:
   - Player launches into **CITY MAP**, **VILLAGE MAP**, or **JUNGLE MAP** (selected explicitly by the player; maps never auto-switch).
   - During the race, every collected 3D gold coin increments both the race HUD coin counter and the persistent coin wallet, while the upgraded physics parameters control peak velocity, throttle pull, brake deceleration, and steering agility.

### Visual Identity & Theme

- **Aesthetic Direction**: Motorsport dark carbon garage with high-contrast championship gold accents for coin economy and emerald/cyan highlights for stat gains.
- **Color Tokens**: Continues using the existing `AsphaltDark` (`#0A0E17`) and `CarbonSurface` (`#131A29`) cards paired with `GoldBright` (`#FACC15`) for coin badges, `RacingCrimson` (`#EF4444`) for primary drive actions, `ElectricCyan` (`#06B6D4`) for handling/speed gauges, and `EmeraldJungle` (`#10B981`) for upgraded stat delta indicators.
- **Typography**: `Chakra Petch` display headings for car titles, tier counters (`LV 2/5`), and coin totals; `Plus Jakarta Sans` for crisp cost labels and stat descriptions.
- **Responsive Layout**:
  - *Portrait*: Interactive 3D car showroom at top, 4-car selector grid, compact stat summary + 4 upgrade cards in a scrollable column, pinned/accessible **DRIVE** button, respecting `WindowInsets.safeDrawing`.
  - *Landscape*: Split two-pane layout — live 3D car showroom + car selector on the left, scrollable Performance Tuning upgrade cards + **DRIVE** button on the right.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Immediate Coin Banking on Pickup**
  - *Chosen Approach*: Bank each collected gold coin into the persistent wallet as soon as it is picked up during a race.
  - *Why*: Players who pause and return to the Main Menu mid-run keep every coin they earned instead of losing progress.
  - *Alternatives Considered*: Awarding coins only on Game Over (penalizes players who exit early).

- **Decision 2 — Local Preferences Persistence vs. Cloud Sign-In**
  - *Chosen Approach*: Store the coin wallet balance and per-car upgrade levels (`carId` × `statType` → `0..5`) in the existing local DataStore repository alongside best scores and audio settings.
  - *Why*: Keeps the arcade racing loop instant and offline-friendly with zero mandatory sign-in wall, matching the app's existing persistence architecture.
  - *Alternatives Considered*: Adding Firebase Authentication and Firestore, which would introduce an account gate not requested by the user.

- **Decision 3 — Dedicated Braking Stat Added to Car Specs & UI**
  - *Chosen Approach*: Surface **Braking** as a first-class stat alongside Top Speed, Acceleration, and Handling in both the car specs and Garage tuning panel.
  - *Why*: Previously braking used a fixed constant in the simulation engine; making it car-specific and upgradeable ensures all four requested upgrades visibly alter stopping distance and brake response.

---

## 4. Technical Architecture & Data Strategy

### Architecture & Component Diagram

```
┌────────────────────────────────────────────────────────────────────┐
│                       Persistence (DataStore)                      │
│  • Coin Wallet Balance (default: 150)                              │
│  • Per-Car Upgrade Map: (carId, stat) -> Level [0..5]              │
└───────────────────────────────┬────────────────────────────────────┘
                                │ Flow<GameSettings>
                                ▼
┌────────────────────────────────────────────────────────────────────┐
│                          GameViewModel                             │
│  • Computes effective CarSpec = baseSpec + per-car upgrade levels  │
│  • purchaseUpgrade(carId, stat) -> validates coins & saves level   │
│  • onCoinCollected() -> increments coin wallet & plays coin SFX    │
└──────────────┬────────────────────────────────┬────────────────────┘
               │ StateFlow                      │ Effective CarSpec
               ▼                                ▼
┌──────────────────────────────┐  ┌──────────────────────────────────┐
│    Garage UI (Select Car)    │  │       RaceEngine (Physics)       │
│  • Wallet Coin Pill          │  │  • maxSpeedKmh = base + 8 * lv   │
│  • 4-Car Selector + 3D View  │  │  • accelRate   = base + 3.2 * lv │
│  • 4 Upgrade Cards (Lv 0..5) │  │  • brakeDecel  = base + 7.5 * lv │
│  • Cost / Maxed / Deficit UX │  │  • handling    = base + 0.12 * lv│
└──────────────────────────────┘  └──────────────────────────────────┘
```

### Data Model & Upgrade Scaling

- **Upgrade Categories (`UpgradeStat`)**:
  - `TOP_SPEED`: `+8 km/h` per level (up to `+40 km/h` at Level 5).
  - `ACCELERATION`: `+3.2 m/s²` acceleration rate per level (up to `+16.0 m/s²`).
  - `BRAKING`: `+7.5 m/s²` braking deceleration per level (up to `+37.5 m/s²` over the `38 m/s²` base).
  - `HANDLING`: `+0.12` lateral steering multiplier per level (up to `+0.60` faster lane response and sharper cornering stability).
- **Tier Cost Curve**:
  - Tier 1: `50` coins | Tier 2: `100` coins | Tier 3: `175` coins | Tier 4: `275` coins | Tier 5: `400` coins.
- **Effective Car Resolution**:
  - Before starting any race on City, Village, or Jungle maps—and when previewing cars in the Garage—the ViewModel resolves an effective `CarSpec` combining the car's base specs with its saved `CarUpgrades` levels.

### Interactive Component & State Mapping

- **Car Card Tap (`car_button_<id>`)**: Switches active `selectedCarId`, updates the 3D showroom car, and rebinds the 4 upgrade cards to that specific car's levels and costs.
- **Upgrade Purchase Tap (`upgrade_button_<stat>`)**: Checks `coinBalance >= nextCost` and `currentLevel < 5`. On success, atomically subtracts cost, increments that car's stat level in state and DataStore, plays feedback SFX, and recalculates effective car stats.
- **Race Coin Pickup**: `RaceEngine` triggers `onCoinCollected`, updating both the race HUD coin counter and the persistent wallet balance in `GameViewModel`.
- **Driving Physics (`RaceEngine.step`)**: Applies the effective car's `maxSpeedKmh`, `accelerationRate`, `brakingDeceleration`, and `handlingRating` uniformly across `CITY`, `VILLAGE`, and `JUNGLE` maps.
